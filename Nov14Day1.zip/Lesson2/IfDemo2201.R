marks<-c(78,56,45,89,90,23,45)
print(" 1:Add, 2:Average, 3:Minimum, 4:Maximum")

ch<-readline(prompt="Enter your choice :")

ch<-as.integer(ch)

result<-switch(ch,sum(marks),mean(marks),min(marks),max(marks))
print(paste("Result is",result),quote = FALSE)
