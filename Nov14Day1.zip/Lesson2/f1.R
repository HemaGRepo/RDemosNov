sumOfNum<-function(n1,n2){
  print(paste("The First number is",n1))
  print(paste("The Second number is",n2))
  sum<-n1+n2
  print(paste("The Sum number is",sum))
}