#No param no return
f1<-function(){
  print("Welcome to functions")
}
#Invoke
f1()

#With params
calculate<-function(a,b){
  c<-a+b
  d<-a*b
  print(paste(a,"+",b,"=",c))
  print(paste(a,"*",b,"=",d))
}

calculate(78,3)

#params - positional notation
calc<-function(a,b,c){
  d<-(a+b)*c
  ans<-c^2
  print(paste(a,"+",b,"*",c,"=",d))
  print(paste(c,"*",c,"=",ans))
}

#Positional notation
calc(6,9,4)#a=6,b=9,c=4

#named notation
calc(c=3,a=2,b=14)#c=3,a=2,b=14

#Mixed notation
calc(c=5,10,18)

calc(b=5,2,6)

calc(2,a=3,8)

class(calc)


#Deafult values

calc1<-function(a,b=7,c=3,d){
  e<-(a+b)
  ans<-c^2
  print(paste(a,"+",b,"=",e))
  print(paste(c,"*",c,"=",ans))
  print(paste("d=",d))
}

#calc1 ,a,b,c,d and b,c have default values
calc1(2,4,9,10)

calc1(d=2,a=17)

calc1(8,10)

calc1(8,,,10)


#Lazy function
f2<-function(a,b){
  ans<-a*a
  print(paste(a,"*",a,"=",ans))
  print("------Processed a-------")
 # print(b)
}

f2(8,4)
f2(7)

#Return types
# Every R function always returns a value, which is the result of the last statement executed

calc1<-function(a,b,c,d){
  e<-(a+b)
  ans<-c^2
  f<-a*d
  m<-b*3
  print("Hello....")
}

res<-calc1(7,4,8,9)
print(res)

calc1<-function(a,b,c,d){
  e<-(a+b)
  ans<-c^2
  f<-a*d
  m<-b*3
  print("Hello....")
  return(ans)
}

res<-calc1(7,4,8,9)
print(res)

# R recursive functions
fact<-function(x){
  if(x==0) { return(1)} 
  else{ return(x*factorial(x-1)) }
}
fact(3)


# Nested functions
f1<-function(){
  a<<-10; #parent environment
  b<-20; #within the function
  print(a);
  print(b);
}

f1()


f2<-function(){
  10->>x; #parent environment
  20->y; #within the function
  print(x);
  print(y);
}

f2()


m1<-function(){#Outer function
  a<-10; 
  b<-20; 
  print(paste("Value of a in m1=",a));
  print(paste("Value of b in m1=",b));
    m2<-function(){
      print("------------M2 starts------------")
      a<<-40;# Make the value of a in m1(parent) as 40
      b<-90; #Create a new variable in m2 with name b and value 90
      print(paste("Value of a in m2=",a));
      print(paste("Value of b in m2=",b));
      print("------------M2 ends------------")
    }
    m2()
  print(paste("Value of a in m1=",a));
  print(paste("Value of b in m1=",b));
}#Outer function ends


f1<-function(){
  a<<-10; #parent environment
  a<-20; #within the function
  print(a);
  #e<-parent.env(environment())
  #x<-get('a',envir = e);
  print(get('a',envir = parent.env(environment())))
}

f1()













