salary<-290000

# If statement

if(salary<100000)
{
  print("No need to pay tax")
}

# If statement

if(salary<100000)
{
  print("No need to pay tax")
}else{
  print("Tax to be paid...")
}

#if...elseif...elseif...else
feedback<-readline(prompt="Enter the feedback :(0-10) ")

if(feedback<3){
  print("Very poor")
}else if(feedback<5){
  print("Poor")
}else if(feedback<7){
  print("ok")
}else if(feedback<=9){
  print("Thats Good")
} else{
  print("You are excellent!!!!!!")
}

#Repeat Loop - Infinite loop
repeat{
  print("Welcome")
}

#Repeat

repeat{
  print("Welcome")
  choice<-readline("Do u want to continue 0-Yes, 1-No :")
  if(choice==1)
    break;
}

cntr<-1
repeat{
  print(paste("This is ",cntr," time"))
  cntr<-cntr+1
  if(cntr>10) #Check condition
    break; #Manual break
}

#While statement - Entry control

cntr<-1
while(cntr<=10){
  print(paste("This is ",cntr," time"))
  cntr<-cntr+1
}


#break...next
# break - terminate the loop


cntr<-1
while(cntr<=10){
  print(paste("This is ",cntr," time"))
  cntr<-cntr+1
  if(cntr==5)
    break; # Stop executing the loop
  print("--------------------------------")
}


cntr<-1
while(cntr<=10){
  print(paste("This is ",cntr," time"))
  cntr<-cntr+1
  if(cntr==5)
    next; #Dont do the remaining lines for this iteration
  print("--------------------------------")
}


#---------------------------------------

numbersArr<-c(12,3,4,5,7,17,8,19,10,15,21)

# For all even numbers print ********

cntr<-1
while(cntr<=length(numbersArr))
{
  temp=numbersArr[cntr];
  cntr=cntr+1
  if(temp%%2!=0)
    next;
  print(paste(temp," *******"))
}


# Find the first even number

cntr<-1
while(cntr<=length(numbersArr))
{
  temp=numbersArr[cntr];
  cntr=cntr+1
  if(temp%%2==0){
    print(paste(temp," *******"))
    break;
  }
}



n1<-c(6,3,7,10,2)
for(temp in n1)
{
  print(temp*2)
}



f1<-c(4,1,10,7,3,8)

for(feedback in f1){
  print("---------------------")
  print(feedback)
      if(feedback<3){
        print("Very poor")
      }else if(feedback<5){
        print("Poor")
      }else if(feedback<7){
        print("ok")
      }else if(feedback<=9){
        print("Thats Good")
      } else{
        print("You are excellent!!!!!!")
      }
}




