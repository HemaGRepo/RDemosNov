age=26
location="Pune"
.password="Cap@123"
.5scores=67
10thModule="JEE"
_Status="Done"
Student_Name="John"

9/2

9%%2
9%/%2

balance=84899
minBal=20000
print(balance>minBal)

print(!balance>minBal)

print(balance>minBal&&age>30)

print(balance>minBal||age>30)

#Assignment Operators =, ->, <- , ->>, <<-

# =, -> and <- do the same job for a simple variable

age=26
age<-43
68->age

# For a data structure 
# <- and -> is used to create a DS
# = is used to assign name to elements inside a DS

products<-c("TV"=47857,"iPhone"=78788,"Pen"=10,"Book"=489)
print(products)

c("TV"=47857,"iPhone"=78788,"Pen"=10,"Book"=489)->catalog

# <- and <<- or -> and ->>
# <<- and ->> are used to assign variables in parent environment


x<-readline()
fname<-readline(prompt = "Enter First name : ")
lname<-readline(prompt = "Enter Last name : ")
print(paste("FirstName :",fname," LastName : ",lname, " You are not ",age," years old!!!!"))

x<-readline()
y<-readline()
x<-as.integer(x); y<-as.integer(y)
print(x+y)



