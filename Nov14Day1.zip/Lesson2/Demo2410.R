#R script file
print("-------------------------",quote=FALSE)
print("    Welcome to R",quote=FALSE)
print(paste("WI score :",score),quote=FALSE)
print("Double century by India",quote=FALSE)
result=sum(sal)
print(result)
print("-------------------------",quote=FALSE)