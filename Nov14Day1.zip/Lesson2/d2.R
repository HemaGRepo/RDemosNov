#If statement
age=10
if(age>18){
  print("You are eligible to work!")
}

#If..else statement 
age=10
if(age>18){
  print("You are eligible to work!")
}else{
  print("You dont qualify......")
}

#If..else if...else if
price<-readline(prompt="Enter the price : ")
if(price<200){
  discount<-10
  print("You are eligible for 10% discount")
}else if(price<400){
  discount<-20
  print("You are eligible for 20% discount")
}else if(price<500){
  discount<-30
  print("You are eligible for 30% discount")
}else{
    discount<-35
    print("You are eligible for 35% discount")
}

#for
#5:14
for(temp in 5:14){
  print(paste("Processing the number...",temp),quote = FALSE)
  print(paste("Square of ",temp,"is",temp^2),quote = FALSE)
  print("--------------")
}


#While

n1<-7:13
res<-0
cnt<-1
while(cnt<=length(n1)){
  temp<-n1[cnt]
  cnt<-cnt+1
  if(temp==11)
   # next
    break
  res<-res+temp
}
print(paste("The sum of 7:13 is: ",res))


#repeat
repeat{
  print("Hi")
}

cnt<-0
#repeat
repeat{
  print("Hi")
  cnt<-cnt+1
  if(cnt>=10)
    break;
}








