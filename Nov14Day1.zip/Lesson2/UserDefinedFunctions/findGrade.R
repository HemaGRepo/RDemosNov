findGrade<-function(total)
{
  if(total>90)
    return("A")
  else if(total>=80)
    return("B")
  else if(total>=70)
    return("C")
  else if(total>=60)
    return("D")
  else
    return("F")
}

findGrade(45)

findGrade(78)

findGrade(94)