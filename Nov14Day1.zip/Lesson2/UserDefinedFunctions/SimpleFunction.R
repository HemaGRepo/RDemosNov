#Function demo
pow = function(x, y) {
  # function to print x raised to the power y
  
  result <- x^y
  print(paste(x,"raised to the power of ", y, "is", result))
}

pow(8, 2)
pow(7,4)
