# Recursive function to find factorial of
# natural numbers upto n
# using recursive function

fact <- function(x) {
  if (x == 0)    return (1)
  else           return (x * fact(x-1))
}

factorialOfNum<-function(num){
  if(num==0) return(1)
  else return(num*factorialOfNum(num-1))
}
factorialOfNum(5)

















