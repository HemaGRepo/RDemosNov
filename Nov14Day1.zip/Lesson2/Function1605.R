sumOfNum<-function(a,b){
  print(a+b)
}

sumOfNum(5,6)

#res and res2 are variables in function scope
calc<-function(a,b,c){
  print(paste("A=",a))
  print(paste("B=",b))
  print(paste("C=",c))
  res<-a*c
  print(paste("res=",res))
  res2<-b*b
  print(paste("res2=",res2))
}

calc(5,2,9) #Positional notation
calc(c=10,a=3,b=5) #Named notation
calc(b=7,6,4) #mixed notation

calc(6,4,b=7)
calc(6,a=7,3)
calc(a=8,9)

# Default values
calc<-function(a,b=9,c,d=4){
  print(paste("A=",a))
  print(paste("B=",b))
  print(paste("C=",c))
  print(paste("D=",d))
  res<-a*c
  print(paste("res=",res))
  res2<-b+d
  print(paste("res2=",res2))
}

calc(7,2,3,4)
calc(a=6,c=10)
calc(5,10) #Incorrect
calc(2,6,10)
calc(3,,8,)

#calc(TRUE,FALSE,"76","Hello")

#Functions are Lazy
f1<-function(a,b){
  print(paste("A=",a))
  res<-a*a
  print(paste("res=",res))
  print(paste("B=",b))
}
f1(4)


readVal<-function(prompt){
  print(paste(prompt,"Result..."))
}

readVal("Hello")
readVal(prompt="Hello")

readline("Enter ur name:")
readline(prompt="Enter ur name:")

f1<-function(){
  a<-10 # Accessible inside the function
  b<<-20 #Global variable - added to Global environment
  print(paste("A=",a))
  print(paste("B=",b))
}

f1()

print(paste("A=",a)) #Invalid
print(paste("B=",b)) #Valid


#Nested functions
m1<-function(){#Outer function
  a<-10; 
  b<-20; 
  print(paste("Value of a in m1=",a));
  print(paste("Value of b in m1=",b));
  m2<-function(){
    print("------------M2 starts------------")
    a<<-40;# Make the value of a in m1(parent) as 40
    b<-90; #Create a new variable in m2 with name b and value 90
    # 40->>a
    print(paste("Value of a in m2=",a));
    print(paste("Value of b in m2=",b));
    print("------------M2 ends------------")
  }
  m2()
  print(paste("Value of a in m1=",a));
  print(paste("Value of b in m1=",b));
}#Outer function ends
m1()

#Returning values - R automatically returns the value of the last statement
calc<-function(a,b,c){
  print(paste("A=",a))
  print(paste("B=",b))
  print(paste("C=",c))
 
  res2<-b*b
  print(paste("res2=",res2))
  
  res<-a*c
  print(paste("res=",res))
  
  return(c)
}

ans<-calc(4,6,7)
print(ans)

m1<-function(){#Outer function
  print(environment())
  m2<-function(){
    print(environment())
  }
  m2()
}
m1()

#Recursive function
factorial<-function(num1){
  if(num1==0){
    return(1)
  }else{
      return(num1*factorial(num1-1))
  }
}
factorial(5)


switch(
  10,
  print("Hai"),
  print("Demo"),
  print("Codes"),
  print("Functions"),
  print("Data Science"),
)


f2<-function(){}

f2()




