#Simple function - No params and No return
#declaration
fn1<-function(){
  print("Welcome to R")
  #a,b,c are in function scope
  a<-10
  b<-20
  res<-a+b
  print(paste(a,"+",b,"=",res),quote = FALSE)
}
#invocation
fn1()
print(res)

#Simple function - No params and No return
#declaration
fn2<-function(){
  print("Welcome to R")
  #a,b are in function scope
  a<-10
  b<-20
  #c1 in global scope
  c1<<-a+b
  print(paste(a,"+",b,"=",c1),quote = FALSE)
}
#invocation
fn2()
print(c1)

#Global Variable
v1<-10
v2<-60

fn3<-function(){
  #Local variable
  v1<-20
  print(paste("V1 inside function",v1))
  print(paste("V2 inside function",v2))
}
fn3()


#Global Variable
v1<-10
v2<-60

fn4<-function(){
  #Local variable
  v1<-20
  print(paste("V1 inside function",v1))
  print(paste("V2 inside function",v2))
  v1<<-45
  print(paste("V1 inside function",v1))
  print(get('v1',envir = parent.env(environment())))
  print(get('v1',envir = .GlobalEnv))
  print(get('v1',envir = globalenv()))
}
fn4()


#Nested functions
m1<-function(){#Outer function
  a<-10; 
  b<-20; 
  print(paste("Value of a in m1=",a));
  print(paste("Value of b in m1=",b));
  m2<-function(){
    print("------------M2 starts------------")
    a<<-40;# Make the value of a in m1(parent) as 40
    b<-90; #Create a new variable in m2 with name b and value 90
    print(paste("Value of a in m2=",a));
    print(paste("Value of b in m2=",b));
    print("------------M2 ends------------")
  }
  m2()
  print(paste("Value of a in m1=",a));
  print(paste("Value of b in m1=",b));
}#Outer function ends
m1()


#With parameters

doThis<-function(a,b,c,d){
  res1<-a+b
  res2<-c*d
  print(paste("res1 =",res1))
  print(paste("res2 =",res2))
}

doThis(6,2,5,4)
doThis(d=10,a=6,c=7,b=3)
doThis(d=7,b=3,5,12)



#With default parameters

doThis<-function(a=4,b,c=6,d){
  res1<-a+b
  res2<-c*d
  print(paste("res1 =",res1))
  print(paste("res2 =",res2))
}

doThis(6,2,5,4)
doThis(d=10,a=6,c=7,b=3)
doThis(d=7,b=3,5,12)
doThis(10,12) #Incorrect, a=10,b=12,c default value
doThis(b=10,d=12)
doThis(,7,,10)

# Lazy function

display<-function(a,b){
  print("Welcome")
  print(paste("a=",a))
  print("Thank You")
  print(paste("b=",b))
}
display(5)

#Functions implicitly return a value
#Return the value of the last statement executed
findGrade<-function(score){
  if(score>90){
    grade<-'A'
  }else if(score>70){
    grade<-'B'
  }  else if(score>50){
    grade<-'C'
  }else if(score>40){
    grade<-'D'
  }else{
    grade<-'F'
  }
}

res<-findGrade(25)
print(res)


fn1<-function(){
res<-7+10
res<-8*3
a<-4*9 #36 is returned by this function
}

#Explicit return statement

fn1<-function(){
  res1<-7+10
  res2<-8*3
  a<-4*9 #36 is returned by this function
  return(res1)
}
ans<-fn1()
print(ans)

#Recursive functions
fact<-function(n){
  if(n==0) return(1)
  else return(n*fact(n-1))
}

print(fact(5))


switch(2,5,9,10,12)

marks<-c(17,23,56,10,20,45)
ch<-3
switch(ch,sum(marks),mean(marks),min(marks),max(marks))


















