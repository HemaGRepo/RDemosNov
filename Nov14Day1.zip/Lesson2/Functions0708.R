# Simple function- No params and No return

f1<-function(){
  print("Welcome to R")
}
f1()

add<-function(){
  n1<-10
  n2<-45
  n3<-n1+n2
  print(paste("Sum of ",n1," and ",n2," is ",n3))
}
add()

#Functions with params

calc<-function(a,b,c,d){
  n1<-a*c
  n2<-b+d
  res<-n1+n2
  print(paste("a=",a,"b=",b,"c=",c,"d=",d))
  print(paste("Result is",res))
}

#Call with positional parameter
calc(10,3,4,5)

#Call with named parameter
calc(d=8,b=1,c=2,a=4)

#Call with mixed parameter
calc(b=5,d=10,3,6)

calc(6,7,8)

#Default parameters

calc<-function(a,b=8,c,d=10){
  n1<-a*c
  n2<-b+d
  res<-n1+n2
  print(paste("a=",a,"b=",b,"c=",c,"d=",d))
  print(paste("Result is",res))
}

calc(1,2,3,4)

calc(a=10,c=20)

calc(5,3)#a=5,b=3, c-no value error

calc(6,4,2)

calc(3,,2)


#Functions in R are LAzy
f3<-function(a,b){
  print("Welcome to functions")
  print(paste("a=",a))
  print("******************")
  print(paste("b=",b))
}
f3(5)

#Return values - Every function returns the result of the last statement executed

calc<-function(a,b,c,d){
  n1<-a*c
  n2<-b+d
  res<-n1+n2
  n1*5
  print("Welcome")
}

ans<-calc(2,3,4,5)
print(ans)


calc<-function(a,b,c,d){
  n1<-a*c
  n2<-b+d
  res<-n1+n2
  n1*5
  print("Welcome")
  print(environment())
  return(n2)
}

ans<-calc(2,3,4,5)
print(ans)

#recursive function

factorial<-function(n)
{
  if(n==0) return(1)
  else return(n*factorial(n-1))#5*4*factorial(3)
}

factorial(5)

# <<- and ->>

#For f5, the Global environment is the parent
f5<-function(){
  n1<-10 # Scope of the function f5, accessible inside f5 only
  n2<<-20 # Global variable, accessible anywhere, 20->>n2
  print(n1)
  print(n2)
}

f5()


#Nested functions - fn1 is parent and fn2 is child
# <<- or ->> assigns a value to parent environment

fn1<-function(){
  x<-10
  y<-20
  print(paste("......Parent starts....."))
  print(paste("The value of x is",x))
  print(paste("The value of y is",y))
  
  fn2<-function(){
    x<-40 # Create a variable x in function fn2
    y<<-25 # Take y from parent and assign the value 25
    print(paste("......Child starts....."))
    print(paste("The value of x is",x))
    print(paste("The value of y is",y))
    print(paste("......Child ends....."))
  }
  fn2()
  print(paste("......Parent starts....."))
  print(paste("The value of x is",x))
  print(paste("The value of y is",y))
}

fn1()



switch(2,print("Hai"),print("Welcome"),print("OOPS"),print("Thank U"))

switch(3,print("Hai"),print("Welcome"),print("OOPS"),print("Thank U"))






