fibo<-function(){
  len = as.integer(readline(prompt="How many terms? "))
  
  fib = len
  fib[1] = 1
  fib[2] = 1
  
  for (i in 3:len) { 
    fib[i] = fib[i-1] + fib[i-2]
  }
  print(fib)  
}