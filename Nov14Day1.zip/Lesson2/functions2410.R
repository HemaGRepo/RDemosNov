# Functions in R

# No param no return

f1<-function(){
  x<-10 #Local to the function
  print("Welcome to f1")
  y<-x*5 #Local to the function
  print(paste("X = ",x," Y= ",y))
}

typeof(f1)

f1()

#Params
calculate<-function(a,b,c,d){
  print("Welcome to Calculate Function")
  n1<-a*c #Local to the function
  n2<-b+d #Local to the function
  res<-n1+n2 #Local to the function
  print(paste("n1 = ",n1,"n2 = ",n2,"Res = ",res))
}

calculate(6,5,3,12) # Positional notation
calculate(6,5,3)

calculate(d=10,b=2,a=15,c=5) # Named notation

calculate(d=10,b=2,4,8) # Mixed notation (a,b=2,c,d=10)==> Assign 4,8 for a,c

#Params with default values
calculate<-function(a,b=2,c=7,d){
  print("Welcome to Calculate Function")
  n1<-a*c #Local to the function
  n2<-b+d #Local to the function
  res<-n1+n2 #Local to the function
  print(paste(" a = ",a," b = ",b," c = ",c," d = ",d))
  print(paste("n1 = ",n1,"n2 = ",n2,"Res = ",res))
}

calculate(6,5,3,12) 

calculate(10,5)# Error -  Positional notation a=10, b=5, c=7

calculate(a=10,d=5)

calculate(10,,,5)


# Return values in Functions

# Every R function automatically returns the result of the last statement


calc<-function(a,b,c,d){
  n1<-a*c #Local to the function
  n2<-b+d #Local to the function
  res<-n1+n2 #Local to the function
  temp<-d*2
  print(paste(" a = ",a," b = ",b," c = ",c," d = ",d))
  print(paste("n1 = ",n1,"n2 = ",n2,"Res = ",res))
}

t1<-calc(2,5,10,9)
print(t1)


# returns

calc1<-function(a,b,c,d){
  n1<-a*c #Local to the function
  n2<-b+d #Local to the function
  res<-n1+n2 #Local to the function
  temp<-d*2
  return(res)
}

t1<-calc1(2,5,10,9)
print(t1)

# What is the result - Lazy Functions
mycalc<-function(a,b){
  print("This is a function")
  print(paste("a =",a))
  print("-------------")
  print(paste("b =",b))
}

mycalc(10)



# Recursive functions
factorial1<-function(n){
  if(n==0){ 
    return(1)
  }  else {
    return(n*factorial1(n-1))
  }
}

res<-factorial1(5)
print(res)

# Global Environment 
m1<-function(){
  x<-10 # Functions environment - child environ
  y<<-20 # Add the value y to the Parent environ ie. Global Environment
  30->>z # Add the value y to the Parent environ ie. Global Environment
}

m1()


# m1() inside which another m2() is created

m1<-function(){
  x<-10 # in m1's environment
  y<-20
  print("In function m1")
  print(paste(" x = ",x," y = ",y)) # 10,20
  print("------------------")
  
  m2<-function(){
    x<-30 # in m2's environment
    y<<-40 # Make the value of y in parent environment as 40 ie. m1's y<<-40
    print("In function m2") 
    print(paste(" x = ",x," y = ",y)) # 30,40
    print("------------------")
  }
  m2()
  print("In function m1")
  print(paste(" x = ",x," y = ",y)) # 10,40
  print("------------------")
  
}

m1()

# Build in functions in R

# Generate Sequence
10:34
19:10

sequence(5) # Sequence from 1 to 5

seq(10,25) # Sequence from 10 to 25

seq(10,45,by = 3) # Start, stop, increment

seq(10,45,length.out = 8) # Equal spaced 8 numbers from 10 to 45

seq_len(10)

sum(1:10)
sum(seq(10,25) )
min(seq(10,25) )
max(seq(10,56,by=6))
mean(1:15)

rep("Hello",3)

rep(6,8)

rep(c(4,10,3,7),3)

rep(c(3,8),c(10,2))

choice<-1

switch(choice,seq(1,12),min(6:34),rep(4,5))
switch(choice,seq(1,12),min(6:34),rep(4,5))


switch(4,
       sum(1:10),
       seq(1,12),
       min(6:34),
       rep(4,5),
       m1(),
       seq_len(5))


f1<-function(){}
f1()