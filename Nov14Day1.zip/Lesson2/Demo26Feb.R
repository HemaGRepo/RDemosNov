#3 types of constants
# Numeric
# Character
 
# Numeric
typeof(4545)
typeof(3.14)
typeof(4545L) # any  number suffixed with L is an integer
typeof(78i)# any  number that has i - img part is a complex number
typeof(6+78i)
typeof(6L+78i)

# Character
typeof("Company name")
typeof('Company name')
typeof("The product's price is Rs.273")
typeof('The CEO said,"Lets expand our business", a loud applaud...')

#Logical
typeof(TRUE)
typeof(FALSE)


# Variables
x=4545
class(x)
y=90L
class(y)
z=3+4i
class(z)
m="Hello"
class(m)
isAvailable=TRUE
class(isAvailable)


name=readline(prompt="Enter ur Name : ")
age=readline(prompt="Enter ur Age : ")
print(paste(name,"is",age,"years old"),quote = FALSE)


x<-5
print(x)
# = is used for key value pairs
# for data structures, = has a different purpose

# Assignment Operators =,<-,<<-,->,->>
count=50
age<-90
70->marks

company<-"Capgemini"
"Capgemini"->company

# <<- and ->> are used to assign variables in parent environment 
# Example in Function

n1<-8
n2<-3
print(n1+n2)
print(n1-n2)
print(format(n1*n2,nsmall = 3))
print(n1/n2)
print(n1%/%n2)
print(n1^n2)
print(n1%%n2)

sprintf("The result %d*%d =%3.4f",n1,n2,n1*n2)

print(n1==n2)
print(n1>n2)

m1<-c(3,0,9,8,0,2)
m2<-c(1,8,0,4,0,7)
m1|m2
m1&m2

m1||m2
m1&&m2

salary=78775
class(salary)

age=45L
class(age)

ops=6+5i
class(ops)

isValid=TRUE
class(isValid)

name="Johnny"
class(name)

# Conversion between data types

# Converting decimal values
count=89
class(count)
c1<-as.integer(count)
print(c1)
class(c1)

c2<-as.character(count)
print(c2)
class(c2)

c3<-as.logical(count) #0 -FALSE and non Zero-TRUE
print(c3)
class(c3)

c4<-as.complex(count)
print(c4)
class(c4)

as.logical(-546)

# Conversion of Character values
ch="434"
as.integer(ch)

ch="J"
as.integer(ch)

ch="Hello"
as.integer(ch)

ch="434"
as.complex(ch)

ch="434"
as.logical(ch)

ch="welcome"
as.logical(ch)

ch="T"
as.logical(ch)
ch="F"
as.logical(ch)
ch="TRUE"
as.logical(ch)
ch="FALSE"
as.logical(ch)
# TRUE=T, FALSE=F

# Convert logical values
n1<-FALSE
as.integer(n1)
as.complex(n1)
as.character(n1)

# Character functions
msg="Please check in by 12 noon"
name="Suraj"
paste("Mr.",name," Message : ",msg)

sprintf("Mr.%s has a  message : %s",name,msg)

salary=345345.34

sprintf("Mr.%s earns Rs.%5.2f",name,salary)

age=25L
sprintf("Mr.%s is %d years old",name,age)

# Substring functions
txt<-"This session is going to introduce you to R"
substr(txt,6,15)
substring(txt,6,15)

substr(txt,6)#No default stop value
substring(txt,6)

txt1<-"The rain in spain stays in the plain that gives you gain"
sub("ain","*****",txt1)
sub("AIN","*****",txt1)
#Ignore case - case insesitive match
sub("AIN","*****",txt1,ignore.case = TRUE)
#Replace all occurances
gsub("ain","*****",txt1)
gsub("AIN","*****",txt1,ignore.case = TRUE)

txt2<-"It is better that my better day for you to better on your betterment"
gsub("better","******",substring(txt2,29))

sub("better","******",txt2)

txt="Explain an explicit example in extraordinary way"
#Find all occurances of "ex" in txt and replace all occurances with "--"
gsub("ex","--",txt)
#Find all occurances of "ex" case insenstive way in txt and replace all occurances with "--"
gsub("ex","--",txt,ignore.case = TRUE)


ip="C:\\Users\\admin\\Downloads\\R"
print(ip)
op<-strsplit(ip,"([\\])")
print(op)

op1<-strsplit(ip,"\\")
print(op1)


ip="C:-Users-dmayur-Downloads-R"
print(ip)
op<-strsplit(ip,"-")
print(op)
x <- c("a", "b", "c")
as.numeric(x)
