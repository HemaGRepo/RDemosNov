#While Loop - 0 or more times
cntr<-1
while(cntr<10)
{
  print(cntr)
  cntr<-cntr+1
}

#While Loop - 1 or more times
cntr<-1
repeat
{
  if(cntr>=10)
    break;
  print(cntr)
  cntr<-cntr+1
}



#Repeat loop
v <- c("Hello","loop")
cnt <- 2

repeat {
  if(cnt > 5) {
    break
  }
  print(v)
  cnt <- cnt+1
}

v <- LETTERS[1:6]
for ( i in v) {
  
  if (i == "D") {
   # print("Cannot Proccess D....")
    next
  }
  print(i)
}

repeat{ # Infinite loop
  print("Hai")
}

cntr<-1
repeat{
  print("Hai")
  if(cntr==10)
    break;
  cntr<-cntr+1
}












