#Numeric Constants

#Every number is a double number
score<-123
typeof(score)

# L indicates it is an integer
empid<-101L
typeof(empid)

score<-123L
typeof(score)

price<-478.34L
typeof(price)

#Complex number -i

c1<-45+8i
typeof(c1)
Re(c1)
Im(c1)

c2<-11i
typeof(c1)
Re(c2)
Im(c2)

#Typeof is used to check the type of value assigned to a variable
#In R everything u create is an object

class(price) # Double -> numeric
class(score) # integer ->integer
class(c1) # complex-> complex

#class(data.frame("ids"=101:120))

#Logical Values

isAvailable<-TRUE
inStock<-FALSE
is.logical(isAvailable)

typeof(isAvailable)
class(isAvailable)


#Character - "" or '' is a character
name<-"Capegemini"
msg<-"Sam's pen is missing"
quot<-'The Leader said "Do or Die", thats great'
m1<-'Thank You'
discount<-"10.25"
status<-"TRUE"

typeof(discount)

typeof(status)


#Character functions
sprintf("%s has %3.5f Dollars",name,price)

s1<-"Today she went to a place that was awesome. The place is ..."
substr(s1,start =2 ,stop = 15)
substr(s1,start =6 )

s2<-"The rain in Spain mostly stays in the plain and gives GAIN not PAIN"

sub("ain","-----",s2) # First match of ain will be replaced

gsub("ain","-----",s2) # All match of ain will be replaced

gsub("ain","-----",s2,ignore.case = TRUE) # All match of ain will be replaced in case insesitive manner

sub("AIN","-----",s2)
sub("AIN","-----",s2,ignore.case = TRUE)

nchar(s2)
nchar(m1)

substr(s2,start=5,stop=nchar(s2))


#Conversion functions

#Decimal to Others

price<-46757.34
typeof(price)

i1<-as.integer(price)
print(paste(i1,typeof(i1)))

i2<-as.complex(price)
print(paste(i2,typeof(i2)))

i3<-as.character(price)
print(paste(i3,typeof(i3)))

#0 means FALSE and all others are TRUE
i4<-as.logical(price)
print(paste(i4,typeof(i4)))

as.logical(0)
as.logical(-87)

#Integer to Others

price<-46757L
typeof(price)

i1<-as.numeric(price)
print(paste(i1,typeof(i1)))

i2<-as.complex(price)
print(paste(i2,typeof(i2)))

i3<-as.character(price)
print(paste(i3,typeof(i3)))

#0 means FALSE and all others are TRUE
i4<-as.logical(price)
print(paste(i4,typeof(i4)))

as.logical(0)
as.logical(-87)

#Complex to Others

price<-89+5i
typeof(price)

i1<-as.numeric(price)
print(paste(i1,typeof(i1)))

i2<-as.integer(price)
print(paste(i2,typeof(i2)))

i3<-as.character(price)
print(paste(i3,typeof(i3)))

#0 means FALSE and all others are TRUE
i4<-as.logical(price)
print(paste(i4,typeof(i4)))

as.logical(9+0i)
as.logical(0+8i)
as.logical(0+0i)

#Characters to Others

price<-"Subject to Taxes"
typeof(price)

i1<-as.numeric(price)
print(paste(i1,typeof(i1)))

i2<-as.integer(price)
print(paste(i2,typeof(i2)))

i3<-as.complex(price)
print(paste(i3,typeof(i3)))

#0 means FALSE and all others are TRUE
i4<-as.logical(price)
print(paste(i4,typeof(i4)))


price<-"81"
typeof(price)

i1<-as.numeric(price)
print(paste(i1,typeof(i1)))

i2<-as.integer(price)
print(paste(i2,typeof(i2)))

i3<-as.complex(price)
print(paste(i3,typeof(i3)))

#0 means FALSE and all others are TRUE
i4<-as.logical(price)
print(paste(i4,typeof(i4)))



price<-"F"
typeof(price)

i1<-as.numeric(price)
print(paste(i1,typeof(i1)))

i2<-as.integer(price)
print(paste(i2,typeof(i2)))

i3<-as.complex(price)
print(paste(i3,typeof(i3)))

#0 means FALSE and all others are TRUE
i4<-as.logical(price)
print(paste(i4,typeof(i4)))




