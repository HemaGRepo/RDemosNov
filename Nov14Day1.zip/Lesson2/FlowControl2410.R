# If statement

salary<-readline(prompt = "Enter Your salary: ")

if(salary>50000){
  print("Thats Good")
}else{
  print("Earn More")
}

# If else if statement
score<-readline(prompt = "Enter Your score in R assessment[0-100] : ")
if(score>=90){
  level<-"expert"
}else if(score>=75){
  level<-"proficient"
}else if(score>=60){
  level<-"practitioner"
}else if(score>=40){
  level<-"knowledgable"
}else{
  level<-"Needs Practice"
}

print(paste("Your score : ",score,"- Your Skill : ", level))

# for each

scores<-c(34,98,56,73,66)

for(score in scores){
  if(score>=90){
    level<-"expert"
  }else if(score>=75){
    level<-"proficient"
  }else if(score>=60){
    level<-"practitioner"
  }else if(score>=40){
    level<-"knowledgable"
  }else{
    level<-"Needs Practice"
  }
  print(paste("Your score : ",score,"- Your Skill : ", level))
  print("---------------------------------------")
}

# While loop

cntr<-0

while(cntr<10){
  print(paste("This is a counter...",cntr),quote = FALSE)
  temp<-cntr*2
  print(paste("This is temp...",temp),quote = FALSE)
  print("---------------------------------------")
  cntr<-cntr+1
}

# Break
cntr<-0
while(cntr<10){
  print(paste("This is a counter...",cntr),quote = FALSE)
  if(cntr==5)
    break
  temp<-cntr*2
  print(paste("This is temp...",temp),quote = FALSE)
  print("---------------------------------------")
  cntr<-cntr+1
}

# next
cntr<-0
while(cntr<10){
  cntr<-cntr+1
  print(paste("This is a counter...",cntr),quote = FALSE)
  if(cntr==5)
    next
  temp<-cntr*2
  print(paste("This is temp...",temp),quote = FALSE)
  print("---------------------------------------")
}

#repeat

cntr<-0

repeat{
  print(paste("This is a counter...",cntr),quote = FALSE)
  temp<-cntr*2
  print(paste("This is temp...",temp),quote = FALSE)
  print("---------------------------------------")
  cntr<-cntr+1
  if(cntr==10) break;
}





















