# if statement

location<-"Mumbai"

#if
if(location=="Pune"){
  print("You can participate")
}

#if else
if(location=="Pune"){
  print("You can participate")
}else{
  print("You cannot participate")
}

#if..else if

salary<-as.integer(readline("Enter your salary: "))

if(salary<100000){
  tax<-0
}else if(salary<250000){
  tax<-10*salary/100
}else if(salary<400000){
  tax<-20*salary/100
}else if(salary<500000){
  tax<-30*salary/100
}else{
  tax<-40*salary/100
}

print(paste("The tax for your salary of Rs.",salary, "is Rs.",tax),quote = FALSE)

# For loop
n1<-5:12
print(n1)

for(temp in n1){
  print(paste("The value is ",temp),quote=FALSE)
}

salaries<-c(300000,700000,459888,120000,600000,222222)

for(salary in salaries){
  #Calculate the tax for the salary
  #If salary>550000 do not calculate tax
  
  if(salary>550000){
    print("Found a salary > 550000...Skipping....")
    print("................")
    break;
    }
  
  if(salary<100000){
    tax<-0
  }else if(salary<250000){
    tax<-10*salary/100
  }else if(salary<400000){
    tax<-20*salary/100
  }else if(salary<500000){
    tax<-30*salary/100
  }else{
    tax<-40*salary/100
  }
  print(paste("The tax for your salary of Rs.",salary, "is Rs.",tax),quote = FALSE)
  print("---------------------------------------------")
  
}


# While loop

lVar<-1
while(lVar<=10){
  if(lVar==5){lVar<-lVar+1;break;}
  print(paste("Hello",lVar))
  lVar<-lVar+1
}



# Repeat loop
cntr<-0
repeat{
  print("Hello")
  cntr<-cntr+1
  if(cntr>10)
    break
}








