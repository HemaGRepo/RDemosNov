 marks<-c(23,45,67,89,10)
 for(temp in marks){
    if(temp<50)
    {
           print(paste(temp,"FAIL"))
    }
    else
    {
      print(paste(temp,"PASS"))
    }
 }
 
 
 cntr<-1
 while(cntr<10){
   if(cntr==5)
   {
     cntr<-cntr+2
     next;
   }
   print(paste(cntr,"The square is:",cntr^2),quote=FALSE)
   cntr<-cntr+1
 }
 

 
rcntr<-10
repeat{
  print(paste(rcntr,"The square is:",rcntr^2),quote=FALSE)
  rcntr<-rcntr+1
  if(rcntr==17)
    break
}
 
 
 
 
 
 
 