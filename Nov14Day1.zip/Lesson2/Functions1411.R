# Functions in R

# Simple functio - no return type, no parameters

printValues<-function(){
  x<-10
  print(paste("The value of x is ",x),quote=FALSE)
}

printValues()

# Functions with parameters

checkNumber<-function(n1){
  if(n1%%2==0)
    print(paste("The number",n1,"is Even"))
  else
    print(paste("The number",n1,"is Odd"))
}

checkNumber(7)
checkNumber(10)
edit(printValues)


#Functions with many parameters
doCalc<-function(a,b,c,d){
  n1<-c+a
  n2<-b*d
  res<-n1+n2
  print(paste(a,b,c,d,sep=","))
  print(paste("The result is ",res))
}

doCalc(5,2,10,8) # Positional notation
doCalc(c=5,b=6,d=7,a=2) # Named notation
doCalc(b=10,d=3,7,4)# remaining is a,c, so 7 and 4 are assigned


#Functions with default parameters
doCalc<-function(a,b=6,c=8,d){
  n1<-c+a
  n2<-b*d
  res<-n1+n2
  print(paste(a,b,c,d,sep=","))
  print(paste("The result is ",res))
}

doCalc(1,5,2,8)
doCalc(a=10,d=3)
doCalc(2,4) # Positional notation a=2, b=4, c=Default(8), d
doCalc(2,,,4)

#Lazy function

f1<-function(a,b){
  n1<-a^2
  print(paste("The value of a=",a))
  print(paste("The result is ",n1))
  print(paste("The value of b=",b))
}

f1(5)

# Return values - By default every R function returns the value of the last statement

doCalc<-function(a,b,c,d){
  n1<-c+a
  n2<-b*d
  res<-n1+n2
  print(paste(a,b,c,d,sep=","))
  print(paste("The result is ",res))
  n3<-10*a+c
}


r1<-doCalc(1,2,3,4)
print(r1)

doCalc<-function(a,b,c,d){
  n1<-c+a
  n2<-b*d
  res<-n1+n2
  print(paste(a,b,c,d,sep=","))
  print(paste("The result is ",res))
  n3<-10*a+c
  return(n1)
}

r1<-doCalc(1,2,3,4)
print(r1)

#Recursive functions

factFunction<-function(n){
  if(n==0) return(1)
  else return(n*factFunction(n-1))
}

factFunction(5)



temp<-function(){
  n1<-10
  n2<-40
  res<-10+40
  return(n1)
  print("test")
}

r1<-temp()
print(r1)

# Nested functions <<-, ->>

# For every function the global environment is the parent

f1<-function(){
  a<-10 # Function scope
  b<<-20 # Parent scope - global enviro
  30->>c1 # Parent scope - global enviro
}

f1()

print(b)


#<<- , ->> is used to assign values to variables in parent scope

f1<-function(){ # For f1, Global enviro is the parent
  a<-10
  b<-20
  print("--------Function f1 starts---------")
  print(paste(" a = ",a)) #a=10
  print(paste(" b = ",b)) #b=20
  
  #nested function
  f2<-function(){ # For f2, f1 is the parent
     a<-50 # In f2, we create a variable a, in F2's scope
     b<<-83 # Assign the value b in parent's scope to 83
     print("--------Function f2 starts---------")
     print(paste(" a = ",a)) #a=50
     print(paste(" b = ",b)) #F1's b=83
     print(get(x='a',envir =parent.env(environment())))
     print("--------Function f2 ends---------")
  }
  f2()
  print("--------Function f1 starts---------")
  print(paste(" a = ",a)) #a=10
  print(paste(" b = ",b)) #b=83
  
}


f1()


# Predefined functions in R
# String related functions

msg<-"Welcome to the basics of R"
nchar(msg)

substr(msg,5,12)
sub(pattern = "a",replacement = "A",x = msg)
sub(pattern = "o",replacement = "------",x = msg) # replace the first occurance of "o"
gsub(pattern = "o",replacement = "------",x = msg) # replace all occurance of "o"

t1<-"The rain in SPAIN stays mainly in the plain and gives gain "

sub("ain","000",t1)
gsub("ain","000",t1)
gsub("ain","000",t1,ignore.case = TRUE)

install.packages("stringi")

install.packages("stringr") #One time activiy

library(stringr)

sentences <- c("Jane saw a cat", "Sam sat down")
word(sentences, 1)
word(sentences, 2)
word(sentences,-1)
word(sentences, 2, -2)

salary<-c(2345,977,5646,3777,8366,100)
min(salary)
max(salary)
range(salary)
sum(salary)
mean(salary)

summary(salary)
prod(salary)

sal<-c(2,3,4)
prod(sal)

ch<-5
switch(ch,min(salary),max(salary),sum(salary),range(salary),print("Thank U"))

#Generating sequences
8:24
seq(6)
seq(10,30)
seq(4,80,by = 5)
seq(4,80,length.out = 6)
seq_len(8)
sequence(12)

rep("Hello",4)

rep(8,3)

rep(c(3,90,45,23),2)

rep(c(5,3),c(10,4))


dummy<-function(){
  
}
dummy()

















