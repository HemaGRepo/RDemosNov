#No params No return
sumOfNum<-function(){
  num1<-10
  num2<-20
  num3<-num1+num2
  print(paste("The sum of Numbers is : ",num3))
}

#No params No return
gSummer<-function(){
  #n1 and n2 are created in Parent scope
  n1<<-10
  n2<<-20
  #n3 is created in local scope
  n3<-n1+n2
  print(paste("The sum of Numbers is : ",n3))
}

#No params No return - nested functions
f1<-function(){
  v1<-10
  print(paste("In f1"," v1 =",v1))
  v2<-20
  print(paste("In f1"," v2 =",v2))
    f2<-function(){
      v1<-30
      print(paste("In f2"," v1 =",v1))
      v2<<-40
      print(paste("In f2"," v2 =",v2))
    }
  f2()
  print(paste("In f1"," v1 =",v1))
  print(paste("In f1"," v2 =",v2))
}

f1()















