# 5 types of variables

# Numeric - Double, Integer, Complex

# All numbers in R are by default Double
#Double

salary=34566
typeof(salary)
class(salary)

discount=456.34
typeof(discount)

#Integer - Suffix with L

empid=478L
typeof(empid)
class(empid)

#Complex - Real and imaginary part
formula=18+4i
typeof(formula)
class(formula)
Re(formula)
Im(formula)

# Character
message1="This is the first example"
typeof(message1)
class(message1)

userError='This is the exact screenshot of the page'
typeof(userError)
class(userError)

status="This is Kavin's pen"
print(status)

msg='Gandhiji said "Do or Die", Lets follow it...'
print(msg)

# Logical - TRUE,FALSE,T,F

inStock=TRUE
typeof(inStock)
class(inStock)

withdrawAllowed=F
typeof(withdrawAllowed)

sal=567777788823923929392392939293

#Please do not use
name=readline(prompt = "Enter ur Name : ")
loc=readline(prompt="Enter ur location: ")

# Conversion 

#Decimal to other types
salary=34567.67
typeof(salary)

i1=as.integer(salary)
c1=as.complex(salary)
s1=as.character(salary)
l1=as.logical(salary)# 0 is FALSE and others are TRUE

#Integer to other types
salary=9854L
typeof(salary)
d1=as.numeric(salary)
c1=as.complex(salary)
s1=as.character(salary)
l1=as.logical(salary)

n1=0L
l2=as.logical(n1)
c2=as.complex(n1)


#Complex to other types
salary=9854+100i
typeof(salary)
d1=as.numeric(salary)
i1=as.integer(salary)
s1=as.character(salary)
l1=as.logical(salary)

c1=90+0i
l2=as.logical(c1)

c1=0+34i
l2=as.logical(c1)

c1=0+0i
l2=as.logical(c1)

# Characters to other types

s1="Hello"
d1=as.numeric(s1)
i1=as.integer(s1)
c1=as.complex(s1)
l1=as.logical(s1)

s1="568.89"
d1=as.numeric(s1)
i1=as.integer(s1)
c1=as.complex(s1)
l1=as.logical(s1)

s1="TRUE"
d1=as.numeric(s1)
i1=as.integer(s1)
c1=as.complex(s1)
l1=as.logical(s1)

# Logical values

s1=FALSE
d1=as.numeric(s1)
i1=as.integer(s1)
c1=as.complex(s1)
l1=as.character(s1)

is.integer(s1)

is.integer(i1)

#Arithmetic
x=45
y=12

x+y
x-y
x*y
x/y
y^2
x%%y  # Reminder of division
x%/%y # Quotient of division

amount=3456
withdraw=5000

amount!=withdraw

l1=T
l2=F
!l1

l1&l2
l1|l2

#Assignment Operators(=, ->, ->>, <-, <<-)

#x=45
x<-45
#y<-20
20->y

# <<- and ->> , Assign values to variables in Parent environment
# When we learn functions we will see <<- and ->>


salary<-c("John"=9000,"Mark"=34566,"Sam"=12000,"Kate"=8732)
print(salary)


#salary<-c("John"<-9000,"Mark"<-34566,"Sam"<-12000,"Kate"<-8732)
#print(salary)

0:6







