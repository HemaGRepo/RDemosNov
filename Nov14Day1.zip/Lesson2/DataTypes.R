#Datatypes
#Logical

v <- 23.5 
print (class(v))

#Numeric

v1 <- 23.5
print (class(v1))

#Integer

v2 <- 2L
print (class(v2))

#Complex

v3 <- 2+5i
print (class(v3))

#Character

v4 <- "TRUE"
print(class(v4))


# Create a vector.
apple <- c('red','green',"yellow")
print (apple)

# Get the class of the vector.
print (class(apple))

val1<-4+8i
val2<-8+4i

x=10
y=7
formula<-10x+4y+8
print(val1+val2)

as.integer(val1)
as.character(val1)
as.logical(val1)




