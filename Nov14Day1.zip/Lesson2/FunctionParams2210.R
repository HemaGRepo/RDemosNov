# Functions with params
sumOfNumParams<-function(num1,num2){
  num3<-num1+num2
  print(paste("The sum of Numbers is : ",num3))
}

sumofNos<-function(a,b,c)
{
  #n1 as a free form variable
  res<-(a*b)+(c-n1)
  print(paste("The sum of Numbers is : ",res))
}

sumofNos(5,3,45)

sumofNos(c=90,a=12,b=3)

sumofNos(c=70,6,2)


calculate<-function(a=8,b,c=30)
{
  #n1 as a free form variable
  res<-(a*b)+c
  print(paste("The Result is : ",res))
}

calculate(2,3)

calculate(5)

calculate(b=5)

calculate(,4,)

calculate(,3,)

# Return value in Function
# Every function in R will return the result of the last statement executed
f3<-function(a,b,c){
  res3<-c*c
  res1<-a*2
  res2<-b+b
}

r1<-f3(5,6,9)
print(r1)



# Return value in Function
# Every function in R will return the result of the last statement executed
f4<-function(a,b,c){
  res3<-c*c
  res1<-a*2
  res2<-b+b
  
  return()
}

r1<-f4(5,6,9)
print(r1)

compute<-function(a,b){
  res2<-b+5
  print(paste("The result of b+5 is",res2))
  print("Thank You")
  print("I am starting to search a....")
  res<-a*2
  print(res)
  
}

compute(,12)










