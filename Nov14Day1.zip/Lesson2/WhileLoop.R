#while loop

v <- c("Hello","while loop")
cnt <- 2

while (cnt < 7) {
  print(v)
  cnt = cnt + 1
}


salary<-c(56565,43434,89897,23423,8965)

cnt<-length(salary)
print(cnt)

cntr<-1

while(cntr<=cnt)
{
  print(paste("The salary is :",salary[cntr]))
  #No PF if salary>50000
  if(salary[cntr]>50000)
  {
    cntr=cntr+1
    break;
  }
  PF=salary[cntr]*12/100;
  print(paste("The PF is :",PF))
  print("-----------------------")
  cntr=cntr+1
}


vals<-1:10
cntr<-1
while(cntr<=10)
{
  print(vals[cntr])
  if(cntr>5)
  {
    print("The value is 5")
    break;
  }
  cntr=cntr+1
}


marks<-c(89,78,65,20,40,88)
cntr<-1
while(cntr<=length(marks))
{
  temp<-marks[cntr]
   if(temp<50) break;
  print(paste("Processing the mark",temp))
  cntr=cntr+1
}


marks<-c(89,78,65,20,40,88)
cntr<-1
while(cntr<=length(marks))
{
  temp<-marks[cntr]
  if(temp<50){ 
    print("Found a mark < 50...skipping")
    cntr=cntr+1;
    next;
    }
  print(paste("Processing the mark",temp))
  cntr=cntr+1
}


salary<-c(56565,43434,89897,23423,8965)
cntr=1
cnt=length(salary)
while(cntr<=cnt)
{
  if(salary[cntr]>70000)
  {
    cntr=cntr+1
    next
  }
  print(salary[cntr])
  cntr=cntr+1
}

weight<-c(78,34,56,90,89,100,42)
cntr<-1
len<-length(weight)
while(cntr<=len)
{
  w1<-weight[cntr]
  print(paste("Weight is :",w1))
  if(w1<50){print("Under weight") }
  else if(w1<90){print("Normal")}
  else{print("Over weight")}
  cntr=cntr+1
}


# Find a person who is overweight and print the value
weight<-c(78,34,56,90,89,100,42)
cntr<-1
len<-length(weight)
while(cntr<=len)
{
  w1<-weight[cntr]
  print(paste("Weight is :",w1))
  if(w1>=90)
  {
    print("Found a person who is overweight............ Come out of loop")
    break; # Terminate the loop
  }
  cntr=cntr+1
}

# Select only people who are not overweight
# next- do not do the steps for the current element and move to next element
weight<-c(78,34,56,90,89,100,42)
cntr<-1
len<-length(weight)
while(cntr<=len)
{
  w1<-weight[cntr]
  cntr=cntr+1
  if(w1>=90)
  {
   next;# go to the next iteration in the loop
  }
  print(paste("Weight is :",w1))
  print("Selected")
}









