#No argument and No return
findResult<-function()
{
  num1<-10;
  num2<-20;
  print(num1+num2)
}

#Argument and No return
findSum<-function(x,y)
{
 sumXY<-x+y;
 print(paste("The sum of ",x,"and",y,"is",sumXY),quote=FALSE)
}

findSum(89,34)
findSum(10,90)

#No argument and return
returnResult<-function()
{
  num1<-10;
  num2<-20;
  return(num1+num2)
}

res<-returnResult()


#Argument and return
sumResult<-function(x,y)
{
  sumXY<-x+y;
  return(sumXY)
}

sumRes<-sumResult(67,34)
print(sumRes)


Outerf1<-function()
{
  x<-10; #Outer x
  print(paste("X from outer =",x))
  innerf1<-function()
  {
    y<-20;#Inner X
    print(paste("Y from inner =",y))
    y<-25;
    print(paste("Y from inner =",y))
    x<<-100;
    print(paste("X from inner =",x))
  }
  innerf1()
  print(paste("X from outer =",x))
}

  
  
  
  
  
  
  
  
  
  



















