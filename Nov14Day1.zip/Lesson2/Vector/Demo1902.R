salary<-c(23454,12787,89765,45674,67321,90909,30000)
print(salary)
typeof(salary)

courses<-c("R","Big Data","Hadoop","DevOps","Cloud")
print(courses)
typeof(courses)
length(courses)

v1<-c(9,45,"Hai","Welcome")
print(v1)

v2<-c(8,34,TRUE,FALSE)
print(v2)

v3<-c(8,34,TRUE,FALSE,"Thank u")
print(v3)

vec1<-45:67
print(vec1)

vec2<-seq(34,50,by=2)
print(vec2)

vec3<-rep(5,10)
print(vec3)

vec4<-c(1:5,rep(8,3),seq(10,15),c(44,36,78,90))
print(vec4)

marks<-c(89,34,56,78,10,20,87,39,27,100,69,44,29)
print(marks)

marks[1]
marks[5]
marks[c(2,4,8)]
marks[-3]
marks[c(-1,-2,-3,-4)]
marks[c(-1,-2,-6,-8)]
marks[c(1,-3)]#Invalid
length(marks)
marks[c(T,T,F,F,F,T,F,F,F,T,T,F,F)]#89,34,20,100,69
marks[c(TRUE,FALSE)]#TRUE,FALSE,TRUE,FALSE,TRUE,FALSE,TRUE,FALSE,TRUE,FALSE,TRUE,FALSE,TRUE,FALSE

salary<-c(23454,12787,89765,45674,67321,90909,30000)
print(salary)
typeof(salary)

names(salary)<-c("Joe","Tim","Jack","Smith","Allen","Mark","Tom")
print(salary)
salary["Tom"]
salary[c("Jack","Tom")]


sales<-c(34,56,78,12,34,56,78,90,34,78,90,12)
names(sales)<-month.abb
print(sales)
sales[c(1:6)]
sales["Feb"]
sales[c("Mar","Jun","Sep","Dec")]
# Print sales for all months except Feb

product<-c("TV"=8989,"Mobile"=6565,"Book"=345,"Pen"=20)
print(product)
product[names(product)!="TV"]


marks<-c(89,34,56,78,10,20,87,39,27,100,69,44,29)
print(marks)
marks[3]<-40
print(marks)
marks[marks<60]<-100
print(marks)

marks<-c(89,34,56,78,10,20,87,39,27,100,69,44,29)
print(marks)
# Remove the 4th element from the vector
marks<-marks[-4]
print(marks)

v1<-c(3,5,6,7)
v2<-c(2,7,1,3)
v1+v2
v1-v2
v1*v2
v1/v2
v1*4

v1<-c(3,4,6,2,7,1,8,9)
v2<-c(5,10)# Recycle rule
v1+v2

v1<-c(3,4,6,2,7,1,8,9,6) # 9 ELEMENTS
v2<-c(5,10)# Recycle rule, 9 is not a multiple of 2
v1+v2

v1<-c(3,NA,6,7,0,NA,4,5)
v2<-c(2,NA,0,3,1,6,3,NA)
v1&&v2
v1&v2
v1|v2

v3<-c(v1,v2)
print(v3)

scores<-c(10,20,30,NA,40,50,NA)
min(scores,na.rm = TRUE)
max(scores,na.rm = TRUE)
sum(scores,na.rm = TRUE)
mean(scores,na.rm = TRUE)
which.min(scores)
which.max(scores)
range(scores,na.rm = TRUE)





















