# Create a vector - c()
rainfall<-c(45.6,34.9,90.8,12.7,56.6)
print(rainfall)
length(rainfall)

skills<-c("Java","Cloud","Angular","DevOps","Scrum","C#","R")
print(skills)
print(length(skills))

ids<-67:90
print(ids)

diceResults<-rep(7,12)
print(diceResults)

v1<-c(1:5,rep(7,3),12:56,c(20,42))
print(v1)

accId<-seq(100,200,by=4)
print(accId)

# Vector elements should be of same type
v2<-c(34L,"Hello",29.6)#R will convert everything to character
class(v2)
print(v2)

v3<-c(23,56,TRUE,FALSE)# R will convert everything to Numeric

class(v3)
print(v3)

v4<-c(34L,"Hello",29.6,TRUE,FALSE,"Thank U")#R will convert everything to character
class(v4)
print(v4)

# Accessing a Vector

r1<-c(6,2,9)
r2<-c(3,10,4)
r1+r2

#recycle rule repeat r2 3,10,4,3,10,4

r1<-c(6,2,9,10,23,17,20,100)
r2<-c(3,10,4)
r1+r2

#Accessing the vectors
marks<-c(67,34,10,78,89,23,56,34,49,54,83,60)
marks

# Accessing with positive integers
marks[1]
marks[4]
marks[c(2,6,8)]
marks[3:7]

# Access with negative integers
marks[-4]
marks[c(-1,-2,-3,-8)]
marks[-(1:3)]

# Cannot Access with both positive and negative integers
marks[c(4,-3)]

# Access with Logical integers
marks<-c(67,34,10,78,89,23,56,34,49,54,83,60)
marks

marks[c(TRUE,FALSE,TRUE,FALSE,TRUE,TRUE,FALSE,TRUE,FALSE,TRUE,FALSE,FALSE)]

deptid<-c(10,20,30,40)
deptid[c(T,F)]


salary<-c(56789,12345,65655,90909)
print(salary)
salary[c(1,3)]
salary[c(F,T)]

names(salary)<-c("Arun","Vijay","Sita","Leena")
print(salary)

salary["Sita"]

salary[c("Arun","Leena")]

scores<-c(67,23,45,90,12)
names(scores)<-c("Tim","Jack")
print(scores)
scores[1]
scores["Tim"]
scores[3]

accId<-c("Kavi"=102,"Ram"=34,"Shiv"=598,"Emma"=204)
accId

accId[2]<-290

marks<-c(67,34,10,78,89,23,56,34,49,54,83,60)
marks

marks[marks<30]<-50
marks

marks<-marks[1:5]

accId<-c("Kavi"=102,"Ram"=34,"Shiv"=598,"Emma"=204)
accId

accId<-c(accId[1:2],accId[4])
accId

accId<-accId[-3]
accId

accId<-accId[c(1,4)]


v1<-c(1,2,3,4)
v2<-c(7,5,0,11)
v1+v2
v1-v2
v1*v2
v1/v2
v1*4

v1&v2
v1|v2

v1&&v2
v1||v2

v3<-c(v1,v2)
print(v3)

marks<-c(67,34,10,78,89,23,56,34,49,54,83,60)
marks

sum(marks)
mean(marks)
min(marks)
max(marks)

range(marks)
sort(marks)
sort(marks,decreasing = TRUE)




