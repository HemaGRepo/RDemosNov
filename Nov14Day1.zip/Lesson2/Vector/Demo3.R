temp1<-c(19,89,78,45,100)
temp2<-c(65,22,81,49,34,12,9)
mean(temp2)
median(temp2)
sd(temp2)


temp3<-c(temp1,temp2)
print(temp3)

temp4<-c(temp1,45:50)
temp4

sort(temp3)
sort(temp3,decreasing = TRUE)

min(temp3)

which.min(temp3)

max(temp3)

which.max(temp3)

range(temp3)

sum(temp1)
mean(temp1)
prod(1:4)

temp4<-c(10,20,NA,80,NA,5,NA,35)
sum(temp4)
mean(temp4)
sd(temp4,na.rm = TRUE)


sum(temp4,na.rm =TRUE)
mean(temp4,na.rm = TRUE)
prod(temp4,na.rm = TRUE)






