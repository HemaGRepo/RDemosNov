# Vector

balance<-7500 # Numeric vector containing 1 element

username<-"John" # Character vector containing 1 element
length(username)
nchar(username)

#Create vector - c()

names<-c("Ram","Sita","Lakshman","Ravan","Krish")
nchar(names)
typeof(names)
class(names)
length(names)

scores<-c(230,187,320,190,267,282,300)

empid<-30:37
print(names)
print(scores)
print(empid)

accid<-seq(100,140,by=4)
print(accid)

dice<-rep(4,6)

v1<-c(1:3,rep(20,4),seq(12,25,by=3),c(75,9,44))
print(v1)

v2<-c("Hema",90,TRUE,89.34) # Automatic conversion
v3<-c(45.89,12L,TRUE)

rainfall<-c(12,8,13,26,10,18,20)
print(rainfall)
names(rainfall)<-c("Jan-18","May-18","Dec-17","Oct-17","Feb-16","Jun-18")
print(rainfall)
print(names(rainfall))

marks<-c("Arun"=78,"Rian"=54,"Sam"=99,"Steve"=30,"Laurel"=20)
print(marks)

products<-c("Pen"=90,"TV"=34566,"Mobile"=25435)
print(products)


print(state.name)
print(state.abb)
print(month.name)
print(month.abb)


#Accessing the elements


scores<-c(34,67,23,NA,90,78,NA,55,80,100,35)
#Positive index
scores[1]
scores[1:3]
scores[3:6]
scores[c(3,2,7)]
scores[c(1,5,3,4)]

#negative index
scores[-2] #All elements except the 2nd
scores[-c(1,2,3,8)]

scores[c(3,-4)]

#Logical index
scores[c(T,F)]
scores[c(T,T,F,T)]

#Condition
scores[scores<50]
scores[scores==100]
scores[scores>70]
scores[!is.na(scores)]

#Character name based

rainfall<-c(2,3,5,10,9,80,13,45,88,33,44,6)
names(rainfall)<-month.abb
print(rainfall)
rainfall[1:6]
rainfall[c(F,F,T)]
#rainfall is a named vector
rainfall["Oct"]
rainfall[c("Jan","Sep","Dec")]

marks<-c("Arun"=78,"Rian"=54,"Sam"=99,"Steve"=30,"Laurel"=20)
print(marks)

marks[c(2,4)]
marks[c("Laurel","Sam")]

scores<-c(230,187,320,190,267,282,300)

scores[4]
names(scores)[1:4]<-c("India","WI","SA","Oz")
print(scores)
print(names(scores[4]))

#Delete the mark of Sam
marks<-c("Arun"=78,"Rian"=54,"Sam"=99,"Steve"=30,"Laurel"=20)
print(marks)

marks<-marks[-3]
print(marks)

marks<-c(marks,c("Anu"=56,"Vivan"=23))
print(marks)


v1<-c(34,89,100,20)
v1<-c(v1,c(44,60,70))

print(rainfall)
rainfall[rainfall<10]<-20
print(rainfall)
rainfall[3]<-43
print(rainfall)

v1<-c(5,10,15)
v2<-c(3,9,18)
v3<-c(v1,v2)

names(v1)[2]<-"Sam"
print(v1)

names(v1)[1]<-"Sam"
print(v1)


# Functions on vectors

marks<-c("Arun"=78,"Rian"=20,"Anu"=NA,"Sam"=99,"Pranav"=NA,"Steve"=30,"Laurel"=20)
print(marks)

sum(marks,na.rm = TRUE)
min(marks,na.rm=TRUE)
max(marks,na.rm=TRUE)
mean(marks,na.rm=TRUE)
order(marks) # Index of ascending order
marks[order(marks)]

sort(marks)
sort(marks,decreasing = TRUE,na.last = TRUE)

which.min(marks)

#All people whose mark is min
marks[marks==min(marks,na.rm = TRUE)]

#Fetch marks in alphabetical order of names
sort(names(marks))
marks[sort(names(marks))]
marks[sort(names(marks),decreasing = TRUE)]

#+,-,*,/

v1<-c(3,5,6,0,9)
v2<-c(4,3)# 4,3,4,3

v1+v2
v1-v2
v1*v2
v1/v2
v1&&v2 # 3 && 4
v1&v2
v1||v2
v1|v2


empnames<-c("Ram","Sita","Lakshman","Ravan","Krish")
sort(empnames,decreasing = TRUE)

unique(names(v1))







