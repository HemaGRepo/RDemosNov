# Create a vector.
apple_colors <- c('green','green','yellow','red','red','red','green')

# Create a factor object.
factor_apple <- factor(apple_colors)

# Print the factor.
print(factor_apple)
print(nlevels(factor_apple))

marks<-c(89,78,65,43,23,10,89)
fmarks<-factor(marks)
print(fmarks)