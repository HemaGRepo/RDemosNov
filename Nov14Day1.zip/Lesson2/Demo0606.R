#Constants
#Character Constants
print("Hello")
print('Welcome')
print("This is Jane's Laptop")
print('Mark said,"I am not going to do this"...I was surprised')

typeof("Hello")
typeof('Welcome')
typeof("This is Jane's Laptop")
typeof('Mark said,"I am not going to do this"...I was surprised')

#Numeric constants
# 1) Decimal numbers - double

typeof(45)
typeof(78.34)
typeof(-5687)

# 2) Integer numbers - integer - L

typeof(45L)
#typeof(78.34L)
#print(78.34L)
typeof(-5687L)

# 3) Complex numbers - Has a real and imaginary part - i
typeof(9+3i) # 9-real part and 3-imaginary part
typeof(0+6i)
typeof(56i)
Re(56i)
Im(56i)
typeof(8+0i)
Re(9+3i)
Im(9+3i)

#Logical constant
typeof(TRUE)
typeof(FALSE)
typeof(T) # NOn zero is considered as TRUE
typeof(F) # 0 is considered as FALSE


copyright=readline(prompt="Enter your company name : ")
print(copyright)


age=readline(prompt="Enter your age : ")
print(age+10)


# Assignement Operator
# =, <-,->,<<-, ->>

#<- , -> Create a variable in the current enviornment 
x<-5
6->y

# = is used for naming a element

z=10 #<-, -> all are same

# When you create Data Structures
person<-list("name"="Ram","salary"=456666,"Desig"="SSE")

person1<-list("name1"<-"Ram","salary1"<-456666,"Desig1"<-"SSE")

list("name2"="Ram","salary2"=456666,"Desig2"="SSE")->person2

#<<- and ->> are used to create variables in the parent evironment
# TBD when we discuss functions

number1<-10
number2<-4
number1+number2
number1-number2
number1*number2
number1/number2
number1%%number2
number1%/%number2

balance<-67676
withdraw<-70000

age<-20

(balance>withdraw)&(age>18)
(balance>withdraw)|(age>18)

v1<-c(T,F,T,F)
v2<-c(F,F,T,T)

v1&v2 # 1st of v1 & 1st of V2, 2nd of v1 and 2nd of v2 etc...
v1&&v2 # 1st of v1 & 1st of V2

#Numeric variables

salary<-89898
typeof(salary)
class(salary)

empid<-101L
typeof(empid)
class(empid)

tax<-7+2i
typeof(tax)
class(tax)

gross<-salary-tax #89898+0i - (7+2i)

# Character variables

employeeName<-"Jack"
class(employeeName)

.password<-"Secret@123"
print(.password)

# Logical 
age<-13
isEligible<-(age>20)

#Conversion of variables

totalBill<-4567.84
is.numeric(totalBill)
is.integer(totalBill)

as.integer(totalBill)
as.complex(totalBill)
as.character(totalBill)
as.logical(totalBill)

quantity<-25L
as.numeric(quantity)
as.complex(quantity)
as.character(quantity)
as.logical(quantity)

oquantity<-88+4i
as.numeric(oquantity)
as.integer(oquantity)
as.character(oquantity)
as.logical(oquantity)
as.logical(88+0i)
as.logical(0+4i)
as.logical(0+0i) #FALSE

#Converting character

msg<-"Capgemini"
as.numeric(msg)
as.integer(msg)
as.complex(msg)
as.logical(msg)

msg<-"89.45"
as.numeric(msg)
as.integer(msg)
as.complex(msg)
as.logical(msg)

msg<-"76"
as.numeric(msg)
as.integer(msg)
as.complex(msg)
as.logical(msg)

msg<-"15+4i"
as.numeric(msg)
as.integer(msg)
as.complex(msg)
as.logical(msg)

msg<-"TRUE"
as.numeric(msg)
as.integer(msg)
as.complex(msg)
as.logical(msg)

msg<-"T"
as.numeric(msg)
as.integer(msg)
as.complex(msg)
as.logical(msg)

msg<-"0"
as.numeric(msg)
as.integer(msg)
as.complex(msg)
as.logical(msg)

#Converting Logical
l1<-TRUE
as.numeric(l1)
as.integer(l1)
as.complex(l1)
as.character(l1)

as.numeric(-25L)
as.logical(67)

empNames<-c("Ram","Sita","Suresh","Ravan")

ratings<-c(1,1,3,2)
f1<-function(x){if(x==1) return(TRUE) else return(FALSE)}
v1<-apply(ratings,f1(x))

v1<-c(T,T,F,F)

name<-"Stephen"
salary<-5000
#_______ earns $ ______ , (name, salary)
# %s ______- for string
# %d ______ - for double

sprintf("%s earns $ %d",name,salary)

msg1<-"This is a fair deal and I go ahead with it"
substring(msg1,first = 6, last=25)
substring(msg1,first = 6)
substring(msg1,last=25)

msg2<-"The rain in Spain stays mainly in the plain"
sub("ain","---",msg2) #First occurance
sub("AIN","---",msg2)
sub("AIN","---",msg2,ignore.case = TRUE)

gsub("ain","---",msg2) #All occurance

library(stringi)






