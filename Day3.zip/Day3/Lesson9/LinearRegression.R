#Regression Analysis

# Linear Regression Analysis
# Values of height - 151, 174, 138, 186, 128, 136, 179, 163, 152, 131

# Values of weight - 63, 81, 56, 91, 47, 57, 76, 72, 62, 48

height <- c(151, 174, 138, 186, 128, 136, 179, 163, 152, 131)#X
weight <- c(63, 81, 56, 91, 47, 57, 76, 72, 62, 48)#Y

# Apply the lm() function.
relation <- lm(weight~height)

# weight = -38.4551+0.6746*height 

print(0.6746*161 -38.4551)
print(relation)

print(summary(relation))

a <- data.frame(height = 161)
result <-  predict(relation,a)
print(result)

# Give the chart file a name.
png(file = "linearregression.png")

# Plot the chart.
plot(weight,height,col = "blue",main = "Height & Weight Regression",
     abline(lm(height~weight)),cex = 1.3,pch = 16,xlab = "Weight in Kg",ylab = "Height in cm")

# Save the file.
dev.off()

res<-read.csv("https://raw.githubusercontent.com/vincentarelbundock/Rdatasets/master/csv/datasets/AirPassengers.csv")
res

wages<-read.csv("https://raw.githubusercontent.com/vincentarelbundock/Rdatasets/master/csv/Ecdat/Bwages.csv")
wages

# Find the relationship between Wages and Experience

relWgExp<-lm(wages$wage~wages$exper)
print(relWgExp)

# Wages<-8.7349+0.1345*exp
# Find the wage for a person with exp 15 years

Wages5<-8.7349+0.1345*15

print(Wages5)









