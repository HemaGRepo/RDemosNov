#Multiple Regression

wages<-read.csv("https://raw.githubusercontent.com/vincentarelbundock/Rdatasets/master/csv/Ecdat/Bwages.csv")
wages

# Wage depends on Education and Experience

rel<-lm(wage~educ+exper,data = wages)
print(rel)

# Wage=1.0737+1.9304*educ+0.2007*exper
# Take a person with 15years of exp and educ is 1
Wage=1.0737+1.9304*1+0.2007*15
print(Wage)

# Take a person with 15years of exp and educ is 2
Wage=1.0737+1.9304*2+0.2007*15
print(Wage)

# Take a person with 20years of exp and educ is 2
Wage=1.0737+1.9304*2+0.2007*20
print(Wage)


input <- mtcars[,c("mpg","disp","hp","wt")]
print(input)
#print(mtcars)
input <- mtcars[,c("mpg","disp","hp","wt")]

# Create the relationship model.
# Response Variable - mpg
# Predictor variable - disp, hp,wt
# mpg=a+b1*disp+b2*hp+b3*wt
model <- lm(mpg~disp+hp+wt, data = input)

# Show the model.
# a=37.106, b1=-0.000937, b2=-0.0311, b3=-3.8008
# mpg = 37.105+(-0.000937)*disp+(-0.0311)*hp+(-3.8008)*wt
print(model)
summary(model)

# Get the Intercept and coefficients as vector elements.
cat("# # # # The Coefficient Values # # # ","\n")

a <- coef(model)[1]
print(a)

Xdisp <- coef(model)[2] #b1
Xhp <- coef(model)[3] #b2
Xwt <- coef(model)[4] #b3

print(Xdisp)
print(Xhp)
print(Xwt)
#Based on the above intercept and coefficient values, we create the mathematical equation.
#Y = 37.105+(-0.000937)*disp+(-0.0311)*hp+(-3.8008)*wt
#For a car with disp = 221, hp = 102 and wt = 2.91 the predicted mileage is ???
disp = 221
hp=102
wt=2.91
Y = 37.15+(-0.000937)*disp+(-0.0311)*hp+(-3.8008)*wt
print(Y)
#Y = 37.15+(-0.000937)*221+(-0.0311)*102+(-3.8008)*2.91 = 22.7104
