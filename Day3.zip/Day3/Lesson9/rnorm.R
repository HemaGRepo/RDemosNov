#rnorm-This function is used to generate random numbers whose distribution is normal. 
# Create a sample of 50 numbers which are normally distributed.
y <- rnorm(50, mean = 2.5, sd = 2)
print(y)
mean(y)
sd(y)
# Give the chart file a name.
#png(file = "rnorm.png")

# Plot the histogram for this samplep
plot(1:50,y, main = "Normal DIstribution")

mean(y)

# Save the file.
#dev.off()

scores<-rnorm(n = 100,mean=50,sd=25)

scores
mean(scores)
sd(scores)

plot(scores,type="l")

hist(scores)