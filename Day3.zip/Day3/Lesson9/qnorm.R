#qnorm- This function takes the probability value and gives a number whose cumulative value 
#matches the probability value.
# Create a sequence of probability values incrementing by 0.02.
x <- seq(0, 1, by = 0.02)

# Choose the mean as 2 and standard deviation as 3.
y <- qnorm(x, mean = 2, sd = 1)

# Give the chart file a name.
#png(file = "qnorm.png")

# Plot the graph.
plot(x,y)

# Save the file.
#dev.off()

prob<-c(0.10,0.20,0.30,0.40,0.50,0.60,0.70,0.80)
prob
y<-qnorm(prob,mean=50,sd=3)
print(y)

probs<-pnorm(y,mean=50,sd=3)
print(probs)

#Take the mark data and find the probability

marks<-c(34,56,99,12,67,82,63,49)
m<-mean(marks)
s<-sd(marks)

#Pnorm - probability of a person getiing less than 34, 56, 99 ,12,67,82,63,49 etc..
y<-pnorm(marks,mean=m,sd=s)
print(y)

# Dnorm will take the probability and find the mark
result<-qnorm(y,mean=m,sd=s)
print(result)



