#Values of height and weight is already there
print(women)
#Find the relationship between height and weight
height<-women$height
weight<-women$weight
rel<-lm(weight~height)
print(rel)

# Get the coefficents 
# Intercept= -87.52
# Beta 2 = 3.45
# Create a formula
# Weight=-87.52+3.45*height

#Question : height of a person is 70, what will be his weight
height1=70
weight1=-87.52+3.45*height1
print(paste("If height is 70, weight is ",weight1))


# You can do the same using predict
hData<-data.frame(height=70)
predict(rel,hData)

