print(women)

# Relationship between height and weight
weight<-women$weight
height<-women$height


res<-lm(weight~height)
print(res)
#summary(res)

# Find a formula weight=const1+const2*height+error
# From res u find that const1=-87.52 and const2=3.45  
ip<-data.frame(height=64)
wt<-predict(res,ip)
print(wt)

weight=-87.52+3.45*height

# Later if someone tells their height u can find their weight 
# Height of ram is 73, find his weight
weight=-87.52+3.45*65
print(weight)
