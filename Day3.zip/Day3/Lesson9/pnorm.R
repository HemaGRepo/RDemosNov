#pnorm()
#This function gives the probability of a normally 
#distributed random number to be less that the value of a given number. 
#It is also called "Cumulative Distribution Function".

# Create a sequence of numbers between -10 and 10 incrementing by 0.2.
x <- seq(-10,10,by = .2)

# Choose the mean as 2.5 and standard deviation as 2. 
y <- pnorm(x, mean = 2.5, sd = 2)

# Give the chart file a name.
#png(file = "pnorm.png")

# Plot the graph.
plot(x,y)

# Save the file.
#dev.off()

marks<-c(10,20,30,40,50,60,70,75,80,90)

# Given the marks - find the mean and sd
marks<-c(34,56,99,12,67,82,63,49)
m<-mean(marks)
s<-sd(marks)

#Pnorm - probability of a person getiing less than 34, 56, 99 ,12,67,82,63,49 etc..
y<-pnorm(marks,mean=m,sd=s)
y*100
plot(marks,y)

marks<-c(88,89,90,91,92,93,93,93,94,95,88,89,88,87,90,91,92)
m<-mean(marks)
s<-sd(marks)
y<-pnorm(marks,mean=m,sd=s)
y*100

