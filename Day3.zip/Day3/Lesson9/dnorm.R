# Create a sequence of numbers between -10 and 10 incrementing by 0.5.
x <- seq(-10, 10, by = .5)
#dnorm - This function gives height of the probability distribution at each point for a given mean and standard deviation.
# Choose the mean as 2.5 and standard deviation as 0.5.
y <- dnorm(x, mean = 2.5, sd = 0.5)
y

# Give the chart file a name.
#png(file = "dnorm.png")

marks<-c(rep(3,1),rep(9,8),rep(4,2),rep(7,6),rep(1,5))
marks
yMarks<-dnorm(marks,mean=8,sd=0.5)
yMarks

plot(marks,yMarks)

plot(x,y)

# Save the file.
#dev.off()


scores<-rnorm(n = 100,mean=50,sd=25)

scores

res<-dnorm(scores,mean=50,sd=25)
print(res)







