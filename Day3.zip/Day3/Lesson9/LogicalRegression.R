


#Logistic Regression

wages<-read.csv("https://raw.githubusercontent.com/vincentarelbundock/Rdatasets/master/csv/Ecdat/Bwages.csv")
wages

answer<-glm(formula=wage~educ+exper,data=wages)
print(summary(answer))

#Type of questions that a logistics regression can examine.
#How does the probability of getting lung cancer (yes vs. no) change for every
#additional pound of overweight and for every pack of cigarettes smoked per day?
#Do body weight ,calorie intake, fat intake, and participant age have an influence on heart attacks (yes vs. no)?
# Select some columns form mtcars.am represents automatic or manual

# Take the data from mtcars
# Does gear type depend on hp, disp, cyl and wt

result<-glm(formula=am~hp+wt+cyl,data=mtcars,family = binomial)
print(summary(result))


input <- mtcars[,c("am","cyl","hp","wt")]
print(input)

am.data = glm(formula = am ~ cyl + hp + wt, data = input, family = binomial)
#sink("logReg.txt")
print(summary(am.data))
#sink()

#In the summary as the p-value in the last column is more than 0.05 for the variables "cyl" and "hp",
#we consider them to be insignificant in contributing to the value of the variable "am".
#Only weight (wt) impacts the "am" value in this regression model.

model <- glm(formula= vs ~ wt + disp, data=mtcars, family=binomial)
summary(model)
newdata = data.frame(wt = 2.1, disp = 180)
predict(model, newdata, type="response")

#Derive the logistic regression formula
model_weight=glm(formula = vs ~ wt, family = binomial, data = mtcars)

# Take data for weight and predict the vs using the fomula - Calculated value or Theor value
xweight <- seq(0, 6, 0.25)
yweight <- predict(model_weight, list(wt = xweight),type="response")

# Plot actual wt~vs from mtcars
plot(mtcars$wt, mtcars$vs, pch = 16, xlab = "WEIGHT (g)", ylab = "VS")

# Draw a line for calculated wt~vs
#plot(xweight, yweight, pch = 12)
lines(xweight, yweight)











