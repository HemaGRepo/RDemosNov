# Linear regression
print(women)
#Weight is dependent on height
# Find the relationship between weight and height
lm(women$weight~women$height)
# Find the coefficients
# Constant - Intercept =-87.52
# Height Coeff = 3.45
# Create a formula
#weight=-87.52+3.45*height
# Find the weight of person whose height is 67
height=67
weight=-87.52+3.45*height
print(weight)

#Data reg experience and salary
exp<-seq(1,20,by=2)
print(exp)

salary<-c(1234,34545,45655,45554,56565,67676,76464,78778,88888,98989)

# Salary is based on experience
lm(salary~exp)
#Coefficents
#salary=13082+4635*exp

# If a person has exp=8, what should be his salary
exp=8
salary=13082+4635*exp
print(salary)

# If a person has exp=4, what should be his salary
exp=4
salary=13082+4635*exp
print(salary)

print(wages)
# Salary is based on education
lm(wages$wage~wages$educ)
# wage=6.185+1.440*educ

educ=3
wage=6.185+1.440*educ
print(wage)










