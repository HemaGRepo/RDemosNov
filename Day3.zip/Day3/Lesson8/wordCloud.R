library(wordcloud)

#Create a list of words (Random words concerning my work)
a=c("Cereal","WSSMV","SBCMV","Experimentation","Talk","Conference","Writing", 
    "Publication","Analysis","Bioinformatics","Science","Statistics","Data", 
    "Programming","Wheat","Virus","Genotyping","Work","Fun","Surfing","R", "R",
    "Data-Viz","Python","Linux","Programming","Graph Gallery","Biologie", "Resistance",
    "Computing","Data-Science","Reproductible","GitHub","Script")

#I give a frequency to each word of this list 
b=sample(seq(0,1,0.01) , length(a) , replace=TRUE) 

#The package will automatically make the wordcloud ! (I add a black background)
par(bg="black")
wordcloud(a,b,col="blue")
wordcloud(a , b , col=terrain.colors(length(a) , alpha=0) , rot.per=0.3 )


par(bg="white")
a=c("MOOC","COOC","SLP","UdaCity","courseera","edX",
    "canvas","NovoED","FutureLearn","Skillsoft","pluralsight","degreed",
    "Techademy"
    )
b=c(0.8,1,0.7,0.3,0.4,0.6,0.5,0.2,0.3,0.6,0.7,0.5,1)
wordcloud(a,b,col=blues9, rot.per=0.40  )




# generate pairs of x-y values
theta = seq(-2 * pi, 2 * pi, length = 300)
x = cos(theta)
y = x + sin(theta) 

# set graphical parameters
op = par(bg = "black", mar = rep(0.1, 4))

# plot
plot(x, y, type = "n", xlim = c(-8, 8), ylim = c(-1.5, 1.5))
for (i in seq(-2*pi, 2*pi, length = 100))
{
  lines(i*x, y, col = hsv(runif(1, 0.85, 0.95), 1, 1, runif(1, 0.2, 0.5)), 
        lwd = sample(seq(.5, 3, length = 10), 1))          
}

# signature
legend("bottomright", legend = "� Gaston Sanchez", bty = "n", text.col = "gray70")

# Colour graph

par(mar=c(0,0,0,0))
plot(0, 0, type = "n", xlim = c(0, 1), ylim = c(0, 1), axes = FALSE, xlab = "", ylab = "")
line=25
col=5
rect(  rep((0:(col - 1)/col),line) ,  sort(rep((0:(line - 1)/line),col),decreasing=T)   ,   rep((1:col/col),line) , sort(rep((1:line/line),col),decreasing=T),  border = "light gray" , col=colors()[seq(1,line*col)])
text(  rep((0:(col - 1)/col),line)+0.1 ,  sort(rep((0:(line - 1)/line),col),decreasing=T)+0.015 , colors()[seq(1,line*col)]  , cex=1)


library(plotly)
head(iris)
# left
plot_ly(iris, x = ~Petal.Length, y = ~Petal.Width , type="scatter", mode = "markers", 
        marker=list( size=20 , opacity=0.5), color = ~Sepal.Length)

# right
plot_ly(iris, x = ~Petal.Length, y = ~Petal.Width , type="scatter", mode = "markers", 
        marker=list( size=20 , opacity=0.5), color = ~Sepal.Length , 
        colors=c("green","blue") )
