# ggplot2 examples
library(ggplot2) 

employee<-data.frame(
  age=c(34,56,34,35,22,28,46,52,45,40,39,27),
  salary=c(23456,34567,76543,189898,54367,45363,67676,120909,245454,12987,34872,59345),
  exp=c(2,5,4,6,7,3,8,9,10,3,4,5),
  gender=c("M","F","M","F","M","F","M","F","M","F","M","F")
)

qplot(age,salary,data=employee)

ggplot(employee,aes(x=age,y=salary))+geom_point()

ggplot(employee,aes(x=age,
        y=salary,size=salary,colour=gender))+geom_point()

ggplot(employee,aes(x=age,
      y=salary))+geom_point()+facet_grid(employee$gender~.)

print(mtcars)
print(mpg)

attach(mtcars)
# Plot 1
ggplot(mtcars, aes(gear, mpg, colour = class)) +geom_point()

print(mpg$class)

#Plot yearsofExp vs Salary and show different colors for designation
employee<-data.frame(
  yearsOfExp=c(4,5,6,8,10,4,5,8,10,2,1),
  desig=c("SSE","SSE","AM","M","SE","SE","AM","M","M","SSE","SE"),
  salary=c(89787,13455,45665,23000,77345,63454,59898,94365,34566,42000,74000),
  gender=c("Female","male","Female","Female","Female","Female","male","male","male","male","Female")
  )
ggplot(employee, 
    aes(yearsOfExp, salary, colour = desig))+ geom_point()

ggplot(employee,
  aes(yearsOfExp, salary, colour = gender)) +geom_point()

#Plot the genderwise designation count
ggplot(employee,
       aes(gender, fill=desig ) ) +  
  geom_bar(position="dodge")

ggplot(employee,
       aes(gender, fill=desig ) ) +  
  geom_bar()

ggplot(employee,
       aes(desig,fill=gender))+geom_bar(position = "dodge")


ggplot(employee,aes(desig,fill=gender))+geom_bar()#Plot 2

#Plot yearsofExp vs Salary and show different colors for designation
emp<-data.frame(
  desig<-c("SSE","SSE","AM","M","SE","SE","AM","M","M","SSE","SE"),
  BU<-c("CSD","InD","Apps1","CSD","CSD","InD","InD","Apps1","InD","Apps1","Apps1"),
  c1<-c(4,3,5,7,2,3,9,5,2,7,4)
)
print(emp)
#ggplot(data = emp, aes(x =desig, y =c1, fill = BU)) +  geom_bar()


mydata100<-data.frame(
  workshop=c("R","Angular 2","R","DevOps","Stata","R","Stata","R","DevOps","Stata","Angular 2",
              "R","Stata","R","DevOps","R","R","Stata","R","DevOps","DevOps","Angular 2"),
  gender=c("Female","male","male","Female","Female","Female","male","male","Female","male","Female",
            "Female","male","male","male","male","Female","male","male","Female","male","Female"),
 q1=c(4,3,3,5,4,5,3,4,4,5,5,3,3,5,4,5,3,3,5,4,5,4),
 q2=c(3,4,2,3,3,4,3,5,4,4,3,4,3,3,3,4,3,5,4,4,3,3),
 q3=c(4,3,5,5,4,3,4,4,5,5,4,3,4,4,3,4,4,3,4,4,3,4),
 q4=c(4,3,3,5,4,5,3,3,4,5,5,5,4,5,5,4,5,5,4,5,5,4),
 pretest=c(70,84,34,70,90,88,65,74,89,10,93,87,76,69,45,59,80,77,90,92,83,74),
 posttest=c(84,74,59,90,98,91,84,89,93,45,97,97,89,91,67,78,90,95,97,92,93,85)
)
attach(mydata100)
qplot(workshop)
qplot(posttest)
qplot(workshop,gender)
qplot(workshop,posttest)
qplot(workshop,pretest)
qplot(pretest,posttest)


ggplot(mydata100,  
       aes(x=factor(""),fill = workshop) )+  geom_bar()

table(mydata100$workshop)

ggplot(mydata100,
       aes(x = factor(""), fill = workshop) ) +
  geom_bar() +
  coord_polar(theta = "y") +
  scale_x_discrete("")

ggplot(mydata100,aes(workshop) ) +
  geom_bar()

ggplot(mydata100, aes(workshop) ) +
  geom_bar() + coord_flip()

ggplot(mydata100, aes(workshop ) ) +
  geom_bar()
ggplot(mydata100, aes(workshop, fill = workshop ) ) +
  geom_bar()

ggplot(mydata100, aes(gender, fill = workshop) ) +
  geom_bar(position = c("stack"))

ggplot(mydata100, aes(gender, fill = workshop) ) +
  geom_bar(position = c("dodge"))

ggplot(mydata100, aes(gender, fill=workshop) ) +
  geom_bar(position="fill")


ggplot(mydata100, aes(gender, fill=workshop ) ) +
  geom_bar(position="dodge")  +
  scale_fill_grey(start = 0, end = 0.8)

ggplot(mydata100, aes(pretest)) +
  geom_density()

ggplot(data=mydata100) +
  geom_histogram( aes(pretest, ..density..) ) +
  geom_density( aes(pretest, ..density..) )+
  geom_rug( aes(pretest) )

ggplot(mydata100, aes(sample = pretest) ) +
  stat_qq()

ggplot(mydata100, aes(workshop, pretest,color=gender) ) +
  geom_point()

ggplot(mydata100, aes(workshop, pretest) ) +
  geom_jitter()

ggplot(mydata100, aes(pretest, posttest) ) +
  geom_line()

ggplot(women,aes(height,weight))+geom_line()
plot(women$height,women$weight,type="l")

ggplot(mydata100,
  aes(pretest, posttest, label = as.character(gender))) +
  geom_text(size = 3)
ggplot(mydata100, aes(pretest, posttest) ) +
  geom_point( aes(shape=gender,color=gender ) )

# DATA
set.seed(345)
Sector <- rep(c("S01","S02","S03","S04","S05","S06","S07"),times=7)
Year <- as.numeric(rep(c("1950","1960","1970","1980","1990","2000","2010"),each=7))
Value <- runif(49, 10, 100)
data <- data.frame(Sector,Year,Value)



ggplot(data, aes(x=Year, y=Value, fill=Sector))+ 
  geom_area()
