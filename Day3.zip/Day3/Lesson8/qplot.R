library(ggplot2) 
mydata100<-data.frame(
  workshop=c("R","Angular 2","R","DevOps","Stata","R","Stata","R","DevOps","Stata","Angular 2",
              "R","Stata","R","DevOps","R","R","Stata","R","DevOps","DevOps","Angular 2"),
  gender=c("Female","male","male","Female","Female","Female","male","male","Female","male","Female",
            "Female","male","male","male","male","Female","male","male","Female","male","Female"),
  q1=c(4,3,3,5,4,5,3,4,4,5,5,3,3,5,4,5,3,3,5,4,5,4),
  q2=c(3,4,2,3,3,4,3,5,4,4,3,4,3,3,3,4,3,5,4,4,3,3),
  q3=c(4,3,5,5,4,3,4,4,5,5,4,3,4,4,3,4,4,3,4,4,3,4),
  q4=c(4,3,3,5,4,5,3,3,4,5,5,5,4,5,5,4,5,5,4,5,5,4),
  pretest=c(70,84,34,70,90,88,65,74,89,10,93,87,76,69,45,59,80,77,90,92,83,74),
  posttest=c(84,74,59,90,98,91,84,89,93,45,97,97,89,91,67,78,90,95,97,92,93,85)
)

table(mydata100$workshop)

barchart(mydata100$workshop)
qplot(mydata100$workshop)

qplot(mydata100$workshop,fill=mydata100$workshop)

qplot(mydata100$workshop,alpha=0.2,fill=mydata100$workshop)

qplot(mydata100$workshop,fill=mydata100$gender)

qplot(mydata100$gender,fill=mydata100$workshop)

qplot(workshop,fill=gender,data=mydata100,
      main="Genderwise workshop data",
      xlab="Workshop",
      ylim=c(0,15))

employee<-data.frame(
  age=c(34,56,34,35,22,28,46,52,45,40,39,27),
  salary=c(23456,34567,76543,189898,54367,45363,67676,120909,245454,12987,34872,59345),
  exp=c(2,5,4,6,7,3,8,9,10,3,4,5),
  gender=c("M","F","M","F","M","F","M","F","M","F","M","F")
)

qplot(age,salary,data=employee)

qplot(mydata100$workshop,mydata100$posttest)
