set.seed(1234)
df <- data.frame(
  sex=factor(rep(c("F", "M"), each=200)),
  weight=round(c(rnorm(200, mean=55, sd=5),
                 rnorm(200, mean=65, sd=5)))
)
head(df)

library(ggplot2)
#Each geom option can be added separately
p<-ggplot(df, aes(x=weight)) 
p+ geom_area(stat = "bin")

# y axis as density value
p+geom_area(aes(y = ..density..), stat = "bin")

# Add mean line
p+geom_bar()
p+geom_area(stat = "bin", fill = "lightblue")+
  geom_vline(aes(xintercept=mean(weight)),
             color="blue", linetype="dashed", size=1)

# Change line color and fill color
p+geom_area(stat ="bin", color="darkblue",
              fill="lightblue")

# Change line type
p+geom_area(stat = "bin", color= "black",
              fill="lightgrey", linetype="dashed")



# Change area plot fill colors by groups
ggplot(df, aes(x=weight, fill=sex)) +
  geom_area(stat ="bin")

mydata100<-data.frame(
  workshop=c("R","Angular 2","R","DevOps","Stata","R","Stata","R","DevOps","Stata","Angular 2",
             "R","Stata","R","DevOps","R","R","Stata","R","DevOps","DevOps","Angular 2"),
  gender=c("Female","male","male","Female","Female","Female","male","male","Female","male","Female",
           "Female","male","male","male","male","Female","male","male","Female","male","Female"),
  q1=c(4,3,3,5,4,5,3,4,4,5,5,3,3,5,4,5,3,3,5,4,5,4),
  q2=c(3,4,2,3,3,4,3,5,4,4,3,4,3,3,3,4,3,5,4,4,3,3),
  q3=c(4,3,5,5,4,3,4,4,5,5,4,3,4,4,3,4,4,3,4,4,3,4),
  q4=c(4,3,3,5,4,5,3,3,4,5,5,5,4,5,5,4,5,5,4,5,5,4),
  pretest=c(70,84,34,70,90,88,65,74,89,10,93,87,76,69,45,59,80,77,90,92,83,74),
  posttest=c(84,74,59,90,98,91,84,89,93,45,97,97,89,91,67,78,90,95,97,92,93,85)
)
ggplot(mydata100,aes(x=pretest,fill=workshop))+
  geom_area(stat="bin")

install.packages("RODBC")
library(RODBC)

# Go to Control Panel -> Administrative Tools ->ODBC and create a new DSN

c1<-odbcConnect("JanDSN",uid="hema",pwd="corp@123",believeNRows=FALSE)
odbcGetInfo(c1)
empData<-sqlQuery(c1,"SELECT * from hema.emp")
empData

ggplot(empData,aes(x=SALARY,fill=JOB))+
  geom_area(stat="bin")


# Use semi-transparent fill
p<-ggplot(df, aes(x=weight, fill=sex)) +
  geom_area(stat ="bin", alpha=0.6) +
  theme_classic()
p

library(plyr)
mu <- ddply(df, "sex", summarise, grp.mean=mean(weight))
mu
head(mu)
# Add mean lines
ggplot(df, aes(x=weight, fill=sex)) +
  geom_area(stat ="bin")+geom_vline(data=mu,
      aes(xintercept=grp.mean, color=sex),
             linetype="dashed",size=1)

# Use custom color palettes
p<-ggplot(df, aes(x=weight, fill=sex)) +
  geom_area(stat ="bin")
p+scale_fill_manual(values=c("#999999", "#E69F00")) 
# use brewer color palettes
p+scale_fill_brewer(palette="Dark2") 
# Use grey scale
p + scale_fill_grey()

p + theme(legend.position="top")
p + theme(legend.position="bottom")
p + theme(legend.position="none") # Remove legend

# Load the data
data("diamonds")
diamonds
p <- ggplot(diamonds, aes(x = price, fill = cut))
head(diamonds)

# Bar plot
p + geom_bar(stat = "bin")

# Area plot
p + geom_area(stat = "bin") +
  scale_fill_brewer(palette="Dark2")

dat <- with(density(df$weight), data.frame(x, y))
ggplot(data = dat, mapping = aes(x = x, y = y)) +
  geom_line()+
  geom_area(mapping = aes(x = ifelse(x>55 & x< 60 , x, 0)), fill = "red") +
  xlim(30, 80)

