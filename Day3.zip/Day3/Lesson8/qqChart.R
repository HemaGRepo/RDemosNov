#Simple qq norm

set.seed(42)
x <- rnorm(100)
print(x)

qqnorm(x)
qqline(x)

y <- rgamma(100, 1)
print(y)

qqnorm(y); qqline(y)

#---------------CASE STUDY 1

# view first 6 entries of the "Ozone" data frame 
head(airquality)

# extract "Ozone" data vector
ozone = airquality$Ozone

# sample size of "ozone"
length(ozone)

# summary of "ozone"
summary(ozone)

# remove missing values from "ozone"
ozone = ozone[!is.na(ozone)]

# having removed missing values, find the number of non-missing values in "ozone"
n = length(ozone)

# calculate mean, variance and standard deviation of "ozone"
mean.ozone = mean(ozone)
var.ozone = var(ozone)
sd.ozone = sd(ozone)

#set the n points in the interval (0,1) for the n equi-probable point-wise 
#probabilities, each of which is assigned to the correspondingly ranked quantile.
#  (The smallest probability is assigned to the smallest quantile, 
#and the largest probability is assigned to the largest quantile.)  
#These probabilities will be used to calculate the quantiles for each hypothesized theoretical distribution.

# set n points in the interval (0,1)
# use the formula k/(n+1), for k = 1,..,n
# this is a vector of the n probabilities
probabilities = (1:n)/(n+1)


#Mean mark of 50 students is 75
#SD is 10.2
# n=50, Probability of mark of each student and we can create theoritical samples


# calculate normal quantiles using mean and standard deviation from "ozone"
normal.quantiles = qnorm(probabilities, mean(ozone, na.rm = T), sd(ozone, na.rm = T))

# normal quantile-quantile plot for "ozone"

plot(sort(normal.quantiles), sort(ozone) , 
     xlab = 'Theoretical Quantiles from Normal Distribution',
     ylab = 'Sample Quqnatiles of Ozone', 
     main = 'Normal Quantile-Quantile Plot of Ozone')
abline(0,1)

#CONCLUSION - The plotted points do not fall closely onto the identity line, 
#so the data do not seem to come from the normal distribution.

#------------CASE STUDY 2

# calculate gamma quantiles using mean and standard deviation from "ozone" to calculate shape and scale parameters
gamma.quantiles = qgamma(probabilities, shape = mean.ozone^2/var.ozone, scale = var.ozone/mean.ozone)


# gamma quantile-quantile plot for "ozone"

plot(sort(gamma.quantiles), sort(ozone), xlab = 'Theoretical Quantiles from Gamma Distribution', ylab = 'Sample Quantiles of Ozone', main = 'Gamma Quantile-Quantile Plot of Ozone')
abline(0,1)

#CONCLUSION - The gamma plot points fall closely to the identity line,
#so the data seems to be normally distributed


accWeather<-c(34,35,42,45,40,42,32,38,39,43,35,36,43,44,41,32,42,48,39,35)
actual<-c(30,33,45,43,41,35,40,41,40,39,30,34,45,40,34,38,39,40,42,37)

a1<-sort(accWeather)
a2<-sort(actual)
plot(sort(accWeather),sort(actual),
     xlab="Accuweather prediction",
     ylab="Actual Temperatures")
abline(0,1)


accWea<-c(31,35,42,44,40,36,39,39,41,39,31,35,44,41,34,37,40,41,42,35)
actual<-c(30,33,45,43,41,35,40,41,40,39,30,34,45,40,34,38,39,40,42,37)
plot(sort(accWea),sort(actual),
     xlab="Accuweather prediction",
     ylab="Actual Temperatures")
abline(0,1)
