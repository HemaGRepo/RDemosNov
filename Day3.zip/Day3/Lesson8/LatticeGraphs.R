# Lattice Examples 
library(lattice) 
attach(mtcars)

employee<-data.frame(
  age=c(34,56,34,35,22,28,86,52,45,40,39,27),
  salary=c(23456,34567,76543,89898,54367,45363,67676,20909,45454,12987,34872,59345),
  exp=c(2,5,4,6,7,3,8,9,10,3,4,5)
)

histogram(~employee$salary,main="Employee Salary Distribution")

barchart(employee$salary~employee$exp)

cloud(employee$salary~employee$exp*employee$age)

wireframe(employee$salary~employee$exp*employee$age)
# create factors with value labels 
gear.f<-factor(gear,levels=c(3,4,5),
               labels=c("3gears","4gears","5gears")) 
gear.f
cyl.f <-factor(cyl,levels=c(4,6,8),
               labels=c("4cyl","6cyl","8cyl")) 

# kernel density plot 
densityplot(mtcars~mpg, 
            main="Density Plot", 
            xlab="Miles per Gallon")

# kernel density plots by factor level 
densityplot(~mpg|cyl.f, 
            main="Density Plot by Number of Cylinders",
            xlab="Miles per Gallon")

employee<-data.frame(
  age=c(34,56,34,35,22,28,46,52,45,40,39,27),
  salary=c(23456,34567,76543,189898,54367,45363,67676,120909,245454,12987,34872,59345),
  exp=c(2,5,4,6,7,3,8,9,10,3,4,5),
  gender=c("M","F","M","F","M","F","M","F","M","F","M","F")
)

# Salary vs Gender
densityplot(~employee$salary|employee$gender,
            main="Genderwise salary distribution",
            xlab="salary")

# kernel density plots by factor level (alternate layout) 
densityplot(~mpg|cyl.f, 
            main="Density Plot by Numer of Cylinders",
            xlab="Miles per Gallon", 
            layout=c(3,1))

# boxplots for each combination of two factors 
bwplot(cyl.f~mpg|gear.f,
       ylab="Cylinders", xlab="Miles per Gallon", 
       main="Mileage by Cylinders and Gears", 
       layout=(c(3,1)))
       
       # scatterplots for each combination of two factors 
       xyplot(mpg~wt|cyl.f*gear.f, 
              main="Scatterplots by Cylinders and Gears", 
              ylab="Miles per Gallon", xlab="Car Weight")
       
       # 3d scatterplot by factor level 
       cloud(mpg~wt*qsec|cyl.f, 
             main="3D Scatterplot by Cylinders") 
       
       cloud(employee$salary~employee$age*employee$exp|employee$gender,
                   main="Genderwise salary distribution")
       
       # dotplot for each combination of two factors 
       dotplot(cyl.f~mpg|gear.f, 
               main="Dotplot Plot by Number of Gears and Cylinders",
               xlab="Miles Per Gallon")
       
       # scatterplot matrix 
       splom(mtcars[c(1,3,4,5,6)], 
             main="MTCARS Data")
       

       splom(employee,main="EmpData")
       
product<-data.frame(
        orders=c(5,6,2,3,4,8,9,2,3,5,7,8,9,1,10,3),
        price=c(56,34,78,23,56,54,34,12,67,47,85,68,39,90,55,29)
)       
 
par(mfrow=c(1,2))  
plot(product$orders,product$price)
plot(product$price,product$orders)

splom(product,main="Product plot")
       
       
       
       
       
       
       
       