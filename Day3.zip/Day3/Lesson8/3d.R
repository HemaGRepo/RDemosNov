a<-c(1,3,5)
b<-c(10,8,6)

fn11<-function(x,y){
  return(x+y)
}

res<-outer(a,b,fn11)
print(res)


fn1<- function(x, y){
  sqrt(x^2+y^2)
}

x <- seq(-1, 1, length= 20)
y <- seq(-1, 1, length= 20)
z <- outer(x, y, fn1)


fn2<- function(x, y){
 x*y
}
x<-1:5
y<-6:10
z<-outer(x,y,fn2)


persp(x, y, z)

persp(x, y, z,
      main="Perspective Plot of a Cone",
      zlab = "Height",
      theta = 30,phi = 20,
      col = "springgreen", shade = 0.5)


x<-1:20
y<-1:20
z<-outer(x,y,fn1)


fn1<- function(x, y){
  sqrt(x^2+y^2+2*x*y)
}

x <- y <- seq(1, 20, length= 20)
z <- outer(x, y, fn1)

#x,y,x^2+y^2+2xy
persp(x, y, z)

persp(x, y, z,
      main="Perspective Plot of a Plane",
      zlab = "Height",
       phi = 15,
      col = "springgreen", shade = 0.5)


x<-1:50
y<-seq(10,90,by=3)
z<-outer(x,y,function(x,y){return(2*(x+y))})

persp(x,y,z, col="blue")

library(RColorBrewer)
par(mar=c(3,4,2,2))
display.brewer.all()

################
# generate pairs of x-y values
theta = seq(-2 * pi, 2 * pi, length = 300)
x = cos(theta)
y = x + sin(theta) 

# set graphical parameters
op = par(bg = "black", mar = rep(0.1, 4))

# plot
plot(x, y, type = "n", xlim = c(-8, 8), ylim = c(-1.5, 1.5))
for (i in seq(-2*pi, 2*pi, length = 100))
{
  lines(i*x, y, col = hsv(runif(1, 0.85, 0.95), 1, 1, runif(1, 0.2, 0.5)), 
        lwd = sample(seq(.5, 3, length = 10), 1))          
}

# signature
legend("bottomright", legend = "� Gaston Sanchez", bty = "n", text.col = "gray70")











