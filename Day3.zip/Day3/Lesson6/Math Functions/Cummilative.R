d1<-c(6,3,4,5,9,1)
#6 6+3 6+3+4 6+3+4+5 6+3+4+5+9 6+3+4+5+9+1
#6,9,13,18,27,28
cumsum(d1)
cumprod(d1)
#6,18,....


vect1<-c(8,3,4,5,1,10)
#Cummilative sum
#8,8+3,8+3+4,8+3+4+5,8+3+4+5+1,8+3+4+5+1+10
#8,11,15,20,21,31
cumsum(vect1)


v1<-1:4 
#(1,2,3,4) => 1, 1+2, 1+2+3, 1+2+3+4
cumsum(v1)
#1 1+2 1+2+3 1+2+3+4
#1,3,6,10

v2<-c(89,30,20,45,10,6)
cumsum(v2)

v3<-c(4,8,12,15,10,6,9,2)
#4 4+8 4+8+12 4+8+12+15 4+8+12+15+10 4+8+12+15+10+6 4+8+12+15+10+6+9 4+8+12+15+10+6+9+2
#4,12,24,39,49,55,64,66
#4 4*8 4*8*12
cumsum(v3)
cumprod(v3)

cumprod(v1)

cumsum(1:10)
cumprod(1:10)

marks<-c(90,89,76,92,87,51,64,12)

cummin(marks)
#min(90) min(90,89) min(90,89,76) min(90,89,76,92) ... 
#90,89,76,76,76,51,51,12

cummax(marks)

cummin(1:10)
cummax(1:10)

sum(1:10)
prod(1:10)


x<-c(324,23,122,34)
range(x)

y<-c(88,34,9,91)
z<-c(56,14,84,12)
r<-c(77,1,90,10)
pmin(x,y,z,r)
pmax(x,y,z,r)
pmin(x,y)

x<-c(324,23,122)
pmin(x,50)


mean(x)
sd(x)
mean(x)

seq(1,10,2)
rep(1:3, 2)

num1<-1:10
cut(num1,5)

num2<-30:90
#60 numbers
cut(num2,6)

marks<-c(0,56,24,89,100,77,61,16,35,47)
cut(marks,4)
table(cut(marks,4))

# Data <- 1 2 3 4 5 6 7 8 9 10
# Creates 5 Levels - (0.991,2.8] (2.8,4.6] (4.6,6.4] (6.4,8.2] (8.2,10]  - created based on the range

# In which range a data falls
# (0.991,2.8] (0.991,2.8] (2.8,4.6] (2.8,4.6] (4.6,6.4] (4.6,6.4] (6.4,8.2] (6.4,8.2] (8.2,10] (8.2,10]

marks<-c(10,45,30,89,95,24,56,90,66,72)
#Poor    NI      Poor    Good    Good    Poor    Average Good    Average Average
cut(marks,4)
table(cut(marks,4))
cut(marks,4,labels=c("Poor","NI","Average","Good"))
table(cut(marks,4,labels=c("Poor","NI","Average","Good")))

#Read the wages of Employees
wages<-read.csv("https://raw.githubusercontent.com/vincentarelbundock/Rdatasets/master/csv/Ecdat/Bwages.csv")
wages

wageGroup<-cut(wages$wage,10,labels=c("A2","A1","B2","B1","C2","C1","D","E","F","G"))
table(wageGroup)

w1<-cut(wages$wage,breaks = c(0,5,10,15,20,25,30,35,40,45,50))
wageTab<-table(w1)

#rent<-c(3456,2300,780)
#rateCategory<-cut(rent,breaks=c(500,1000,1700,2500,10000),
         # labels=c("Category1","Category2","Category3","Category4"))

#rateCategory


hist(wages$wage,breaks=10,ylab="Count of Employees",xlab="wages")

marks<-c(10,45,30,89,95,24,56,90,66,72)
mtab<-cut(marks,breaks=c(0,35,70,100))
print(table(mtab))

range(marks)

y <- cut(x, 5)
print(y)

x<-c(1,2,3,4,3,2,5)
y<-c(5,4,2,8,3,4)
union(x,y)
intersect(x,y)
setdiff(x,y)
setdiff(y,x)
is.element(x,y)
is.element(y,x)

v1<-c(6,3,7,10,12)
v2<-c(5,4,3,7,8,10)

#is.element(v1,v2)
# 6 -> check if 6 there in v2 -FALSE
# 3 -> check if 3 is there in v2 - TRUE
is.element(v1,v2)
is.element(v2,v1)

library(psych)
describe(v1)




mean(1:10)
sd(1:10)
install.packages("psych")
library(psych)
describe(1:10)