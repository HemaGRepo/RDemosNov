sin(180)
cos(180)
tan(90)
cos(0)
sin(0)
exp(5)

log(78) # Log base e
log10(54) # Log base 10
logb(54,2) # Logb -> Log of 54 to the base 2
logb(54,10) # same as lab10(54)

ceiling(3.475)
floor(3.475)
trunc(5.99)
abs(-5.678)

factorial(3)

sqrt(2)
round(3.56)
round(3.45)