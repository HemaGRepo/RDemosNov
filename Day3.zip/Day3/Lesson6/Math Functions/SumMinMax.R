min(5:1)
max(5:1)

salary<-c(89123,34599,23345,90900,45678)
min(salary)
which.min(salary)
max(salary)
range(salary)

location<-c("Chennai","Mumbai","Pune","Delhi","Agra")
min(location)
max(location)
range(location)

v1<-c(-1,10,9,4,6)
v2<-c(5,8,3,1,21)
v3<-c(0,6,1,5,7)

pmin(v1,v2,v3)
pmax(v1,v2,v3)

rainInChennai<-c("Jan"=10,"Feb"=45,"Mar"=78,"Apr"=10,"May"=5,"June"=90)
rainInChennai
rainInPune<-c("Jan"=30,"Feb"=5,"Mar"=22,"Apr"=8,"May"=85,"June"=30)
rainInPune
rainInMumbai<-c("Jan"=12,"Feb"=3,"Mar"=7,"Apr"=40,"May"=55,"June"=12)
rainInMumbai


rainFL<-c(39,42,47,52,62,69,72,72,68,57,47,41)
rainIL<-c(27,28,35,44,54,63,68,66,57,46,34,23)
rainTX<-c(42,45,51,59,67,72,74,75,69,61,51,42)
names(rainFL)<-names(rainIL)<-names(rainTX)<-month.abb

pmin(rainFL,rainIL,rainTX)
pmax(rainFL,rainIL,rainTX)

leastRainInIndia<-pmin(rainInChennai,rainInPune,rainInMumbai)
leastRainInIndia


maxRainMonthwise<-pmax(rainInChennai,rainInPune,rainInMumbai)
maxRainMonthwise

taxrate = c(AL=4,CA=7.25,IL=6.25,KS=5.3,NY=4.25,TN=7)
total<-sum(taxrate)
print(total)