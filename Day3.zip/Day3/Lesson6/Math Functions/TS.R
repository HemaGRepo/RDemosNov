sales<-c(564,345,297,345,109,678,230,787,345,789,345,620)
salesTs<-ts(sales,start=c(2017,1),frequency=12)
print(salesTs)
plot(salesTs)


sales11<-c(564,345,297,345,109,678,230,787,345,789,345,620,564,345,297,345,109,678)
salesTs11<-ts(sales11,start=c(2017,1),frequency=12)
print(salesTs11)

#plot(sales)
#axis(1, at=1:12, labels = c("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"))


sales1<-c(564,345,297,345,109,678,230,787,345,789,345,620)
salesTs1<-ts(sales1,start=c(2015,1),frequency = 4)
print(salesTs1)
plot(salesTs1)

salesA<-c(564,345,297,345,109,678,230,787,345,789,345,620)
salesAB<-ts(salesA,start=c(2015,1),frequency=4)
print(salesAB)

salesB<-c(787,345,356,267,500,345,789,290,333,909,465,234)
salesMatrix<-matrix(c(salesA,salesB),nrow=12)

salesAB<-ts(salesMatrix,start=c(2015,1),frequency=4)
print(salesAB)

salesAB<-ts(salesMatrix,start=c(2017,1),frequency=12)
print(salesAB)
plot(salesAB,type="b")
