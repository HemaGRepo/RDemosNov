stud.data<-data.frame(
  mark=c(10,10,10,20,20,20,30,30,30,30),
  course=c("BE","MCA","BE","MCA","BE","MCA","BE","MCA","BE","MCA")
)
#BE=10,10,20,30,30 =mean=20
#MCA=10,20,20,30,30 =mean=22

#Group the data by course, find the mean for each course
by(stud.data,stud.data$course,function(x){mean.mark<-mean(x$mark)})

emp.data <- data.frame(
  emp_id = c (1:8), 
  emp_name = c("Rick","Dan","Michelle","Ryan","Gary","Tim","Steve","Allen"),
  salary = c(623.3,515.2,611.0,729.0,843.25,655.2,811.0,799.0), 
  
  start_date = as.Date(c("2012-01-01", "2013-09-23", "2014-11-15", "2014-05-11",
                         "2015-03-27","2013-09-23", "2014-11-15", "2014-05-11")),
  desig=c("SSE","SE","Mgr","SE","SE","Mgr","SE","SSE"),
  grade=c("Chennai","Pune","Mumbai","Mumbai","Pune","Chennai","Chennai","Pune"),
  stringsAsFactors = FALSE
)

by(emp.data,emp.data$desig,function(x){mean.salary<-mean(x$salary)})

by(emp.data$salary,list(emp.data$loc,emp.data$gender,emp.data$desig),mean)