salesA<-c(564,345,297,345,109,678,230,787,345,789,345,620)
salesB<-c(787,345,356,267,500,345,789,290,333,909,465,234)
salesC<-c(564,345,297,345,109,678,230,787,345,789,345,620)
salesD<-c(787,345,356,267,500,345,789,290,333,909,465,234)
salesMatrix<-matrix(c(salesA,salesB,salesC,salesD),nrow=12,
                    dimnames = list(month.abb,
                  c("SalesMan A","SalesMan B","SalesMan C","SalesMan D")))
print(salesMatrix)

#Dimension - 1-row and 2-column
#apply(matrix/array, dimension,function)
individualSales<-apply(salesMatrix,2,sum)
print(individualSales)
plot(salesMatrix)

minSales<-apply(salesMatrix,2,min)
print(minSales)

monthlySales<-apply(salesMatrix,1,sum)
print(monthlySales)
plot(monthlySales)

AvgSales<-apply(salesMatrix,2,mean)
print(AvgSales)

monthlySales<-apply(salesMatrix,1,sum)
print(monthlySales)

#Create an array
sales<-c(564,345,297,345,109,678,230,787,345,789,345,620,
         787,345,356,267,500,345,789,290,333,909,465,234)

rnames<-c("2016","2017","2018")
cnames<-c("Q1","Q2","Q3","Q4")
sMan<-c("SalesMan1","SalesMan2")

salesArray<-array(sales,dim=c(3,4,2),
                  dimnames = list(rnames,cnames,sMan))

print(salesArray)

apply(salesArray,1,sum)

apply(salesArray,2,sum)

apply(salesArray,3,sum)

#Sales by Salesman A
print(salesArray[,,1])

apply(salesArray[,,1],1,sum)
apply(salesArray[,,2],1,sum)

#apply function
# Construct a 5x6 matrix
#X <- matrix(rnorm(30), nrow=5, ncol=6)
X <- matrix(1:30,nrow=5,ncol=6)
print(X)
# Sum the values of each column with `apply()` - 2 represents column wise
apply(X, 2, sum)

# Sum the values of each column with `apply()` - 1 represents row wise
apply(X, 1, sum)

apply(X,3,sum)

# Return a new matrix whose entries are those of 'm' modulo 10
apply(X,c(1,2),function(x) x%%10) 

#userdefined function
translate<-function(x){
  if (length(x)!=1){
    r<-sample(1:(length(x)),1)
    x<-append(x[r:length(x)],x[1:r-1])
  }
  return(x)
}

translate(56564)

#data frame
emp.data <- data.frame(
  emp_id = c (1:5), 
  emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),
  salary = c(623.3,515.2,611.0,729.0,843.25), 
  
  start_date = as.Date(c("2012-01-01", "2013-09-23", "2014-11-15", "2014-05-11",
                         "2015-03-27")),
  stringsAsFactors = FALSE
)

print(emp.data)

print(apply(data.matrix(emp.data$salary),2,sum))

data.matrix(emp.data$salary)





