emp.data <- data.frame(
  emp_id = c (1:8), 
  emp_name = c("Rick","Dan","Michelle","Ryan","Gary","Tim","Steve","Allen"),
  salary = c(623.3,515.2,611.0,729.0,843.25,655.2,811.0,799.0), 
  gender=c("M","F","M","M","M","F","F","M"),
  
  start_date = as.Date(c("2012-01-01", "2013-09-23", "2014-11-15", "2014-05-11",
                         "2015-03-27","2013-09-23", "2014-11-15", "2014-05-11")),
  desig=c("SSE","SE","Mgr","SE","SE","Mgr","SE","SSE"),
  loc=c("Chennai","Pune","Mumbai","Mumbai","Pune","Chennai","Chennai","Pune"),
  stringsAsFactors = FALSE
)

emp.data <- data.frame(
  emp_id = c (1:16), 
  emp_name = c("Rick","Dan","Michelle","Ryan","Gary","Tim","Steve","Allen",
               "Rick","Dan","Michelle","Ryan","Gary","Tim","Steve","Allen"),
  salary = c(6233.3,5152.2,6110.0,3729.0,8437.25,6559.2,8115.0,7993.0,
             6233.3,5152.2,6110.0,3729.0,8437.25,6559.2,8115.0,7993.0), 
  gender=c("M","M","M","M","F","M","F","M","F","F","F","M","M","F","F","M"),
  
  start_date = as.Date(c("2012-01-01", "2013-09-23", "2014-11-15", "2014-05-11",
                         "2015-03-27","2013-09-23", "2014-11-15", "2014-05-11",
                         "2012-01-01", "2013-09-23", "2014-11-15", "2014-05-11",
                         "2015-03-27","2013-09-23", "2014-11-15", "2014-05-11")),
  desig=c("Mgr","Prgmr","Prgmr","Prgmr","Mgr","Sr.Prgmr","Mgr","Sr.Prgmr",
          "Sr.Prgmr","Prgmr","Sr.Prgmr","Sr.Prgmr","Mgr","Sr.Prgmr","Mgr","Sr.Prgmr"),
  loc=c("NY","CA","MI","CA","CA","NY","CA","MI","MI","NY","MI","MI","CA","NY","MI","MI"),
  stringsAsFactors = FALSE
)


#Find the mean salary Group by designation
# SELECT avg(salary) FROM emp.data GROUP BY desig 
#tapply(emp.data$salary,emp.data$desig,mean)

tapply(emp.data$salary,emp.data$desig,mean)

#Find the mean salary Group by designation and location
# SELECT avg(salary) FROM emp.data GROUP BY desig,location
#tapply(emp.data$salary,list(emp.data$desig,emp.data$location),mean)
res<-tapply(emp.data$salary,list(emp.data$loc,emp.data$desig),mean)
res

#Find the mean salary Group by designation,gender and grade
res1<-tapply(emp.data$salary,list(emp.data$loc,emp.data$gender,emp.data$desig),mean)
res1


#Find the mean salary Group by designation,gender and grade
res2<-tapply(emp.data$salary,list(emp.data$desig,emp.data$loc,emp.data$gender),mean)
res2


mtcars

tapply(mtcars$mpg, list(mtcars$cyl, mtcars$am), mean)