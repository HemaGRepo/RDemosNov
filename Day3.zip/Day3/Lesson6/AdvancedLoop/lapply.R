#Applying a function to each element and getting a list as output

f1<-function(x)
{
  if(x<5)
    return(x^2)
  else
    return(x*2)
}

lapply(1:10,f1)
sapply(1:10, f1)

f <- function(x) x^2
sapply(1:10, f)

#data frame
emp.data <- data.frame(
  emp_id = c (1:5), 
  emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),
  salary = c(623.3,515.2,611.0,729.0,843.25), 
  
  start_date = as.Date(c("2012-01-01", "2013-09-23", "2014-11-15", "2014-05-11",
                         "2015-03-27")),
  stringsAsFactors = FALSE
)

lapply(data.matrix(emp.data$salary),function(x) x+x*10/100)
sapply(data.matrix(emp.data$salary),function(x) x+x*10/100)