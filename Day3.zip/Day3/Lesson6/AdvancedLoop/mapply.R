#rep
mapply(rep,1:4,4)

data<-c(1,4,8)

print(data)

print(rep(data,c(3,5,2)))

#The mapply() function stands for 'multivariate' apply.
# Take input as 1:4, use rep function
# The repeat count is 6:3
# IP(1,2,3,4) repeat(6,5,4,3) => rep(c(1,2,3,4),c(6,5,4,3))
mapply(rep, 1:4, 6:3)

Q=mapply(rep,1:4,4)
print(Q)

mapply(function(x)x*2,1:4)
#data frame
emp.data <- data.frame(
  emp_id = c (1:5), 
  emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),
  salary = c(623.3,515.2,611.0,729.0,843.25), 
  
  start_date = as.Date(c("2012-01-01", "2013-09-23", "2014-11-15", "2014-05-11",
                         "2015-03-27")),
  stringsAsFactors = FALSE
)

mapply(function(x) x+x*10/100,data.matrix(emp.data$salary))

