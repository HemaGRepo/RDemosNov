library(ggplot2)    # load ggplot2 plotting package

# set 'seed' for random number generation 
set.seed(53)        

# CREATE DATA FRAME
#  1. create 'x_var' as 15 random, normally distributed numbers (using rnorm)
#  2. create 'y_var' as 15 random, normally distributed numbers (using rnorm)
#  3. create 'size_var' as a random number between 1 and 10
#  4. combine these variables into a single data frame using the data.frame() function
x_var <- rnorm( n = 15, mean = 5, sd = 2)
x_var
y_var <- x_var + rnorm(n = 15, mean = 5, sd =4)
size_var <- runif(15, 1,10)

df.test_data <- data.frame(x_var, y_var, size_var)

# PLOT THE DATA USING GGPLOT2
ggplot(data=df.test_data, aes(x=x_var, y=y_var)) +
  geom_point(aes(size=size_var)) +
  scale_size_continuous(range=c(2,15)) +
  theme(legend.position = "none")

employee<-data.frame(
  age=c(34,56,34,35,22,28,46,52,45,40,39,27),
  salary=c(23456,34567,76543,189898,54367,45363,67676,120909,245454,12987,34872,59345),
  exp=c(2,5,4,6,7,3,8,9,10,3,4,5)
)

ggplot(data=employee,aes(x=exp, y=age))+
  geom_point(aes(size=salary)) +
  scale_size_continuous(range=c(2,20))

symbols(employee$age,employee$exp,circles = employee$salary,
        fg="white", bg="red", xlab="Employee Age", ylab="Experience in Years")

symbols(employee$age,employee$salary,circles = employee$exp,
        fg="white", bg="blue", xlab="Employee Age", ylab="Salary in Rs.")


myvector <- c(20:100)
myts <- ts(myvector, start=c(2009, 1), end=c(2014, 12), frequency=4) 

plot(myts)


sales<-c(90,84,56,78,90,23,89,67,89,12,34,56,78,90,23,53,75,85)
myts <- ts(sales, start=c(2015, 1), end=c(2017, 6), frequency=12)
myts

myts1 <- ts(sales, start=c(2015, 1),end=c(2017,6), frequency=4)
myts1
plot(myts, type="b")

















