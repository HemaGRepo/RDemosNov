#Histrogram
B <- c(2, 4, 5, 7, 12, 14, 16)
hist(B)

A <- structure(list(James = c(1L, 3L, 6L, 4L, 9L),
                    Robert = c(2L, 5L,4L, 5L, 12L),
                    David = c(4L, 4L, 6L, 6L, 16L),
                    Anne = c(3L, 5L,6L, 7L, 6L)), 
                    Names = c("James", "Robert", "David", "Anne"), 
              class="data.frame", row.names = c(NA, -5L))

print(A)

B <- c(A$James, A$Robert, A$David, A$Anne)
print(B)
hist(B, col="darkgreen", ylim=c(0,10), ylab ="MY HISTOGRAM", xlab
     ="FREQUENCY")

hist(B, col = "red", breaks=6, xlim=c(0,max(B)), 
     main="My Histogram", las=2, xlab = "Values", cex.lab = 1.3)

bins<- c(0, 4, 8, 12, 16)
hist(B, col = "blue", breaks=bins, xlim=c(0,max(B)), 
     main="My Histogram", las=2, xlab = "Values", cex.lab = 1.3)

#Using built in dataset airquality
str(airquality)

Temperature <- airquality$Temp
hist(Temperature)

# histogram with added parameters

hist(Temperature,
     main="Maximum daily temperature at La Guardia Airport",
     xlab="Temperature in degrees Fahrenheit",
     xlim=c(50,100),
     col="darkmagenta",
     freq=FALSE
)
#Use Histogram return values for labels using text()

h <- hist(Temperature,ylim=c(0,40))
text(h$mids,h$counts,labels=h$counts, adj=c(0.5, -0.5))

#Histogram with different breaks
hist(Temperature, breaks=4, main="With breaks=4")
hist(Temperature, breaks=20, main="With breaks=20")

#Histogram with manual breaks
hist(Temperature,
     main="Maximum daily temperature at La Guardia Airport",
     xlab="Temperature in degrees Fahrenheit",
     xlim=c(50,100),
     col="chocolate",
     border="brown",
     breaks=c(55,60,70,75,80,100)
)


# Data about the number of eruptions of a Geyser and the waiting period between eruptions


geysers<-data.frame(
  eruptions=c(3.600, 1.800,3.333,2.283,4.533,2.883),
  waiting=c(79,54,74,63,85,55)
)
print(geysers)


duration = faithful$eruptions 
print(duration)
hist(duration,right=FALSE)


colors = c("red", "yellow", "green", "violet", "orange", 
 "blue", "pink", "cyan") 
hist(duration, right=FALSE,  col=colors,  main="Old Faithful Eruptions", 
       xlab="Duration minutes") 

employeeSalary<-c(56457,34556,38989,76767,23434,65676,20000,80000,
                  34545,46767,56389,61023,77243,23455)
hist(employeeSalary)

hist(employeeSalary,main="Salary Distribution",
     xlim=c(20000,80000),
     breaks=c(20000,50000,70000,80000))













