#Simple Plot
v1<-c(1,2)
v2<-c(3,5)
plot(v1,v2)
text(v1,v2,v1,2)

data1=c(10,34,57,23,42,38,18)

check<-function(x)
{
  return(x%%7)
}

plot(data1,check(data1))

# Plot for Sin function
x <- seq(-pi,pi,0.1)
plot(x,cos(x),main="The Cos Plot",type="l",
     xlab="X Value",ylab="Cos value of X",col="green")

plot(x, cos(x), main="The Sine Function", 
     ylab="sin(x)", type="h")

#Plot of x^2

x<-1:20
plot(x,x^2,main="The Square of Numbers",ylab="Square",
     xlab="Number",type="l")

# Plot with arguments
plot(x, sin(x),
     main="The Sine Function",
     ylab="sin(x)",
     type="l",
     col="blue")

# Overlaying Graphs
plot(x, cos(x), main="Overlaying Graphs",
     xlab="Value of X", ylab="Sin and Cos Curve",type="h", col="blue")
lines(x,sin(x), col="red",type="h") 
legend("topleft", c("cos(x)","sin(x)"), fill=c("blue","red")
       )
plot

#Define custom values for x-asix. Use xaxt to remove default values
plot(1:10)
plot(1:10, xaxt = "n", xlab='Some Letters')
axis(1, at=1:10, labels=letters[1:10])

# Plot the average Rainfall in Mumbai in 2016
rainfall<-c(80,54,30,2,5,0,29,45,67,80,90,66)
months <-c("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec")

mumbaiRains<-data.frame(
  rain=rainfall,
  month=months
)
mumbaiRains

plot(rainfall,
     main=("Rainfall in 2016"),
     ylab="Rainfall",xlab="months",
     type="b",col="red",xaxt = "n")
axis(1, at=1:12, labels=months[1:12])

plot(mumbaiRains$rain,
     main=("Rainfall in 2016"),
     ylab="Rainfall",xlab="months",
     type="b",col="blue",xaxt = "n")
axis(1, at=1:12, labels=mumbaiRains$month[1:12])
