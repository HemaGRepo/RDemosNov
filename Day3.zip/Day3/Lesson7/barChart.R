# bar plots from categorical data.
age <- c(17,18,18,17,18,19,18,16,18,18)
table(age)
barplot(table(age),
        main="Age Count of 10 Students",
        xlab="Age",
        ylab="Count",
        border="blue",
        col=c("blue","magenta","green","yellow"),
        density=20
)

#higher dimensional tables
# This demo uses a built in datset with name Titanic

#Titanic - this data has 4 dimensions, class, sex, age and survival

# margin.table(Titanic,1)  # count according to class
# margin.table(Titanic,4)  # count according to survival
# margin.table(Titanic)  # gives total count if index is not provided
print(Titanic)
print(margin.table(Titanic,3))
barplot(margin.table(Titanic,4),xlab="Survived")
barplot(margin.table(Titanic,2))

#Bar Chart
mydata100<-data.frame(
  workshop=c("R","Angular 2","R","DevOps","Stata","R","Stata","R","DevOps","Stata","Angular 2",
              "R","Stata","R","DevOps","R","R","Stata","R","DevOps","DevOps","Angular 2"),
  gender=c("Female","male","male","Female","Female","Female","male","male","Female","male","Female",
            "Female","male","male","male","male","Female","male","male","Female","male","Female"),
  q1=c(4,3,3,5,4,5,3,4,4,5,5,3,3,5,4,5,3,3,5,4,5,4),
  q2=c(3,4,2,3,3,4,3,5,4,4,3,4,3,3,3,4,3,5,4,4,3,3),
  q3=c(4,3,5,5,4,3,4,4,5,5,4,3,4,4,3,4,4,3,4,4,3,4),
  q4=c(4,3,3,5,4,5,3,3,4,5,5,5,4,5,5,4,5,5,4,5,5,4),
  pretest=c(70,84,34,70,90,88,65,74,89,10,93,87,76,69,45,59,80,77,90,92,83,74),
  posttest=c(84,74,59,90,98,91,84,89,93,45,97,97,89,91,67,78,90,95,97,92,93,85)
)

print(mydata100)
count<-table(mydata100$workshop)
print(count)
barplot(count, main="Workshop Data", 
        xlab="Workshop Names")

#Horizontal Bar Plot
barplot(count, main="Workshop Data", horiz=TRUE,
        names.arg=c("Trg1", "Trg2", "Trg3","Trg4"),
        border="red",
        col="blue",
        density=20)

# Stacked Bar Plot with Colors and Legend

table(mydata100$gender,mydata100$workshop)

counts <- table( mydata100$gender,mydata100$workshop)
print(counts)
barplot(counts,main="Training date by workshop and gender",
        xlab="Workshop name",col=c("pink","blue"),
        legend=rownames(counts), beside=TRUE)

barplot(counts, main="Training date by workshop and gender",
        xlab="Workshop", col=c("darkblue","red"),
        legend = rownames(counts))

# Grouped Bar Plot
counts <- table( mydata100$gender,mydata100$workshop)
barplot(counts, main="Training date by workshop and gender",
        xlab="Workshop", col=c("darkblue","red"),
        legend = rownames(counts), beside=TRUE)

# Fitting Labels 
par(las=2) # make label text perpendicular to axis
par(mar=c(5,8,4,2)) # increase y-axis margin.

counts <- table(mydata100$workshop)
barplot(counts, main="Workshop Distribution",
        horiz=TRUE,   cex.names=0.8)

uk2007 = data.frame(Commodity =
                    factor(c("Cow milk", "Wheat", "Sugar beet", "Potatoes", "Barley"),
                    levels = c("Cow milk", "Wheat", "Sugar beet", "Potatoes", "Barley")),
                    Production = c(14023, 13221, 6500, 5635, 5079))



print(uk2007)

barplot(uk2007$Production, names = uk2007$Commodity,
        xlab = "Commodity", ylab = "Production (1,000 MT)",
        main = "UK 2007 Top 5 Food and Agricultural Commodities")

text(uk2007$Commodity,uk2007$Production,uk2007$Production,cex=1.0, pos=1, col="blue")

# On the chart, click where you would like the text to appear
temp <- locator(1) 


text(temp,"Use the text() with or without the locator() function")

#Bar chart for scores of participants where learning is in AL and ILT mode
learning<-data.frame(
  range=c("90-100","80-89","70-79","60-69","50-59","0-50"),
  AL=c(8,9,4,32,8,9),
  ILT=c(0,31,8,32,11,0)
)
print(learning)
v1<- as.vector(rbind(learning$AL,learning$ILT))

v2<- c("90-100","90-100","80-89","80-89","70-79","70-79",
       "60-69","60-69","50-59","50-59","0-50","0-50")

barplot(v1,names=v2,beside=T, 
        col=c("aquamarine3","coral"),
        legend = c("AL","ILT"))




