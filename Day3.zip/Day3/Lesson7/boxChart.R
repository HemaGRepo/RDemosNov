#Box Plot and Stripchart

#Using built in dataset airquality
str(airquality)
boxplot(airquality$Ozone)

hist(airquality$Ozone,breaks=c(0,5,10,15,20,25,35,50,150,200))
boxplot(airquality$Ozone,
        main = "Mean ozone in parts per billion at Roosevelt Island",
        xlab = "Parts Per Billion",
        ylab = "Ozone",
        col = "orange",
        border = "brown",
        horizontal = TRUE,
        notch = TRUE
)

#Create data 
names=c(rep("A", 20) , rep("B", 8) , rep("C", 30), rep("D", 80))
value=c( sample(2:5, 20 , replace=T) , sample(4:9, 8 , replace=T), 
         sample(1:7, 30 , replace=T), sample(3:8, 80 , replace=T) )
data=data.frame(names,value)
print(value)
data


#Draw the boxplot, with the number of individuals per group
a=boxplot(data$value ~ data$names , col=rgb(0.1,0.9,0.3,0.4) , ylim=c(1,10))
plot(a)
text( c(1:nlevels(data$names)) , a$stats[nrow(a$stats) , ]+0.5 , paste("n = ",table(data$names),sep="")  )

#----------------Demo 2------
#Creating data 
names=c(rep("A", 20) , rep("B", 20) , rep("C", 20), rep("D", 20))
value=c( sample(2:5, 20 , replace=T) , sample(6:10, 20 , replace=T), 
         sample(1:7, 20 , replace=T), sample(3:10, 20 , replace=T) )
data=data.frame(names,value)

#Classic boxplot (A-B-C-D order)
boxplot(data$value ~ data$names)

# I reorder the groups order : I change the order of the factor data$names
data$names=factor(data$names , levels=levels(data$names)[c(1,4,3,2)])

#The plot is now ordered !
boxplot(data$value ~ data$names , col=rgb(0.3,0.5,0.4,0.6) , ylab="value" , 
        xlab="names in desired order")




