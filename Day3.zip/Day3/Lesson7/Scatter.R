marks<-c(89,45,67,34,20,10)
plot(marks)
barplot(marks)
hist(marks)
pie(marks)

input<-data.frame(weight=mtcars$wt,mileage=mtcars$mpg)
input

plot(x = input$weight,y = input$mileage, 
     xlab = "Weight",   ylab = "Milage",
     xlim = c(2.5,5),   ylim = c(15,30),
     main = "Weight vs Milage"
)


pairs(~wt+mpg+disp+cyl,
      data = mtcars,
      main = "Scatterplot Matrix")

pairs(~wt+mpg+disp,
      data = mtcars,
      main = "Scatterplot Matrix")


mydata100<-data.frame(
  workshop=c("R","Angular 2","R","DevOps","Stata","R","Stata","R","DevOps","Stata","Angular 2",
             "R","Stata","R","DevOps","R","R","Stata","R","DevOps","DevOps","Angular 2"),
  gender=c("Female","male","male","Female","Female","Female","male","male","Female","male","Female",
           "Female","male","male","male","male","Female","male","male","Female","male","Female"),
  q1=c(4,3,3,5,4,5,3,4,4,5,5,3,3,5,4,5,3,3,5,4,5,4),
  q2=c(3,4,2,3,3,4,3,5,4,4,3,4,3,3,3,4,3,5,4,4,3,3),
  q3=c(4,3,5,5,4,3,4,4,5,5,4,3,4,4,3,4,4,3,4,4,3,4),
  q4=c(4,3,3,5,4,5,3,3,4,5,5,5,4,5,5,4,5,5,4,5,5,4),
  pretest=c(70,84,34,70,90,88,65,74,89,10,93,87,76,69,45,59,80,77,90,92,83,74),
  posttest=c(84,74,59,90,98,91,84,89,93,45,97,97,89,91,67,78,90,95,97,92,93,85)
)
pairs(~pretest+posttest,data=mydata100,main="Pre vs Post Test")

pairs(~pretest+posttest+q1,
      data=mydata100,main="Pre vs Post Test")

employee<-data.frame(
  age=c(34,56,34,35,22,28,86,52,45,40,39,27),
  salary=c(23456,34567,76543,89898,54367,45363,67676,20909,45454,12987,34872,59345),
  exp=c(2,5,4,6,7,3,8,9,10,3,4,5)
)

plot(employee$age,employee$salary)

plot(employee$salary,employee$age)

pairs(~age+salary,data=employee)

pairs(~age+salary+exp,data=employee)






