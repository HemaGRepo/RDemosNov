# Pie chart

expenditure<-c("Housing"=600,"Food"=300,"Clothes"=150,"Shopping"=100,"Others"=90)
pie(expenditure)

pie(expenditure,
    labels=paste(names(expenditure)," - ",expenditure),
    main="Monthly Expenditure Breakdown",
    col=c("red","orange","yellow","blue","green"),
    border="brown",
    clockwise=TRUE
)


slices <- c(10, 12,4, 16, 8)
pie(slices)
lbls <- c("US", "UK", "Australia", "Germany", "France")

pie(slices, labels = lbls, main="Pie Chart of Countries")

# Pie Chart with Percentages
slices <- c(10, 12, 4, 16, 8) 
lbls <- c("US", "UK", "Australia", "Germany", "France")
pct <- round(slices/sum(slices)*100)
#lbls <- paste(lbls, pct) # add percents to labels 
lbls <- paste(lbls,pct,"%",sep=" ") # ad % to labels 
pie(slices,labels = lbls, col=rainbow(length(lbls)),
    main="Pie Chart of Countries")

# 3D Exploded Pie Chart
install.packages("plotrix")
library(plotrix)
slices <- c(10, 12, 4, 16, 8) 
lbls <- c("US", "UK", "Australia", "Germany", "France")
lbls <- paste(lbls," - ",slices,sep=" ")
pie3D(slices,labels=lbls,explode=0.1,
      main="Pie Chart of Countries ")


# Pie Chart from data frame with Appended Sample Sizes
mytable <- table(iris$Species)
lbls <- paste(names(mytable), "\n", mytable, sep="")
pie(mytable, labels = lbls, 
    main="Pie Chart of Species\n (with sample sizes)")
