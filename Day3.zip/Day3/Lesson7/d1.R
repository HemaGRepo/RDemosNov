marks<-c(34,45,67,8,9,23,90,57,71,20)
plot(marks)

x <- seq(-pi,pi,0.1)
plot(x, sin(x), main="The Sine Function", ylab="sin(x)",xlab="-Pi to Pi")

plot(c(1,2),c(3,5)) 