dev.copy(png,'myplot.png')  

age <- c(17,18,18,17,18,19,18,16,18,18)
table(age)
barplot(table(age),
        main="Age Count of 10 Students",
        xlab="Age",
        ylab="Count",
        border="red",
        col="blue",
        density=10
)
dev.off()
