#Define custom values for x-asix. Use xaxt to remove default values
par(pch=11,col=629)
plot(1:10, xaxt = "n", xlab='Some Letters',type="b")
axis(1, at=1:10, labels=letters[1:10])

max.temp=c(10,34,57,22,40,39,18)
names(max.temp)<-c("Sun","Mon","Tues","Wed","Thur","Fri","Sat")
print(max.temp)
par(mfrow=c(2,3))    # set the plotting area into a 1*2 array

barplot(max.temp, main="Barplot")
pie(max.temp, main="Piechart", radius=1)

jpeg("Newplot12Dec.jpg")
plot(1:10, xaxt = "n", xlab='Some Letters',type="b")
axis(1, at=1:10, labels=letters[1:10])
dev.off()


jpeg("plot1220.jpg")
attach(mtcars)
par(mfrow=c(1,1),fg="blue",pch=2,col.lab="blue")
plot(wt,mpg, main="Scatterplot of wt vs. mpg")
dev.off()

plot(wt,disp, main="Scatterplot of wt vs disp")


# Add boxplots to a scatterplot
par(fig=c(0,0.5,0,0.8), new=TRUE)
plot(mtcars$wt, mtcars$mpg, xlab="Car Weight",
     ylab="Miles Per Gallon")
par(fig=c(0,0.5,0.55,1), new=TRUE)
boxplot(mtcars$wt, horizontal=TRUE, axes=FALSE)
par(fig=c(0.65,1,0,0.8),new=TRUE)
boxplot(mtcars$mpg, axes=FALSE)
mtext("Enhanced Scatterplot", side=3, outer=TRUE, line=-3)
