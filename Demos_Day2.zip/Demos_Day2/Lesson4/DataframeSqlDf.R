employee<-data.frame(
  eid=c(101,127,145,765,390,200),
  names=c("Ram","Shyam","Suraj","Krish","Vani","Laya"),
  desig=c("TL","SSE","Mgr","Mgr","SE","TL"),
  salary=c(12000,23456,67843,89234,20865,78787),
  deptid=c(10,20,30,10,20,20),
  stringsAsFactors = FALSE
)
print(employee)


department<-data.frame(
  deptid=c(10,20,30),
  dname=c("LnD","Sogeti","Infra"),
  loc=c("Chennai","Pune","Mumbai")
)

print(department)

#package called as sqldf -> execute sql queries on Dataframes
#install.packages("sqldf")
library(sqldf)

sqldf("Select * from employee where salary<35000")

sqldf("Select * from employee order by salary desc")

sqldf("Select eid,names,salary from employee order by salary")

sqldf("Select sum(salary),desig from employee Group by desig")

salaryData<-sqldf("Select count(Salary) from employee Group by desig")

salaryDF<- sqldf("Select sum(Salary),Desig from employee where desig!='TL' Group by desig ")

sqldf("select names,dname,loc from employee e,department d where e.deptid=d.deptid")