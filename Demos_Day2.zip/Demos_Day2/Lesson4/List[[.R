a <- list(a = 1, b = 2)
a[[1]]
## [1] 1
a[["a"]]
## [1] 1
# If you do supply a vector it indexes recursively
b <- list(a = list(b = list(c = list(d = 1))))
b[[c("a", "b", "c", "d")]]
## [1] 1
# Same as
b[["a"]][["b"]][["c"]][["d"]]
## [1] 1