empNames<-c("Ram","Sita","Lakshman","Bharath","Ravan")
desig<-c("Mgr","TL","SSE","SE","Mgr")
salary<-c(89898,67676,34544,66677,56534)
locs<-c("Pune","Mumbai","Pune","Chennai","Mumbai")

employeeDB<-data.frame(
  enames=empNames,
  desigs=desig,
  sal=salary,
  location=locs
)

subset(employeeDB,sal>60000)

subset(employeeDB,sal>60000,select=c(enames,sal))

subset(employeeDB,subset = (sal>60000 & sal<70000)|desig=='SSE')

employeeDB

print(airquality)

subset(airquality, Temp > 80, select = c(Ozone, Temp))

subset(airquality, Day == 1, select = -Temp)

subset(airquality, select = Ozone:Wind)

with(airquality, subset(Ozone, Temp > 80))

## sometimes requiring a logical 'subset' argument is a nuisance
print(state.x77)
nm <- rownames(state.x77)
print(nm)
start_with_M <- nm %in% grep("^M", nm, value = TRUE)
subset(state.x77, start_with_M, Illiteracy:Murder)
# but in recent versions of R this can simply be
subset(state.x77, grepl("^S", nm), Illiteracy:Murder)