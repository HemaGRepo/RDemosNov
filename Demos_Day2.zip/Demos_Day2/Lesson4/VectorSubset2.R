#Character vectors to return elements with matching names.

(y <- setNames(x, letters[1:4]))
##   a   b   c   d 
## 2.1 4.2 3.3 5.4
y[c("d", "c", "a")]
##   d   c   a 
## 5.4 3.3 2.1
# Like integer indices, you can repeat indices
y[c("a", "a", "a")]
##   a   a   a 
## 2.1 2.1 2.1
# When subsetting with [ names are always matched exactly
z <- c(abc = 1, def = 2)
z[c("a", "d")]
## <NA> <NA> 
##   NA   NA