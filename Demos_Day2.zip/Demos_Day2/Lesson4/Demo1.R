emp.data <- data.frame(
  emp_id = c (1:5), 
  emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),
  salary = c(623.3,515.2,611.0,729.0,843.25), 
  
  start_date = as.Date(c("2012-01-01", "2013-09-23", "2014-11-15", "2014-05-11",
                         "2015-03-27")),
  stringsAsFactors = FALSE
)
names(emp.data)

head(emp.data,2)
tail(emp.data,3)

sum(emp.data$salary)
mean(emp.data$salary)


employee<-data.frame(
  eid=c(101,127,145,765,390,200),
  names=c("Ram","Shyam","Suraj","Krish","Vani","Laya"),
  desig=c("TL","SSE","Mgr","Mgr","SE","TL"),
  salary=c(12000,23456,67843,89234,20865,78787),
  stringsAsFactors = FALSE
)
print(employee)

# Print the employee details sorted by salary
employee[order(employee[,"salary"]),]

employee[3:5,2]#Get a single column - u get a list
employee[3:5,2:3]

employee[employee$salary<=25000,]

#Modify salary of Row #1
employee[1,"salary"]<-34000

# Add rows to data frame
employee<-rbind(employee,list(433,"Tina","TL",34876))

#Add columns to data frame
employee<-cbind(employee,"location"=c("MUM","CH","PU","BLR","HYD","MUM","CH"))

#Delete a column
employee$location=NULL

employee<-employee[-4,]
print(employee)


print(max(employee$salary))

employee[employee$salary==max(employee$salary),]

sort(employee$salary)

print(employee[3,])

install.packages("sqldf")
library(sqldf)

sqldf("Select sum(Salary),desig from employee Group by desig")

sqldf("Select * from employee order by salary")

sqldf("Select count(Salary) from employee Group by desig")
salaryData<-sqldf("Select count(Salary) from employee Group by desig")

salaryDF<- sqldf("Select sum(Salary),Desig from employee where desig!='TL' Group by desig ")

salaryDF$`sum(Salary)`















