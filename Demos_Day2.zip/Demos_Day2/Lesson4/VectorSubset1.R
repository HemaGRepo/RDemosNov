x <- c(2.1, 4.2, 3.3, 5.4)
  
  x[c(3, 1)]
## [1] 3.3 2.1
x[order(x)]
## [1] 2.1 3.3 4.2 5.4
# Duplicated indices yield duplicated values
x[c(1, 1)]
## [1] 2.1 2.1
# Real numbers are silently truncated to integers
x[c(2.1, 2.9)]
## [1] 4.2 4.2
#Negative integers omit elements at the specified positions:
  
  x[-c(3, 1)]
## [1] 4.2 5.4
#You can't mix positive and negative integers in a single subset:
  
  x[c(-1, 2)]
## Error in x[c(-1, 2)]: only 0's may be mixed with negative subscripts
#Logical vectors select elements where the corresponding logical value is TRUE. This is probably the most useful type of subsetting because you write the expression that creates the logical vector:
  
  x[c(TRUE, TRUE, FALSE, FALSE)]
## [1] 2.1 4.2
x[x > 3]
## [1] 4.2 3.3 5.4
#If the logical vector is shorter than the vector being subsetted, it will be recycled to be the same length.

x[c(TRUE, FALSE)]
## [1] 2.1 3.3
# Equivalent to
x[c(TRUE, FALSE, TRUE, FALSE)]
## [1] 2.1 3.3
#A missing value in the index always yields a missing value in the output:
  
  x[c(TRUE, TRUE, NA, FALSE)]
## [1] 2.1 4.2  NA
#Nothing returns the original vector. This is not useful for vectors but is very useful for matrices, data frames, and arrays. It can also be useful in conjunction with assignment.

x[]
## [1] 2.1 4.2 3.3 5.4
#Zero returns a zero-length vector. This is not something you usually do on purpose, but it can be helpful for generating test data.

x[0]
## numeric(0)