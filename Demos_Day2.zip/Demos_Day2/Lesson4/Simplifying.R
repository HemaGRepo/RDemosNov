#Atomic vector: removes names.

x <- c(a = 1, b = 2)
x[1]
## a 
## 1
x[[1]]
## [1] 1
#List: return the object inside the list, not a single element list.

y <- list(a = 1, b = 2)
str(y[1])
## List of 1
##  $ a: num 1
str(y[[1]])
##  num 1
#Factor: drops any unused levels.

z <- factor(c("a", "b"))
z[1]
## [1] a
## Levels: a b
z[1, drop = TRUE]
## [1] a
## Levels: a
#Matrix or array: if any of the dimensions has length 1, drops that dimension.

a <- matrix(1:4, nrow = 2)
a[1, , drop = FALSE]
##      [,1] [,2]
## [1,]    1    3
a[1, ]
## [1] 1 3
#Data frame: if output is a single column, returns a vector instead of a data frame.

df <- data.frame(a = 1:2, b = 1:2)
print(df)
str(df[1])
## 'data.frame':    2 obs. of  1 variable:
##  $ a: int  1 2
str(df[[1]])
##  int [1:2] 1 2
str(df[, "a", drop = FALSE])
## 'data.frame':    2 obs. of  1 variable:
##  $ a: int  1 2
str(df[, "a"])
##  int [1:2] 1 2

