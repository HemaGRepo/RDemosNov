library(RCurl)
read.table.url("http://lib.stat.cmu.edu/jcgs/tu",skip=4,header=T)
url.show("http://lib.stat.cmu.edu/datasets/csb/ch11b.txt")
beaver<-read.table.url("http://lib.stat.cmu.edu/datasets/csb/ch11b.dat",
                       col.names=c("obsnum","day","time","temperature","activity"),row.names=1)
