# Reading Data from a fixed width file

person_info<-read.fwf("fwf_data.txt",widths=c(10,10,4,-1,4,-1,2)) 

person_info[1,]

dfrm1<-read.table("inp.txt")
dfrm1$V3

#Read contents from the file with heading
data1<-read.table("inp.txt",header = TRUE,stringsAsFactors = FALSE)
data1$FirstName

#Read using ; as separator

dfrm4 <- read.table("input2.txt",sep = ";",header = TRUE,stringsAsFactors = FALSE)
dfrm4


dfrm <- read.table("input.txt",header=TRUE,stringsAsFactor=FALSE)
dfrm

dfrm <- read.table("input.txt",header=TRUE,na.strings=c("-",";","=","NA") )
dfrm


d2<-read.table("RTest.txt", header = TRUE, stringsAsFactors = FALSE)
d2

d1 <- read.table("RTest.txt",header=TRUE, stringsAsFactor=FALSE)
d1

sum(dfrm$Year1,na.rm = TRUE)

dfrm2 <- read.table("inputSep",sep="-",
                    na.strings="_",header=TRUE, stringsAsFactor=FALSE)
dfrm2

dfrm1$FirstName



#Reading data from Multiple files
fv=c("input.txt","input3.txt")

readFromFiles<-function(fileVector){
  cntr<-1
  for(f in fileVector)
  {
    temp<-read.table(f,header=TRUE,na.strings=c("-",";","=","NA") )
    if(cntr==1)
    {
       op<-temp
    }
    else
    {
      op<-rbind(op,temp)
    }
    cntr<-cntr+1
  }
  print(op)
}

readFromFiles(fv)

temp<-read.table("input3.txt",header=TRUE,na.strings=c("-",";","=","NA"))




