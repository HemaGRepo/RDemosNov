data <- read.csv("input.csv",as.is = TRUE)
print(data)
data$name

save(data,file="file1912.txt")
dput(data,file="file1912_2.txt")
dump("data",file="file1912_3.txt")