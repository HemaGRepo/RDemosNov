structure(list(eid = c(101, 127, 145, 765, 390, 200), names = c("Ram", 
"Shyam", "Suraj", "Krish", "Vani", "Laya"), desig = c("TL", "SSE", 
"Mgr", "Mgr", "SE", "TL"), salary = c(12000, 23456, 67843, 89234, 
20865, 78787), deptid = c(10, 20, 30, 10, 20, 20)), .Names = c("eid", 
"names", "desig", "salary", "deptid"), row.names = c(NA, -6L), class = "data.frame")
