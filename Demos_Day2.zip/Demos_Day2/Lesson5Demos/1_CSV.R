#READING AND WRITING DATA - CSV FILE
# Create a data frame.
data <- read.csv("input.csv",stringsAsFactors = FALSE)
print(data)
data$name

# Get the max salary from data frame.
sal <- max(data$salary)
print(sal)

retval <- subset(data, salary == max(salary))
print(retval)

retval <- subset( data, dept == "IT")
print(retval)

retval <- subset(data, as.Date(start_date) > as.Date("2014-01-01"))
print(retval)

retval <- subset(data, as.Date(start_date) > as.Date("2014-01-01"))

# Write filtered data into a new file.
write.csv(retval,"demoOp.csv",row.names = FALSE)

# TrainingData
trgInfo<-read.csv("trgData.csv",stringsAsFactors = FALSE)

trgByCategory<-table(trgInfo$Category)
print(trgByCategory)

trgByRT<-table(trgInfo$RequestType)
print(trgByRT)

library(sqldf)
sqldf("select count(*),CourseName from trgInfo
      group by CourseName
      having count(*)>10 order by CourseName desc")


newdata <- read.csv("output_12132017.csv")
print(newdata)

tbl <- read.csv("http://www.example.com/download/data.csv")

res<-read.csv("https://raw.githubusercontent.com/vincentarelbundock/Rdatasets/master/csv/datasets/AirPassengers.csv")
res

wages<-read.csv("https://raw.githubusercontent.com/vincentarelbundock/Rdatasets/master/csv/Ecdat/Bwages.csv")
wages

library(sqldf)
sqldf("Select avg(wage),exper from wages group by exper")

sqldf("Select avg(wage),educ from wages group by educ")

sqldf("Select avg(wage),exper,educ from wages group by exper,educ")









