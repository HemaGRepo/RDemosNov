  eid names desig salary deptid
1 101   Ram    TL  12000     10
2 127 Shyam   SSE  23456     20
3 145 Suraj   Mgr  67843     30
4 765 Krish   Mgr  89234     10
5 390  Vani    SE  20865     20
6 200  Laya    TL  78787     20
  names  dname     loc
1   Ram    LnD Chennai
2 Shyam Sogeti    Pune
3 Suraj  Infra  Mumbai
4 Krish    LnD Chennai
5  Vani Sogeti    Pune
6  Laya Sogeti    Pune
