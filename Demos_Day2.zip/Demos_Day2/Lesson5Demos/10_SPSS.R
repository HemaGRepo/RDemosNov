library(foreign) 

dataset = read.spss("Employee.sav", to.data.frame=TRUE)
print(dataset$jobcat)
table(dataset$jobcat)

anx= read.spss("Anxiety.sav", to.data.frame=TRUE)
print(anx)

inp=read.dta("medical.dta")
print(inp)

head(inp)

sqldf("select count(*) from inp where age>60")