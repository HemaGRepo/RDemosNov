#install.packages("RODBC")
library(RODBC)


# Create a DSN - Data Source Name
# Go to Control Panel -> Administrative Tools ->Data Sources (ODBC) ->right click Open ->Add
# and create a new DSN
#The DSN created is FebDS, JanDSN,RDSN
#A new DSN is created with Name MayDS -> Connect me to the Oracle DB with service name orcl and username =hema

connect1<-odbcConnect("MayDS",uid = "hema",pwd="corp@123",believeNRows=FALSE)
odbcGetInfo(connect1)

#Reading from a Database
jobDf<-sqlQuery(connect1,"SELECT * FROM jobs")
write.csv(jobDf,file = "JobData.csv")


#CREATE a Data FRAME
pid<-106:109
pnames<-c("Bat","Ball","Flowers","Furniture")
price<-c(34526,450,1000,8000)
isAvailable<-c(T,F,T,F)

productDetails<-data.frame(
  productId=pid,
  prodNames=pnames,
  prodPrice=price,
  inStock=isAvailable,
  stringsAsFactors = FALSE
)

#Create a DB table and write the dataframe to that table

sqlSave(connect1,productDetails,tablename = "AMAZONCATLOG",
        rownames = FALSE,append = TRUE)
close(connect1)


