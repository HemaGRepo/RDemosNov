check <- function(x) {
  data <- read.csv("input.csv")
  retval <- subset(data, as.Date(start_date) > as.Date(x))
  print(retval)
  write.csv(retval,"OpFromFunction.csv")
}

check("2014-01-01")

library(XML)
d1<-readHTMLTable("https://nssdc.gsfc.nasa.gov/planetary/factsheet",which=1)
d1


d2<-readHTMLTable("https://developer.mozilla.org/en-US/docs/Learn/HTML/Tables/Basics",which=1)
d2


url <- 'http://www.example.com/data/table.html'
tbls <- readHTMLTable(url)
