#Connecting to Database - Oracle
install.packages("RODBC")
library(RODBC)

# Go to Control Panel -> Administrative Tools ->ODBC and create a new DSN

c1<-odbcConnect("JanDSN",uid="hema",pwd="hema676412",believeNRows=FALSE)
odbcGetInfo(c1)


empData<-sqlQuery(c1,"SELECT * from hema.emp")
empData

products<-sqlQuery(c1,"SELECT * FROM hema.product")
print(products)

#Read Data from SPSS file and store it in DB

library(foreign) 

dataset = read.spss("Employee.sav", to.data.frame=TRUE)

sqlSave(c1,dataset,'taxPayers')




c1<-odbcConnect("CapgeminiDS",uid="hema",pwd="hema676412",believeNRows=FALSE)
odbcGetInfo(c1)
empData<-sqlQuery(c1,"SELECT * from hema.emp")
empData

close(c1)

e1<-data.frame("eid"=empData$EMPNO,"ename"=empData$EMPNAME,"sal"=empData$SALARY)
e1

#Create a table and copy the data frame e1 into that table
accId<-c(4565,3456,8998,2345,3610,3676)
custName<-c("Ram","Lakshman","Sita","Sam","Suhail","Alfred")
balance<-c(89765.45,34239.34,218984.22,46738.50,20909.70,98654.54)
accType<-c("SA","CA","CA","SA","CA","SA")

AccountDF<-data.frame(
  accountNumber=accId,customers=custName,accBalance=balance,type=accType,
  stringsAsFactors = FALSE
)

print(AccountDF)

sqlSave(c1,AccountDF,"Account1801",append = TRUE)



#Table name as Account1801

##############################################
e2<-data.frame("eid"=empData$EMPNO,"sal"=empData$SALARY)
e2
sqlSave(c1,e2,"ESal")

close(c1)

c2<-odbcConnect("CapgeminiDS",uid="hema",pwd="hema676412",believeNRows=FALSE)
odbcGetInfo(c2)
empData2<-sqlQuery(c2,"SELECT * from hema.employees")

empData2


#DSN Created is newDb

channel <- odbcConnect("DecDS1", uid="hema", pwd="hema676412", believeNRows=FALSE)
odbcGetInfo(channel)


dataframe<-sqlQuery(channel,"SELECT * FROM hema.employees")
print(dataframe)

t<-sqlQuery(channel,"SELECT * FROM hema.temperature")
print(t)
plot(t$TEMP,t$CITY)
pie(t$TEMP,t$CITY)

sqlUpdate(channel,"UPDATE hema.emp SET salary=1000")















