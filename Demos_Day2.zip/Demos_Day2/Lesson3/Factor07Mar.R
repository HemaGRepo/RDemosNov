#Factor - Categorical data

desig<-c("SE","TL","Mgr","SSE","SSE","SE","TL","Mgr","Mgr","SE","SSE","TL","TL")
is.factor(desig)

f1<-factor(desig)
#1) Unique values in desig are taken - SE,SSE,TL,Mgr
#2) They are sorted - Mgr,SE,SSE,TL
#3) Levels= Mgr,SE,SSE,TL (ie. The sorted unique values are the levels)
#4) Numeric values are given for levels 1-Mgr,2-SE,3-SSE,4-TL
#5) Internall the data is stored in f1 using numeric values
#6) actual data ="SE","TL","Mgr","SSE","SSE","SE","TL","Mgr","Mgr","SE","SSE","TL"
#7) internally stored as=2,4,1,3,3,2,4...
is.factor(f1)
print(f1)
str(f1)

f1[1]
f1[c(3,4,6)]

print(f1)
#f1[1]=SE, he is promoted to SSE
f1[1]<-'SSE'
print(f1)
#How to add a level VP to f1

levels(f1)<-c(levels(f1),"VP")
print(f1)

#f1[3]=Mgr, he is promoted to VP
f1[3]<-'VP'
print(f1)



f2<-factor(desig,levels = c("SE","SSE","TL","Mgr","VP","Director"))
print(f2)
#f2[3]=Mgr, he is promoted to VP
f2[3]<-'VP'
print(f2)

#Table - tabulate the data
table(f2)
table(desig)





