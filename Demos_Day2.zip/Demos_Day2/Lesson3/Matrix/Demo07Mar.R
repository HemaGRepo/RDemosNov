#Matrix- 2D data structure

temp<-c(23,34,45,19,18,17,34,34,33,23,35,28)

#matrix() - used to create a matrix
avgTemp<-matrix(temp,nrow=4,ncol=3)
print(avgTemp)

# Data is populated in a columnwise manner

avgTemp<-matrix(temp,nrow=4,ncol=3,byrow=TRUE)
print(avgTemp)

# You can give names for rows and cols
rnames=c("Chennai","Mumbai","Delhi","Kolkatta")
#cnames=c("Jan","Feb","Mar")
cnames=month.abb[1:3]

dimnames(avgTemp)<-list(rnames,cnames)
print(avgTemp)


#Create a matrix with names
avgTemp1<-matrix(temp,nrow=4,ncol=3,byrow=TRUE,
                dimnames=list(rnames,cnames))
print(avgTemp1)


#Appraisal Matrix
appData<-c(1,3,2,3,1,1,1,1,2,3,4,2)
rownames<-c("2016","2017","2018")
colnames<-c("Q1","Q2","Q3","Q4")

appMatrix<-matrix(appData,nrow=3,
                  dimnames = list(rownames,colnames))
print(appMatrix)


#User info
userData<-c(101,"Ram","ram@gmail.com",102,"Sita","sita@cg.com",
            103,"Venkat","venkat@yahoo.com")

userMatrix<-matrix(userData,nrow=3,byrow = TRUE,
                   dimnames = list(
                     c("User1","User2","User3"),
                     c("EmpId","Name","Email")
                   ))
print(userMatrix)


d1<-1:7
m1<-matrix(d1,nrow=4,ncol=3) #4*3=12, but data is only 7 - recycle rule
print(m1)

#Accessing a matrix
print(avgTemp)
avgTemp[2,3]
avgTemp["Mumbai","Mar"]
avgTemp["Delhi","Jan"]

# Get me the entire 3rd row
avgTemp[3,]
avgTemp[,1]

#Get me Feb data
avgTemp[,"Feb"]

#Get me Chennai data
avgTemp["Chennai",]

#Get me Jan and Feb data for Mumbai
avgTemp["Mumbai",c("Jan","Feb")]

#Get me Jan and Feb data for Mumbai and Kolkatta
avgTemp[c("Mumbai","Kolkatta"),c("Jan","Feb")]

print(userMatrix)

id<-as.numeric(userMatrix[,"EmpId"])
print(id)

print(appMatrix)
#Fetch 2016 and 2017, Q3 and Q4 appraisal data
appMatrix[c("2016","2017"),c("Q3","Q4")]

print(avgTemp)
# How to append columns for avgTemp for April and May
data<-c(23,24,25,26,36,37,34,30)
newMatrix<-matrix(data,nrow=4,
          dimnames=list(c("Chennai","Mumbai","Delhi","Kolkatta"),
                        c("Apr","May")))
print(newMatrix)

# To append columns -> cbind() -> column bind

avgTemp<-cbind(avgTemp,newMatrix)
print(avgTemp)

# Add temp data for Bglr also
blrData<-matrix(c(12,13,20,34,40),
                nrow=1,
                dimnames=list(c("Bangalore"),c()))
print(blrData)

#To append row ->rbind() -> row bind
avgTemp<-rbind(avgTemp,blrData)
print(avgTemp)


#Modifying data

print(avgTemp)

#Change the Feb temp of Blr
avgTemp[5,2]<-40
print(avgTemp)

#Change the Jan temp of Blr
avgTemp[5,"Jan"]<-40
print(avgTemp)

avgTemp[2,]<-c(30,31,32,34,37)
print(avgTemp)

avgTemp[3,]<-c(30,31,32,NA,NA)
print(avgTemp)

which(is.na(avgTemp))
which(is.na(avgTemp),arr.ind = TRUE)


m1<-matrix(1:12,nrow=3)
m2<-matrix(31:42,nrow=3)

m1[2,]<-c(NA,2,4,NA)
print(m1);print(m2)

m1+m2
m1-m2
m1*m2

print(avgTemp)
t(avgTemp)
t(userMatrix)


m1<-matrix(1:12,nrow=3)
m2<-matrix(1:6,nrow=2)
print(m1);print(m2)
m1+m2













