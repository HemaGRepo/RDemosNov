# Matrix - 2 dimensional array - rows and columns - elements of same type

vals<-c(1,3,5,7,9,2,4,6,8,10,11,12)

# Populate these vals in a 3*4 matrix

m1<-matrix(vals,nrow=3,ncol=4)

# By default values are populated in a columnar manner

# 1 7 4 10
# 3 9 6 11
# 5 2 8 12

print(m1)


m2<-matrix(vals,nrow=3,ncol=4,byrow = TRUE)

# By default values are populated in a columnar manner

# 1  3  5  7
# 9  2  4  6
# 8 10 11 12

print(m2)

marks<-c(67,34,51,78,12,34,96,89,90,66,19,56)
rownames<-c("Sophie","Annie","Simon","Alwin")
colnames<-c("Angular","Cloud","DevOps")

# Store data for 4 students in 3 subjects
stuMarks<-matrix(marks,nrow=4,dimnames=list(rownames,colnames))
print(stuMarks)

stuMarks["Simon",]

stuMarks[c(F,F,T,F),]
t1<-as.table(stuMarks)
print(t1)
t1['Arun','Angular']


print(t(stuMarks))

dim(stuMarks)
stuMarks[3,2]
#Access the 2nd row
stuMarks[2,]
stuMarks[c(1,2),]

#Access the second column
stuMarks[,2]
stuMarks[,c(1,2)]

# Access the cloud and devops marks of Shyam and Prabhu

stuMarks[c(1,4),c(2,3)]

stuMarks["Arun",]

stuMarks[c("Arun","Tina"),]

stuMarks[c("Arun","Prabhu"),c("Angular","DevOps")]

print(m1)
print(m2)

m1+m2
m1-m2
m1*m2
m1/m2

print(m1)
print(t(m1))

m1*5

m3<-matrix(10:12,nrow=3)
print(m3)

m1+m3
m1-m3

#RBind and CBind

marks<-c(67,34,51,78,12,34,96,89,90,66,19,56)
rownames<-c("Shyam","Arun","Tina","Prabhu")
colnames<-c("Angular","Cloud","DevOps")

# Store data for 4 students in 3 subjects
stuMarks<-matrix(marks,nrow=4,dimnames=list(rownames,colnames))
print(stuMarks)


# What if two more students are added

newMarks<-c(10,20,30,40,50,60)
newstudNames<-c("Ian","John","Jack","Tim","Fred","Steve")
nMarks<-matrix(newMarks,nrow=2,dimnames = list(newstudNames,c("A","B","C")))

print(nMarks)

smarks<-rbind(stuMarks,nMarks)
print(smarks)

# What if scores in 1 more subject should be added
bigData<-matrix(c(56,34,90,67),nrow=4,dimnames=list(rownames,c("Big Data")))
print(bigData)

cbind(stuMarks,bigData)


# Marks in BigData and Python for 3 students
Marks<-c(10,20,30,40,50,60)
participants<-c("Ian","John","Jack")
courses<-c("BigData","Python")
scoreMatrix<-matrix(Marks,nrow=3,dimnames = list(participants,courses))
print(scoreMatrix)

rscores=c(78,89,34)
course=c("R")
rscore=matrix(rscores,nrow=3,dimnames=list(participants,course))
print(rscore)

cbind(scoreMatrix,rscore)





