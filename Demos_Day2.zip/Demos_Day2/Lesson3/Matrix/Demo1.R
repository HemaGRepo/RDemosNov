values<-c(1,2,3,4,5,6,7,8,9,10,11,12)#1:12
m1<-matrix(values,nrow=2,ncol=6)
print(m1)

m1<-matrix(values,nrow=2,ncol=6,byrow=TRUE)
print(m1)

m2<-matrix(21:29,nrow=3)
print(m2)

m3<-matrix(20:29,nrow=3,ncol=2)
print(m3)


m4<-matrix(20:24,nrow=3,ncol=2)
print(m4)


marks<-c(45,34,67,89,92,56,78,49,92,85,76,61)

marks<-c(45,34,67,89,92,56,78)

marks<-c(45,34,67,NA,92,56,78,49,NA,85,76,61)

marks<-c(45,34,67,89,92,56,78,49,92,85,76,61)
subNames<-c("Maths","Physics","Chemistry")
studNames<-c("Ram","Shyam","Sita","Nita")
studMarks<-matrix(marks,nrow=4,ncol=3,byrow=TRUE,dimnames=list(studNames,subNames))
print(studMarks)

studMarks[3,]
studMarks[,2]

studMarks[c("Ram","Nita"),]

studMarks[c(1,2,4),]
studMarks[c(2,4),c(1,3)]
dim(studMarks)

#Row Bind
matrix1<-matrix(1:8,nrow=2,byrow=TRUE)
matrix2<-matrix(c(10,20,30,40,50,60,70,80,100,110,120,130),nrow=3,byrow=TRUE)
print(matrix1)
print(matrix2)

res<-rbind(matrix1,matrix2)
print(res)

# For rbind No.of.Cols should be equal
matrix3<-matrix(c(10,20,30,40,50,60,70,80,100,110,120,130),nrow=4,byrow=TRUE)
print(matrix3)
res1<-rbind(matrix1,matrix3)
print(res1)


#Column Bind
matrix1<-matrix(1:8,nrow=4,byrow=TRUE)
matrix2<-matrix(c(10,20,30,40,50,60,70,80,100,110,120,130),nrow=4,byrow=TRUE)
print(matrix1)
print(matrix2)

# For cbind No.of.Rows should be equal
res<-cbind(matrix1,matrix2)
print(res)










