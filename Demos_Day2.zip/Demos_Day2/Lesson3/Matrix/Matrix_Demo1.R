# Create a matrix.
m1=matrix(c(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16),nrow=4,ncol=4)
print(m1)

#Access [1,4]  1st row 4th column
print(m1[1,4])

m1[2,]

print(m1[,3])

print(m1[c(2,4),])

print(m1[,c(1,3)])

print(m1[c(2,4),c(1,3)])


m2=matrix(c(1,2,3,4,5,6,7,8,9),nrow=3,ncol=3,byrow=FALSE)
print(m2)

M = matrix( c('a','a','b','c','b','a'), nrow = 2, ncol = 3, byrow = TRUE)
print(M)

M = matrix( c('a','a','b','c','b','a'), nrow = 2, ncol = 3, byrow = FALSE)
print(M)

M = matrix( c('a','a','b','c','b','a'), nrow = 3, ncol = 2, byrow = TRUE)
print(M)

# Elements are arranged sequentially by row.
M <- matrix(c(3:15), nrow = 4, byrow = TRUE)
print(M)


rownames<-c("Student1","Student2","Student3","Student4")
colnames<-c("Maths","Physics","Chemistry")



StudentMarks<-matrix(c(90,89,78,45,56,67,34,23,12,78,89,67),
                     nrow=4,ncol = 3,byrow=TRUE,dimnames = list(rownames,colnames))

print(StudentMarks)

dim(StudentMarks)

a <- matrix(1:8, nrow=4, ncol=4)
print(a)


m5=matrix(c(1,NA,3,4,5,NA,7,8,9),nrow=3,ncol=3,byrow=TRUE)
print(m5)


M6 = matrix( c('a',' ','b','c',' ','a'), nrow = 2, ncol = 3, byrow = TRUE)
print(M6)







