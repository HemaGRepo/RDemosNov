data<-c(2,5,3,7,8,10,9,12,8,6,1,11)
m1<-matrix(
             data,
             nrow=4,
             ncol=3
          )
print(m1)

rnames<-c("Q1","Q2","Q3","Q4")
cnames<-c("2016","2017","2018")

dimnames(m1)<-list(rnames,cnames)
print(m1)
t(m1)

m1["Q3","2017"]
m1[3,2]
m1[c("Q3","Q4"),]
m1[c("Q3","Q4"),c("2017","2018")]


stuMarks<-matrix(
          c(34,56,78,23,78,90),
          nrow=3,
          ncol=2,
          dimnames=list(
            c("Ram","Shyam","Kumar"),
            c("Maths","Science")
          ),
          byrow = TRUE
)
print(stuMarks)

m2<-matrix(1:15,nrow=5,ncol=3,
           dimnames=list(
             1:5,letters[1:3]
           ),byrow=TRUE)

m2[3,2]
m2[4,1]
m2[1,]
m2[3,]
m2[c(1,3),]
m2[,3]
m2[,c(2,3)]
m2[c(1,4),c(2,3)]
m2["3",]
m2[,"b"]

mat1<-matrix(1:9,nrow=3)
mat2<-matrix(21:29,nrow=3)
mat1+mat2
mat2-mat1
mat1*mat2
mat1/mat2
t()

#rbind and cbind
print(m1)
m1<-rbind(m1,c(10,20,30))

temp<-matrix(1:6,ncol=3,
             dimnames=list(c("A","B"),c("1","2","3")))
print(temp)

m1<-rbind(m1,temp)



futureMatrix<-matrix(51:62,nrow=6,dimnames=
                       list(1:6,c("2019","2020")))
print(futureMatrix)

m1<-cbind(m1,futureMatrix)
print(m1)














