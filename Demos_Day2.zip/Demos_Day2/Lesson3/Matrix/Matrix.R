#MATRIX FUNCTIONS

# Elements are arranged sequentially by row.
M <- matrix(c(3:14), nrow = 4, byrow = TRUE)
print(M)

# Elements are arranged sequentially by column.
N <- matrix(c(3:14), nrow = 4, byrow = FALSE)
print(N)

# Define the column and row names.
rownames = c("row1", "row2", "row3", "row4")
colnames = c("col1", "col2", "col3")

P <- matrix(c(3:14), nrow = 4, byrow = TRUE, dimnames = list(rownames, colnames))
print(P)

# Define the column and row names.
rownames = c("row1", "row2", "row3", "row4")
colnames = c("col1", "col2", "col3")

# Create the matrix.
P <- matrix(c(3:14), nrow = 4, byrow = TRUE, dimnames = list(rownames, colnames))

# Access the element at 3rd column and 1st row.
print(P[1,3])

# Access the element at 2nd column and 4th row.
print(P[4,2])

# Access only the  2nd row.
print(P[2,])

# Access only the 3rd column.
print(P[,3])

# Create two 2x3 matrices.
matrix1 <- matrix(c(3, 9, -1, 4, 2, 6), nrow = 2)
print(matrix1)

matrix2 <- matrix(c(5, 2, 0, 9, 3, 4), nrow = 2)
print(matrix2)

# Add the matrices.
result <- matrix1 + matrix2
cat("Result of addition","\n")
print(result)

# Subtract the matrices
result <- matrix1 - matrix2
cat("Result of subtraction","\n")
print(result)

# Create two 2x3 matrices.
matrix1 <- matrix(c(3, 9, -1, 4, 2, 6), nrow = 2)
print(matrix1)

tmat<-t(matrix1)
print(tmat)
dim(tmat)

matrix2 <- matrix(c(5, 2, 0, 9, 3, 4), nrow = 2)
print(matrix2)

# Multiply the matrices.
result <- matrix1 * matrix2
cat("Result of multiplication","\n")
print(result)

# Divide the matrices
result <- matrix1 / matrix2
cat("Result of division","\n")
print(result)

B = matrix( 
  c(12, 14, 13, 11, 15, 17), 
  nrow=3, 
 ncol=2) 

C = matrix( 
  c(17, 14, 12),  
  nrow=3, 
  ncol=1)
print(B)
print(C)

B+C

newMat2<-cbind(B, C) 
print(newMat2)


D = matrix( 
 c(6, 2), 
 nrow=1, 
 ncol=2) 

print(D)
rbind(B,D)


# Elements are arranged sequentially by row.
M1 <- matrix(c(3:14), nrow = 4, byrow = TRUE)
print(M1)

# Elements are arranged sequentially by column.
N1 <- matrix(c(3:14), nrow = 4, byrow = FALSE)
print(N1)

result<-M1[,1]*N1[,2]
print(result)





