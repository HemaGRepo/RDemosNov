#Logical Operators

v<-c(1,2,3,4,5)
t<-c(0,9,0,1,3)

print(v&t)
print(v|t)
print(v&&t)
v<-c("A")
v<-c("B")
print(v&&t)

u<-c(1,0)
print(v&u)


v <- c(3,1,TRUE,2+3i)
t <- c(4,0,FALSE,5)
print(v&t)


v1<-c(90,45,30,50,60,89,78)
v2<-c(1,0)
print(v1&v2)

v <- c(3,0,TRUE,2+2i)
t <- c(4,0,FALSE,2+3i)
print(v|t)


v <- c(3,0,TRUE,2+2i)
print(!v)

v <- c(3,0,TRUE,2+2i)
t <- c(1,3,TRUE,2+3i)
print(v&&t)

v <- c(0,0,TRUE,2+2i)
t <- c(0,3,TRUE,2+3i)
print(v||t)