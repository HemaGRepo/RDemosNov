x<-c(13,67,90,25,100,4,39)

x
# [ is called as the selection operator
x[3]

ind<-c(3,5)
x[ind]

x[2:6]

x[c(1.8,3.2,4.9)]

x[-2]

x[c(-2,-5,-7,-1)]

x[c(-2,3)]

x<-c(13,67,90,25,100,4,39)

x[c(TRUE,TRUE,FALSE,FALSE,FALSE,TRUE,FALSE)]

# 7 elements in the vector, so repeat (TRUE,FALSE) to make length=7
# c(TRUE,FALSE)=> (TRUE,FALSE,TRUE,FALSE,TRUE,FALSE,TRUE)
x[c(TRUE,FALSE)]

x[FALSE]

temp<-x[as.logical(c(0,0,0,1,0,0,1))]

print(temp)

t1<-c("Smith","Adam","Australia","CSK")

names(t1)<-c("LastName","FirstName","Country","Team")

print(t1)

t1["Country"]

t2<-c("LastName"="Smith","FirstName"="Adam","Country"="Australia","Team"="CSK")

print(t2)

t2["Team"]

t2["Team"]<-"RCB"

print(t2)

t2[2]<-"Aaron"


print(names(t2))

marks<-c(87,90,91,75,67)
names(marks)<-c("Maths","Robotics","AI","Java","Data Science")
marks[c("Maths","AI","Java")]

x1<-c(13,67,90,25,100,4,39)
names(x1)<-c("Col1","Col2")

print(x1)

x1[x1<20]<-30
print(x1)

x1<-x1[2:5]
print(x1)













