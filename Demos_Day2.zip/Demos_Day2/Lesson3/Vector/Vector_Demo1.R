#Vector
# Create a vector.
apple <- c('red','green',"yellow")
print(apple)

# Get the class of the vector.
print(class(apple))

marks<-c(89,78,65,43,23,10,89)
print(marks)