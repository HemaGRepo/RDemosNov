# R has no scalars
age<-22 
#age is a vector of length = 1
#Vector - One dimensional data structure
marks<-c(56,34,12,90,87)
# Marks is a vector containing numeric values
typeof(marks)

names<-c("Sam","Ram","Rohan","Tarun")
length(names)

# Create a vector - c()
products<-c("TV","Mobile","Pen","Garments","Books")
print(products)
availability<-c(T,F,T,T,F)

# Ways to create a vector
ids<-10:18
print(ids)

empid<-seq(100,120,by=2)
print(empid)

draw<-rep(5,10)
print(draw)

v1<-c(1:5,rep(9,3),seq(1,10,by=3),c(8,12,15,20))
print(v1)

# Access the elements of a vector
print(v1)
v1[1]
v1[10]
v1[3:8]
#Access the 2,5,9,12
v1[c(2,5,9,12)]

seq(1:20)[5:15]

# Get me all the elements except the 4th element
v1[-4]
# Get me all the elements except the 2,4,6,9th element
v1[-c(2,4,6,9)]
v1[c(-2,-3)]

v1[c(2,-5)]#Incorrect

marks<-c(56,34,12,90,87,10,66,91,40)
print(marks)

marks[c(T,F,T,F,F,F,T,T,F)]
marks[c(T,F)]# No of elements=9, repeat T,F => 5 times 
marks[c(F,F,T)]

names(marks)<-c("Ram","Sita","Lakshman","Krish",
                "Allen","Jack","Syed","Tarun","Isha")
print(marks)

price<-c("Pen"=10,"TV"=34562,"Mobile"=25656,"Garment"=987)
print(price)

price["Pen"]
marks[c("Sita","Isha","Tarun")]
marks[c(1:4)]
marks[-c("Jack")]

#Add elements
print(marks)
marks<-c(marks,c("Tom"=40,"Vishnu"=98))
print(marks)

# Delete the mark of Syed
marks<-marks[-7]
print(marks)

#Update the marks - if marks<30 change it to 50
marks[marks<30]<-50
print(marks)
names(marks)<-NULL
print(marks)
names(marks)<-c("Ram","Sita","Lakshman","Krish",
                "Allen","Jack","Syed","Tarun","Isha")
print(marks)
#Delete Tarun
marks<-marks[names(marks)!="Tarun"]
print(marks)






