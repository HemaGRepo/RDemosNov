#Arithmetic Operators
v <- c( 2,5.5,6)
t <- c(8, 3, 4)
print(v+t)

v <- c( 2,5.5,6)
t <- c(8, 3, 4)
print(v-t)

v <- c( 2,5.5,6)
t <- c(8, 3, 4)
print(v*t)

v <- c( 2,5.5,6)
t <- c(8, 3, 4)
print(v/t)

v <- c( 2,5.5,6)
t <- c(8, 3, 4)
print(v%%t)

v <- c( 2,5.5,6)
t <- c(8, 3, 4)
print(v%/%t)

v <- c( 2,5.5,6)
t <- c(8, 3, 4)
print(v^t)


v<-3:10
v
t<-11:13
t
print(v+t)


v1<-c(10,20)
v2<-c(9,8,7,6,5,4,3)
print(v1+v2)



