salary<-c(45456,34545,90998,23567,10000)
incentive<-c(120,457,783,924,290)

totalSal<-salary+incentive
print(totalSal)

incentive<-c(5000)
totalSal<-salary+incentive
print(totalSal)

incentive<-c(1000,2000) # Recycle rule 
# salary has 5 elements
#incentive has only 2 elements -> recylce the elements of incentive
#1000,2000,1000,2000,1000,2000
totalSal<-salary+incentive
print(totalSal)


print(salary)
tax<-c(700,300)
monthlySal<-salary-tax
print(monthlySal)

bonus<-c(2,3,1,2,3)
totalSal<-salary*bonus
print(totalSal)

v2<-c(12,6,4,3,6)
monthly<-salary/v2
print(monthly)

#Character takes precedence
v1<-c(1,2,3,"A","B")
print(v1)

v1<-c(1,2,3,TRUE,FALSE,"A","B")
print(v1)


v1<-c(31,82,54,TRUE,FALSE)
print(v1)

orderPrice<-c(100,250,320,80,60,400)
min(orderPrice)
max(orderPrice)
range(orderPrice)
sum(orderPrice)

which.min(orderPrice)
orderPrice[which.max(orderPrice)]

sort(orderPrice)
sort(orderPrice,decreasing = TRUE)


discount<-c(30,40,20,100,NA,NA,50,NA,20,NA)

print(discount)
length(discount)
min(discount,na.rm = TRUE)
max(discount,na.rm = TRUE)

sum(discount,na.rm = TRUE)
mean(discount,na.rm = TRUE)
sd(discount,na.rm = TRUE)

library(psych)
describe(discount)

length(discount)



