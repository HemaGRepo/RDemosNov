#Vector

x1<-c(2, 3, 5) 

y1<-c(TRUE, FALSE, TRUE, FALSE, FALSE) 

z1<-c("aa", "bb", "cc", "dd", "ee") 

length(c("aa", "bb", "cc", "dd", "ee")) 

class(x1)
n = c(2, 3, 5) 
s = c("aa", "bb", "cc", "dd", "ee") 
c(n, s) 

a = c(1, 3, 5, 7) 
b = c(1, 2,4,8)

print(a+b)
print(a-b)
print(a*b)
print(a/b)

s = c("aa", "bb", "cc", "dd", "ee") 
print(s[3])
print(s[-3])
print(s[c(2,3)])
print(s[c(2,3,3)])
print(s[c(2,1)])
print(s[c(1:3)])
L = c(FALSE, TRUE, FALSE, TRUE, FALSE) 
print( s[L])

v = c("Mary", "Sue") 
names(v) = c("First", "Last") 
print(v[c("Last", "First")] )
