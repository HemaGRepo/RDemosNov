#Data frame - represents real world data

empNames<-c("Ram","Sita","Lakshman","Bharath","Ravan")
desig<-c("Mgr","TL","SSE","SE","Mgr")
salary<-c(89898,67676,34544,66677,56534)
locs<-c("Pune","Mumbai","Pune","Chennai","Mumbai")

employeeDB<-data.frame(
              enames=empNames,
              desigs=desig,
              sal=salary,
              location=locs
)

employeeDB

shoppingData<-data.frame(
  product=c("Lamp","Detergent","Paste","Cutlery","Wipes","Milk"),
  price=c(67.89,45.34,89.78,120,56,123.34),
  inStock=c(TRUE,FALSE,TRUE,TRUE,TRUE,TRUE),
  qty=c(45,67,12,67,89,90),
  stringsAsFactors = FALSE
)
shoppingData

shoppingData[2,4]

shoppingData[1,]

shoppingData[,1]

shoppingData[2,2]

shoppingData$product

shoppingData$price

shoppingData[,c("product","price")]

shoppingData[shoppingData$price>60,]

shoppingData[shoppingData$price>60,c(1,2)]

shoppingData[shoppingData$inStock==FALSE,]


