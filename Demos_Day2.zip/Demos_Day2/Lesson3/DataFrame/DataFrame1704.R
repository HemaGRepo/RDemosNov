ids<-1:5
names<-c("Ram","Sita","Arun","Tarun","Yuva")
salary<-c(23454,12344,89898,45667,40000)
desig<-c("SE","SE","SSE","TL","Mgr")

employeeDB<-data.frame(
     "Empid"=ids,
     "EmpNames"=names,
     "Salary"=salary,
     "Designation"=desig,
     stringsAsFactors = FALSE
)
str(employeeDB)
nrow(employeeDB)
ncol(employeeDB)

employeeDB[1,3]
employeeDB[,2]
employeeDB[3,1]

employeeDB$EmpNames
employeeDB$EmpNames[3]
employeeDB[employeeDB$Salary<50000,]

#Change Ram salary to 26000
employeeDB[employeeDB$EmpNames=="Ram",3]<-26000

head(employeeDB,3)

tail(employeeDB,3)

employeeDB[3:5,c(1,3)]

employeeDB[2,"Salary"]<-90000

library(dplyr)
select(employeeDB,EmpNames,Salary)




