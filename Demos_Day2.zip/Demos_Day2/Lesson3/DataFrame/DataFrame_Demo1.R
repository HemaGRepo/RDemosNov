emp.data <- data.frame(
  emp_id = c (1:5), 
  emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),
  salary = c(623.3,515.2,611.0,729.0,843.25), 
  start_date = as.Date(c("2012-01-01", "2013-09-23", "2014-11-15", "2014-05-11",
                         "2015-03-27")),
  stringsAsFactors = FALSE
)


print(emp.data)
names(emp.data)

head(emp.data,2)
tail(emp.data,3)

emp.data[1,4]
emp.data[c(4,5),]

emp.data[c(4,5),c(1,2)]

#Get me the salary of 1st and 3rd employee
emp.data[c(1,3),"salary"]

#Get me the name and salary of 1st and 3rd employee
emp.data[c(1,3),c("salary","emp_name")]

# Get me all the employee names

emp.data$emp_name

sum(emp.data$salary)
mean(emp.data$salary)


employee<-data.frame(
  eid=c(101,127,145,765,390,200),
  names=c("Ram","Shyam","Suraj","Krish","Vani","Laya"),
  desig=c("TL","SSE","Mgr","Mgr","SE","TL"),
  salary=c(12000,23456,67843,89234,20865,78787),
  stringsAsFactors = FALSE
)
print(employee)



employee[3:5,2]#Get a single column - u get a list
employee[3:5,2:3]

employee[employee$salary<25000,]

employee[employee$salary<25000,c("names","salary")]

employee[employee$salary<=25000,]

employee[employee$salary<=25000,c(2,4)]

#Modify salary of Row #1
employee[1,"salary"]<-34000

# Add rows to data frame
print(employee)
newEmp<-list(433,"Tina","TL",34876)
employee<-rbind(employee,newEmp)
print(employee)

#Add columns to data frame
employee<-cbind(employee,"location"=c("MUM","CH","PU","BLR","HYD","MUM","CH"))
print(employee)
#Delete a column
employee$location=NULL

print(employee)
newEmp<-list(566,"Ram","TL",64344)
employee<-rbind(employee,newEmp)
print(employee)

employee[(employee$names=="Ram")&(employee$salary==64344),]
employee[(employee$names=="Ram"),]

# Delete the 4th Row
employee<-employee[-4,]
print(employee)
newEmp<-list("Renu",435,566,"TL")
employee<-rbind(employee,newEmp)
print(employee)
str(employee)
employee<-employee[c("1",  "2" , "3"  ,"5" , "6" , "7"),]
print(employee)
rownames(employee)

rownames(employee)<-letters[1:7]
print(employee)

print(max(employee$salary))


# Find the row which has maximum salary
employee[employee$salary==max(employee$salary),]

sort(employee$salary)

# Print the employee details sorted by salary
employee[order(employee[,"salary"],decreasing = TRUE),]

employee[order(employee[,"names"]),]

# Print the count of employees based on Desig
table(employee$desig)

print(employee[3,])

# Create the data frame.
BMI <- 	data.frame(
  gender = c("Male", "Male","Female"), 
  height = c(152, 171.5, 165), 
  weight = c(81,93, 78),
  Age = c(42,38,26)
)
print(BMI)

BMI[BMI$Age>40,]

# The department of police wants to store the number of accidents in a year
# Values are captured for Two Wheeler, Four Wheeler and Heavy Vehicles

accident<-data.frame(
  vehicle=c("Two Wheeler", "Four Wheeler", "Heavy Vehicles"),
  Accident_Count=c(56,45,83),
  Drunken_Driving=c(3,30,42)
)

print(accident)

employee<-data.frame(
  eid=c(101,127,145,765,390,200),
  names=c("Ram","Shyam","Suraj","Krish","Vani","Laya"),
  desig=c("TL","SSE","Mgr","Mgr","SE","TL"),
  salary=c(12000,23456,67843,89234,20865,78787),
  stringsAsFactors = FALSE
)

head(employee,3)
employee[1:3,]
print(employee)

str(employee)



BMI2 <- 	data.frame(
  c("Male", "Male","Female"), 
  height = c(152, 171.5, 165), 
  weight = c(81,93, 78),
  Age = c(42,38,26)
)
print(BMI2)