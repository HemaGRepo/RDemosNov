employee<-data.frame(
  eid=c(101,127,145,765,390,200),
  names=c("Ram","Shyam","Suraj","Krish","Vani","Laya"),
  desig=c("TL","SSE","Mgr","Mgr","SE","TL"),
  salary=c(12000,23456,67843,89234,20865,78787),
  deptid=c(10,20,30,10,20,20),
  stringsAsFactors = FALSE
)
print(employee)


department<-data.frame(
  deptid=c(10,20,30),
  dname=c("LnD","Sogeti","Infra"),
  loc=c("Chennai","Pune","Mumbai")
)

print(department)

#package called as sqldf -> execute sql queries on Dataframes
#install.packages("sqldf")
library(sqldf)


# Select all the employees
sqldf("Select * from employee")

sqldf("Select names,salary from employee")

# Select employes whose salary is <35000
sqldf("Select names,salary from employee where salary<35000")

sqldf("Select * from employee where names='Ram'")

sqldf("Select eid,names,desig from employee where names in ('Ram','Krish','Vani')")

sqldf("select 
      *
      from employee
      where
      salary>30000
      and deptid!=10")

sqldf("Select * from employee where salary<35000")

sqldf("Select * from employee order by salary desc")

sqldf("Select eid,names,salary from employee order by salary")

# Display departmentwise sum(salary)

sqldf("Select deptid,sum(salary) as SALARY
      from 
      employee
      group by deptid")


sqldf("Select sum(salary),desig from employee Group by desig")

sqldf("Select avg(salary),desig from employee Group by desig")

salaryData<-sqldf("Select count(Salary),desig 
                  from employee Group by desig")

salaryDF<- sqldf("Select sum(Salary),Desig 
                 from employee where 
                 desig!='TL' Group by desig ")

# Find the employees who earn more than Vani

sqldf("Select * from employee
      where 
      salary>
      (Select salary from employee where names='Vani')
      ")

# Find the location of Suraj

sqldf("Select names,employee.deptid,loc
      from employee,department
      where employee.deptid=department.deptid
      and names='Suraj'")

sqldf("Select names,loc from employee,department
 where employee.deptid=department.deptid
  and employee.names='Suraj'")

sqldf("Select names,loc from employee,department
 where employee.deptid=department.deptid
     ")

examples(data.frame)

# Count the number of employees in each designation

print(Orange)

str(Orange)

sqldf("select avg(circumference),tree
      from Orange group by tree")

print(warpbreaks)

d1<-sqldf("select avg(breaks),wool,tension
      from warpbreaks
      group By wool,tension")











