pid<-101:105
pnames<-c("TV","Oven","Book","Toys","Furniture")
price<-c(34526,12000,450,1000,8000)
isAvailable<-c(T,F,T,T,F)

productDetails<-data.frame(
  productId=pid,
  prodNames=pnames,
  prodPrice=price,
  inStock=isAvailable,
  stringsAsFactors = FALSE
)

print(productDetails)


#Delete the product 103
productDetails<-productDetails[-3,]
#Automatically on Character columns factor is created
productDetails$prodNames[2]<-"Microwave Oven"

str(productDetails)
colnames(productDetails)
rownames(productDetails)
rownames(productDetails)<-c("A","B","C","D","E")
rownames(productDetails)

#Access the df

productDetails[1,]
productDetails[,2]

# Get the product name and price
productDetails[,c(2,3)]
productDetails[,c("prodNames","prodPrice")]

# What is the price of Furniture
productDetails["E","prodPrice"]

# What is the price of Furniture and its availability
productDetails["E",c("prodPrice","inStock")]

# Get me all details of Book and Toys
productDetails[c("C","D"),]

# Get me pid and price details of Book and Toys
productDetails[c("C","D"),c("productId","prodPrice")]

# With Df $ can be used to access colums
productDetails$productId
productDetails$prodNames
productDetails$prodPrice

# Name of the 3rd product
productDetails$prodNames[3]


