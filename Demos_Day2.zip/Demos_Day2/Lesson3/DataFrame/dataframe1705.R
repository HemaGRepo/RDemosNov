empData<-data.frame(
   empid=101:105,
   name=c("Ram","Sita","Lakshman","Ravan","Krish"),
   salary=c(45468,2445,90900,26767,56478),
   isContract=c(T,F,F,F,T),
   stringsAsFactors = FALSE
)
str(empData)
empData[2,"name"]<-"Arun"
