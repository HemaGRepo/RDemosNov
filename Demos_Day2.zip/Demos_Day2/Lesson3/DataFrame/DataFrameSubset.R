df <- data.frame(x = 1:3, y = 3:1, z = letters[1:3])

df[df$x == 2, ]
##   x y z
## 2 2 2 b
df[c(1, 3), ]
##   x y z
## 1 1 3 a
## 3 3 1 c
# There are two ways to select columns from a data frame
# Like a list:
df[c("x", "z")]
##   x z
## 1 1 a
## 2 2 b
## 3 3 c
# Like a matrix
df[, c("x", "z")]
##   x z
## 1 1 a
## 2 2 b
## 3 3 c
# There's an important difference if you select a single 
# column: matrix subsetting simplifies by default, list 
# subsetting does not.
str(df["x"])
## 'data.frame':    3 obs. of  1 variable:
##  $ x: int  1 2 3
str(df[, "x"])
##  int [1:3] 1 2 3