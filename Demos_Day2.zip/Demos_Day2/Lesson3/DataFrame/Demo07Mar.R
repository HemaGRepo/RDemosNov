product<-data.frame(
          pid=c(1,2,3,4,5),
          productName=c("TV","Pen","Book","Tab","Pencil"),
          price=c(34454.3,23.50,345,9898,10),
          stringsAsFactors = FALSE
)
print(product)
typeof(product)
class(product)
product$productName[2]<-"Jeans"

account<-data.frame()
account<-edit(account)
print(account)