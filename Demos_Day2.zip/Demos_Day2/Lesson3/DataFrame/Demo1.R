accId<-c(4565,3456,8998,2345,3610,3676)
custName<-c("Ram","Lakshman","Sita","Sam","Suhail","Alfred")
balance<-c(89765.45,34239.34,218984.22,46738.50,20909.70,98654.54)
accType<-c("SA","CA","CA","SA","CA","SA")

AccountDF<-data.frame(
   accountNumber=accId,customers=custName,accBalance=balance,type=accType,
   stringsAsFactors = FALSE
)

print(AccountDF)


AccountDF$customers

AccountDF["customers"]
AccountDF[c(2,3),]

# Create the data frame.- print function
emp.data <- data.frame(
  emp_id = c (1:5), 
  emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),
  salary = c(623.3,515.2,611.0,729.0,843.25), 
  
  start_date = as.Date(c("2012-01-01", "2013-09-23", "2014-11-15", "2014-05-11",
                         "2015-03-27")),
  stringsAsFactors = FALSE
)
# Print the data frame.			
print(emp.data) 


products<-data.frame(
  prodId=201:205,
  pnames=c("TV","Pen","Mobile","Book","Denim"),
  price=c(32456,5,10000,650,3000),
  qty=c(80,120,456,300,45),
  stringsAsFactors = FALSE
)

print(products)



























