# Employee data

emp<-data.frame(
      empid=c(101,102,103),
      name=c("Ram","Lakshman","Sita"),
      salary=c(76767.45,23234.33,56565.34)
)

products<-data.frame()
products<-edit(products)

accounts<-data.frame(
  accId=c(103,107,108),
  custName=c("Ram","Lakshman","Sita"),
  balance=c(3434,2323,23232)
)

accounts$custName

accounts$custName[1]<-"Ram Kumar"

accounts<-data.frame(
  accId=c(103,107,108),
  custName=c("Ram","Lakshman","Sita"),
  balance=c(3434,2323,23232),
  stringsAsFactors = FALSE
)

accounts$custName

accounts$custName[1]<-"Ram Kumar"


ids<-101:106
names<-c("Ram","Sita","Krish","Yuva","Ravan","Lakshman")
salary<-c(78745,2322,78788,12345,90967,58378)
desig<-c("SE","SSE","TL","SE","SE","SSE")

employee<-data.frame(
  empId=ids,
  empNames=names,
  empSal=salary,
  empDesig=desig,
  stringsAsFactors = FALSE
)

employee[1]
employee$empId

employee[c(1,3)]
employee[c("empId","empNames")]

print(employee)
View(employee)

employee[2,3]<-40000

employee[c(2,4),]

employee<-data.frame(
  eid=c(101,127,145,765,390,200),
  names=c("Ram","Shyam","Suraj","Krish","Vani","Laya"),
  desig=c("TL","SSE","Mgr","Mgr","SE","TL"),
  salary=c(12000,23456,67843,89234,20865,78787),
  stringsAsFactors = FALSE
)


# Install the package:
install.packages("dplyr")

library(dplyr)


select(employee,names,salary)

filter(employee,grepl("m",names))

# Find the names and salary of employees whose name contain "m" 
op<-filter(employee,grepl("m",names))
select(op,names,salary)
select(filter(employee,grepl("m",names)),names,salary)


# Sort the elements in a data frame
arrange(employee,salary)
arrange(employee,-salary)

group_by(employee,desig)

summarise(group_by(employee,desig),sum(salary))

install.packages("sqldf")
library(sqldf)

sqldf("Select * from CO2 where plant='Qn1'")

sqldf("Select * from CO2 where plant='Qn1' and conc>400")

#Find the sum of conc for each Plant
sqldf("Select Plant,sum(uptake)
       from CO2
       group by Plant
      ")

#Find the count of plantwise type
sqldf("Select Plant,Type,count(conc)
       from CO2
       group by Plant,Type
      ")
subset(employee,salary>60000,select=c(names,salary))

v1<-1:5
v2<-6:10
res<-outer(v1,v2,paste,sep=",")
print(res)









