desig<-c("SE","TL","Mgr","SSE","SSE","SE",
         "TL","Mgr","Mgr","SE","SSE","TL","TL")
is.factor(desig)

#Factor - stores categorical data
# Factor is created on Vectors which have repeated set of values

#Steps
# Find the unique values - SE,TL,Mgr,SSE
# Sort the values - Mgr,SE,SSE,TL
# The srted unique values becomes levels 
# Levels - Mgr,SE,SSE,TL
# For each level give level number - 1-Mgr,2-SE,3-SSE,4-TL
# The vector is ("SE","TL","Mgr","SSE","SSE","SE","TL","Mgr","Mgr","SE","SSE","TL","TL")
# Instead od SE, it will store the level number 2 and so on
# (2,4,1,3,3,2,4,1,1,2,3,4,4)
#Internally the vector is stored as (2,4,1,3,3,2,4,1,1,2,3,4,4)

f1<-factor(desig)
print(f1)
str(f1)

f1[1]<-"SSE"
print(f1)
f1[3]<-"Sr.Mgr"
print(f1)


f2<-factor(desig,levels = c("SE","SSE","TL","Mgr","Sr.Mgr","VP"))
print(f2)
f2[3]<-"Sr.Mgr"
print(f2)

#New desig introducted, "ASE"
levels(f2)<-c(levels(f2),"ASE")
print(f2)


desig<-c("SE","TL","Mgr","SSE","SSE","SE",
         "TL","Mgr","Mgr","SE","SSE","TL","TL")
table(desig)

gender<-c("M","F","M","F","M","F","M","M",
          "M","F","M","F","M","F","M","M","M","F","M","F","M","F","M","M",
          "M","F","M","F","M","F","M","M")
table(gender)








