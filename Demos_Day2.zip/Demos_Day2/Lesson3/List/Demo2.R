l1<-list(name="Shiva",design="Sr.BA",company="Capgemini",salary=67676)
print(l1)

#Vector
skills<-c("Data Science","UX","SAP","BI")
print(skills)

#Matrix
data<-c(4,1,2,3,4,2,3,1,4,3,3,2)
rownames<-c(2015,2016,2017)
colnames<-c("Q1","Q2","Q3","Q4")
appraisalData<-matrix(data,nrow=3,dimnames=list(rownames,colnames))
print(appraisalData)

empList<-list(ename="Ram",desig="SSE",salary=56432,empSkills=skills,ratings=appraisalData)
print(empList)

# 3 types of access
#[]
#[[]]
#$

length(empList)