#Vector
v1<-1:8

#Matrix
m1<-matrix(10:15,nrow=2,ncol=3,byrow=TRUE)

# Create a list.
list1 <- list(v1,m1,23:27,TRUE,"Capgemini India L&D")

# Print the list.
print(list1)

list2<-c("Name"="Capgemini","years"=50,"headOff"="France","turnover"=150000000)
print(list2)

str(list2)

list1[1]

list1[[1]]

list1[1][c(1,3,5)]
class(list1[1])

list1[[1]][c(1,3,5)]


rating<-c(2,3,3,3,1,2,1,3,3,3,4,4)
p2015<-c("P1","P3")
 p2016<-c("LnD","HR")
 p2017<-c("XYZ","ABC","MNO")
empData<-list("p15"=p2015,"p16"=p2016,"p17"=p2017,"rating"=ratingMatrix)
 rNames<-c("2015","2016","2017")
 cNames<-c("Q1","Q2","Q3","Q4")
 ratingMatrix<-matrix(rating,nrow=3,dimnames=list(rNames,cNames))
 empData<-list("p15"=p2015,"p16"=p2016,"p17"=p2017,"rating"=ratingMatrix)

 # Find the H1 rating of the employee in 2016
  empData[[4]][2,c(1,2)]
 # Create a list to hold the employee project details year wise
 pList<-empData[c(1,2,3)]
 
 
 # Add 2018 Project details to the list
 
 p2018<-c("InD","FS","Apps1")
 empData[["p18"]]<-p2018
 
 
 
 
 
 


