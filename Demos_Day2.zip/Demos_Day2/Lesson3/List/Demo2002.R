empDetails<-list(empid=90L,name="Hema",isPermanent=TRUE,salary=34543.23)
print(empDetails)
str(empDetails)

appraisalData<-c(2,3,2,3,1,2,3,2,2,1,2,1)
rn<-c("2016","2017","2018")
cn<-c("Q1","Q2","Q3","Q4")

appData<-matrix(appraisalData,nrow=3,dimnames=list(rn,cn))
print(appData)

#Store all details of an employee

empDetails<-list(
                  empid=90L,
                  name="Sam",
                  isPermanent=TRUE,
                  salary=34543.23,
                  skills=c("Java","DevOps","R","Python"),
                  projectIds=c("P7867","123454","LnDCG1"),
                  appraisal=appData
                 )
print(empDetails)
str(empDetails)

#Add additional elements to a list - Add location to empDetails
empDetails[["location"]]<-"Chennai"
print(empDetails)
str(empDetails)

# Accessing the elements of a list - [] or [[]] or $

#[] - Get me Box #3
#[[]] and $ - Get me the content in Box #3

# [] and [[]] both index and name can be used
# $ - only name can be used

empDetails[6] #[] - Get me Box #6
empDetails[[6]] #[] - Get me the contents in Box #6
#empDetails$6

empDetails["projectIds"]
empDetails[["projectIds"]]
empDetails$projectIds

print(empDetails)

empDetails["appraisal"]

#Change the rating for 2018 Q4 to "2"
empDetails["appraisal"]["2018","Q4"]<-2

#Change the rating for 2018 Q4 to "2"
empDetails[["appraisal"]]["2018","Q4"]<-3

# [] is used to get a sublist from an existing list

eDetails<-empDetails[1:4]

print(eDetails)

#[] - Take few boxes and store it in another room
e1<-empDetails[c(1,4,6)]
print(e1)

#[[]] or $ is used to access the data in 1 box
empDetails[[6]]

#Change the rating for 2016 Q2 to "1"
empDetails$appraisal["2016","Q2"]<-1






