productDetail<-list(
        pid=90L,pname="Book",price=354.23,isAvailable=TRUE
)
print(productDetail)

appraisal<-matrix(
  c(3,2,1,3,2,2,2,3,2,1,1,3),
  nrow=3,
  byrow=TRUE,
  dimnames = list(
    c("2016","2017","2018"),
    c("Q1","Q2","Q3","Q4")
  ))

EmpDetail<-list(
          empid=34233L,name="Ram",age=27,salary=45321.90,
          skills=c("DevOps","UX","DataScience","Hadoop"),
          ratings=appraisal)

print(EmpDetail)

# Access the elements of the list [],[[]],$
EmpDetail[1]
EmpDetail[c(2,4,5)] # Get me the boxes 2,4,5 -> Do not open 

EmpDetail[[3]]
EmpDetail[[c(2,3)]]#Invalid
EmpDetail[[1]]

#$ and [[]] are the same, but $ can be used only with name
EmpDetail$age
# EmpDetail$3 #invalid
EmpDetail[[3]]
EmpDetail[["age"]]

# Get me the rating of the employee in Q3 2017
EmpDetail$ratings

EmpDetail$ratings["2017","Q3"]

# Change the rating of the employee in Q3 2017 to 1
EmpDetail$ratings["2017","Q3"]<-1


# Get me the rating of the employee in Q1 2016
EmpDetail[[6]][1,1]

EmpDetail[6][1,1]


print(productDetail)
productDetail[c(T,F,T,T)]
#add element
productDetail["description"]<-"Published in 2016"
print(productDetail)
#Delete a element
productDetail["isAvailable"]<-NULL
print(productDetail)

#[] - get me the box- if a list has 6 elements [] will get few elements
#[c(2,3)] - get me the box 2 and 3 - Do not Open the box


#[[]] or $ - open one of the boxes and give me the content
#[[2]] - get me the data in the 2nd element
#[["empName"]] - [[]] can access using index or name
#$ - can access only using name







