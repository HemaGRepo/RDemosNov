skills<-c("Java","Agile","Scrum","Cloud","DevOps")
skills

rows<-c("2016","2017","2018")
cols<-c("Q1","Q2","Q3","Q4")
ratings<-c(2,3,2,1,3,4,2,1,1,2,2,2)
empRating<-matrix(ratings,nrow=3,dimnames=list(rows,cols))
empRating


emp<-list(name="Ram",
          rating=empRating)

emp[["rating"]]["2017","Q3"]

employeeData<-list(name="Ram",
                   salary=78787.34,
                   desig="Manager",
                   isCertified=TRUE,
                   skillDetails=skills,
                   rating=empRating)

emp<-list(name="Ram",
                   salary=78787.34,
                   desig="Manager",
                   isCertified=TRUE,
                   rating=empRating)
employeeData

str(employeeData)

employeeData[1]

employeeData[c(3,5)]

employeeData[c("name","desig","skillDetails")]

# List can  be accessed in 3 ways - [], [[]], $

# []- get me the compartment

# employeeData["rating"] is same as employeeData[6]
# It gets you the compartment #6 or with name rating
employeeData["rating"]
employeeData[1]

employeeData[c(1,4,5,6)]

# [[]], $ - get me the data within the compartment
employeeData[["rating"]]
employeeData[[1]]

employeeData$skillDetails

# Get me the Q3 2017 rating of the employee

employeeData["rating"]# gives u a box ie. a list with 1 box

employeeData[["rating"]]# give you a matrix which is the content in rating box

employeeData["rating"]["2017","Q3"]

employeeData[["rating"]]["2017","Q3"]

# Get 2016 rating
employeeData[["rating"]]["2016",]

employeeData["location"]<-"Chennai"

employeeData

employeeData[["location"]]<-"Pune"















