# Create a list containing a vector, a matrix and a list.
list_data <- list("Months"=c("Jan","Feb","Mar"),"Scores"= matrix(c(3,9,5,1,-2,8), nrow = 2),
                 "color"= list("green",12.3))

print(list_data)

# This gives me a Matrix
list_data$Scores[2,1]<-50

list_data$Scores

list_data2 <- list(c("Jan","Feb","Mar"),matrix(c(3,9,5,1,-2,8), nrow = 2),
                 list("green",12.3))
print(list_data2)

list_data[[2]][2,1]<-40
list_data[[2]]
