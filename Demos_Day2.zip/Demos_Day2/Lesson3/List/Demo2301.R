#Example 1
l1<-list("Priya",101,67.56,TRUE)
print(l1)

#Example 2
empList<-list("id"=789,"name"="Suraj","salary"=67876.83,"desig"="Manager")
print(empList)

#Example 3

#Skill is a vector
skills<-c("Java","Spring","Python","Perl","Linux")

#Rating is a matrix
rate<-c(1,2,3,4,3,3,4,2,2,2,1,3)
rnames<-c("2015","2016","2017")
cnames<-c("Q1","Q2","Q3","Q4")
empRating<-matrix(rate,nrow=3,dimnames=list(rnames,cnames))
print(empRating)

empDetail<-list("id"=101,"name"="Tarun","salary"=67876.83,"desig"="Manager",
                "skillData"=skills,"rating"=empRating)
print(empDetail)


#Accessing the elements

# [] - Get the box

empDetail[c(1,3)] # Get the boxes 1 and 3
empDetail[6]
empDetail[3]
empDetail[-2]

# [[]] - Get me the contents of the box

empDetail[[3]]
empDetail[[c(1,3)]]

# $ - similar to [[]] - get me the content of the box with name "rating"

empDetail$rating

# Get the Q3 2016 rating of the employee
empDetail[[6]]["2016","Q3"]

empDetail$rating["2016","Q3"]

#[[]]- use the column index or name
empDetail[[1]]
empDetail[["id"]]

#$ - use ONLY the column name
# invalid- empDetail$1
empDetail$id

# Add a new data to the list

empDetail["location"]<-"Chennai"

print(empDetail)

empDetail$projId<-101
print(empDetail)

empDetail[["isMarried"]]<-TRUE
print(empDetail)

# Delete the salary

empDetail["salary"]<-NULL
print(empDetail)


# Change the employee id to 45
empDetail[[1]]<-45
print(empDetail)

empDetail$rating["2017","Q4"]<-1
print(empDetail)










