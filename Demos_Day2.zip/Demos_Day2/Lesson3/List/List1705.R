#List - One dimensional DS that can store elements of differnt type

employee<-list(empid=101,
               name="Sita",
               salary=67545.89,
               skills=c("JEE","Spring","MVC"))

print(employee)

str(employee)

data<-c(1,3,2,3,4,4,4,4,1,4,2,3)
appData<-matrix(data,nrow=3,ncol=4,byrow = TRUE,
                dimnames=list(
                  c("2016","2017","2018"),
                  c("Q1","Q2","Q3","Q4")
                ))

print(appData)

#When u add a element or modify a element use [[]]
employee[["rating"]]<-appData


print(employee)

str(employee)


bankAccount<-list("accId"=4556,"balance"=3556565,
                  "CustName"="Arun",
                  "TransId"=c(356,45,909,345),
                  "Interest"=matrix(c(67,56,34,68),nrow=2,
                            dimnames = list(c("2017","2018"),c("H1","H2"))))

print(bankAccount)
bankAccount["TransId"]<-NULL

print(bankAccount)

#Accessthe elements of a list - [] , [[]], $


#Instruction 1- Get me the box 3 and box 5 - []
employee[c(3,5)]
employee[2]


#Instruction 2 - Get me the content of box 2 - [[]]

employee[[2]]
employee[[c(2,4)]]#Invalid

employee[["empid"]]

# $ is same as [[]] with $ u can use only the name and not index
employee$empid # Same as employee[["empid"]]

employee$rating # Same as employee[["rating"]] or employee[[5]]

#Change the name to "Sam"
employee[2]<-"Sam"

#Change the Q2 2017 rating to 1
employee[5][2,2]<-1 #Invalid
employee[[5]][2,2]<-1 

employee$rating["2017","Q4"]<-3

employee$rating[3,]




















