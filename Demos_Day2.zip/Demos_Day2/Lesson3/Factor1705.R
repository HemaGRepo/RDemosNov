desig<-c("SE","TL","Mgr","SSE","SSE","SE",
         "TL","Mgr","Mgr","SE","SSE","TL","TL")
is.factor(desig)

table(desig)

#The vector desig has repeated values (or) categorical data

#Create a factor for this vector
# Factor is created on Vectors which have repeated set of values

#Steps for creating the factor
#1) Find the unique values - SE, TL, Mgr, SSE
#2) Sort the values in alphabetical order - Mgr,SE,SSE,TL
#3) The sorted unique values are called as Levels - Mgr,SE,SSE,TL
#4) Give numbers for the sorted values ie. Levels 1-Mgr,2-SE,3-SSE,4-TL
#5) Take the vector ("SE","TL","Mgr","SSE","SSE","SE","TL","Mgr","Mgr","SE","SSE","TL","TL")
#6) Replace the values with numeric equivalent and store internally
#7) 2,4,1,3,3,2,4,1,1,

f1<-factor(desig)
print(f1)
str(f1)

f1[2]<-"Mgr"

print(f1)

f1[3]<-"Sr.Mgr" #Invalid because the factor has only 4 levels  Mgr,SE,SSE,TL
print(f1)

#Add Sr.Mgr to the level

levels(f1)<-c(levels(f1),"Sr.Mgr")
f1[3]<-"Sr.Mgr" #Valid because the factor has Sr.Mgr
print(f1)

gender<-c("M","F","M","F","M","F","M","M",
          "M","F","M","F","M","F","M","M","M","F","M","F","M","F","M","M",
          "M","F","M","F","M","F","M","M")
gfactor<-factor(gender, levels = c("M","F","T"))

str(gfactor)
table(gfactor)

desig<-c("SE","TL","Mgr","SSE","SSE","SE",
         "TL","Mgr","Mgr","SE","SSE","TL","TL")
f2<-factor(desig, levels=c("SE","SSE","TL","Mgr","Sr.Mgr","Dir","VP"))
print(f2)

table(f2)





