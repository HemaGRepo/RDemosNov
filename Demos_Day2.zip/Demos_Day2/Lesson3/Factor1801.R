
# Create a Factor
f1<-factor(c("SE","SSE","Mgr","Mgr","SSE","TL","SSE","SE","SE","SE","TL"))

#1) Take the unique values in Ascending order - "Mgr", SE", "SSE","TL"
#2) These are called as Levels ie. Levels="Mgr", "SE", "SSE","TL"
#3) Assign Numeric values to the levels 1="Mgr", 2="SE",3="SSE",4="TL"
#4) Internally store the data based on levels 
#5) ("SE","SSE","Mgr","Mgr","SSE","TL","SSE","SE","SE","SE","TL")
#6) (2,3,1,1,3,4,3,2,2,2,4)

print(f1)

f1[4]<-"VP"
f1[3]<-"SSE"

str(f1)

table(f1)

f2<-factor(c("SE","SSE","Mgr","Mgr","SSE","TL","SSE","SE","SE","SE","TL"),
           levels = c("SE","SSE","TL","Mgr","AVP","VP"))
print(f2)

f2[4]<-"VP"
print(f2)

str(f2)


dFact<-factor(c("SE","SSE","Mgr","Mgr","SSE","TL","SSE","SE","SE","SE","TL"))

# 4 unique values called as Levels -> Mgr,SE,SSE,TL=1,2,3,4 
# Data in the designs is modified as (2,3,1,1,3,4,3,2,2,2,4)
dFact

str(dFact)

dFact[1]<-"SSE"

dFact

dFact<-factor(c("SE","SSE","Mgr","Mgr","SSE","TL","SSE","SE","SE","SE","TL"),levels = c("SE","SSE","TL","ASE","Director","Mgr"))

# 6 unique values called as Levels -> Mgr,SE,SSE,TL=1,2,3,4 
# Data in the designs is modified as (2,3,1,1,3,4,3,2,2,2,4)
dFact

str(dFact)

dFact[1]<-"Director"

dFact


levels(dFact)<-c(levels(dFact),"VP")

table(dFact)




# Create a factor for this gender
fgender<-factor(c("male","male","female","female","male",
                  "female","male","male","male","female",
                  "female","male","female","male","male","male",
                  "female","female","male","female","male","male",
                  "male","female","female","male","female","male"))

# Tabulate the values in the factor
table(fgender)

#Vector
v1<-c("SE","SSE","Mgr","Mgr","SSE","TL","SSE","SE","SE","SE","TL")
print(table(v1))

plot(table(v1))
barplot(table(v1))

transport<-c("TW","FW","PT","PT","WA","PT","TW","FW","WA","FW","FW","WA","WA","PT","TW","TW","FW","WA","FW","PT","WA","PT","TW","WA","PT","TW","FW","PT","PT","WA")

table(factor(transport))





