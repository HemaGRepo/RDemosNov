column.names <- c("COL1","COL2","COL3")
row.names <- c("ROW1","ROW2","ROW3")
matrix.names <- c("Matrix1","Matrix2")

vector1 <- 1:9
vector2 <- 10:18

# Take these vectors as input to the array.
result <- array(c(vector1,vector2),dim = c(3,3,2),
                dimnames = list(row.names,column.names,matrix.names))
print(result)

result[2,3,1]

trial <- matrix(c(34,11,9,32), ncol=2)
colnames(trial) <- c('sick', 'healthy')
rownames(trial) <- c('risk', 'no_risk')
print(trial)

trial.table <- as.table(trial)
print(trial.table)

trial.table[3]

trial.table['risk', 'sick']
