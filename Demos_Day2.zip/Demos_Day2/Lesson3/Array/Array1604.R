myEggShelf<-array(
            1:48,
            dim = c(2,4,3,2),
            dimnames = list(
              c("Row1","Row2"),
              c("Col1","Col2","Col3","Col4"),
              c("Tray1","Tray2","Tray3"),
              c("Box1","Box2")
            )
)

print(myEggShelf)
myEggShelf[1,3,1,2]
myEggShelf[2,,1,2]
myEggShelf[,,2,2]
myEggShelf[,,,1]

#Store the 3 years rating of 3 employees
ratingEmp1<-c(3,2,3,4,3,2,1,3,3,4,2,4)
ratingEmp2<-c(1,1,1,1,1,1,1,1,1,1,1,1)
ratingEmp3<-c(3,4,3,4,3,4,3,4,3,4,3,4)

empRatings<-array(c(ratingEmp1,ratingEmp2,ratingEmp3),
                  dim=c(4,3,3),
                  dimnames=list(
                    c("Q1","Q2","Q3","Q4"),
                    c("2016","2017","2018"),
                    c("Dhoni","Bravo","Kholi")
                  )
)
print(empRatings)

empRatings["Q3",,]
empRatings[,"2016",]
empRatings[c("Q3","Q4"),"2016",c("Dhoni","Bravo")]

myEggShelf<-array(
  1:144,
  dim = c(2,4,3,2,3),
  dimnames = list(
    c("Row1","Row2"),
    c("Col1","Col2","Col3","Col4"),
    c("Tray1","Tray2","Tray3"),
    c("Box1","Box2"),
    c("Room1","Room2","Room3")
  )
)


#ProdName,Cols(Qty,Price),SubCategories,Category,Shops



















