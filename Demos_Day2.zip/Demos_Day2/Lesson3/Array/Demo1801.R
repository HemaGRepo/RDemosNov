#My egg shelf example
# 3 dimension
eggs<-1:24

#rows=2,cols=3,trays=4
rnames<-c("Row1","Row2")
cnames<-c("Col1","Col2","Col3")
trays<-c("Tray1","Tray2","Tray3","Tray4")

eggShelf<-array(eggs,dim = c(2,3,4),dimnames = list(rnames,cnames,trays))
eggShelf


# 4 dimension
eggs1<-1:48

#rows=2,cols=3,trays=4
rnames<-c("Row1","Row2")
cnames<-c("Col1","Col2","Col3")
trays<-c("Tray1","Tray2","Tray3","Tray4")
boxes<-c("Box1","Box2")

eggBoxes<-array(eggs1,dim=c(2,3,4,2),dimnames = list(rnames,cnames,trays,boxes))
eggBoxes

eggBoxes[1,2,3,1]

eggBoxes[,,,1]

eggBoxes[,,4,2]


Titanic




