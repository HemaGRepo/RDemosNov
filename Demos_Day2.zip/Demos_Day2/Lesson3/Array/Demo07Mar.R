data<-1:48

eggShelf<-array(data,
                dim = c(2,4,3,2),
                dimnames = list(
                  c("Row1","Row2"),
                  c("Col1","Col2","Col3","Col4"),
                  c("Tray1","Tray2","Tray3"),
                  c("Box1","Box2")
                ))

print(eggShelf)
eggShelf[1,4,2,2]
eggShelf["Row1","Col4","Tray2","Box2"]
eggShelf[2,,1,1]
eggShelf[,,,1]
eggShelf[,,2,2]

str(eggShelf)
dim(eggShelf)

# Store Appraisal data for 3 employees

appData<-c( c(1,3,2,3,1,1,1,1,2,3,4,2),
            c(1,1,1,1,2,2,2,2,3,3,3,3),
            c(4,4,4,4,3,3,3,3,4,3,4,3))



rownames<-c("2016","2017","2018")
colnames<-c("Q1","Q2","Q3","Q4")
empnames<-c("Ram","Sita","Vishnu")

empRatings<-array(appData,dim = c(3,4,3),
                  dimnames = list(rownames,colnames,empnames))
print(empRatings)

#Accessing a array
# 2017, Q2 rating of Sita
empRatings[2,2,2]

# All ratings of Ram
empRatings[,,"Ram"]

# All Q3 ratings of 2018
empRatings["2017","Q3",]

# Get me all year Q4 ratings for all employees
empRatings[,4,]

#Change Vishnu Q4 2018 rating to 2
empRatings[3,4,3]<-2
print(empRatings)


data1<-1:48

eggShelf1<-array(data1,
                dim = c(2,4,3,2),
                dimnames = list(
                  c("Row1","Row2"),
                  c("Col1","Col2","Col3","Col4"),
                  c("Tray1","Tray2","Tray3"),
                  c("Box1","Box2")
                ))
print(eggShelf1)

data2<-51:98

eggShelf2<-array(data2,
                dim = c(2,4,3,2),
                dimnames = list(
                  c("Row1","Row2"),
                  c("Col1","Col2","Col3","Col4"),
                  c("Tray1","Tray2","Tray3"),
                  c("Box1","Box2")
                ))
print(eggShelf2)
eggShelf1+eggShelf2

str(eggShelf1)

str(empRatings)


