# I have 48 eggs - trays 2*4

data <-1:48
eggShelf<-array(
                data,
                dim = c(2,4,3,2),
                dimnames=list(
                  c("r1","r2"),
                  c("c1","c2","c3","c4"),
                  c("Tray1","Tray2","Tray3"),
                  c("Box1","Box2")
                )
)

print(eggShelf)


#blue Egg
eggShelf[2,2,2,2]

# Red Tray
eggShelf[,,3,2]

# Access All Green eggs
eggShelf[1,,2,1]



print(Titanic)


print(crimtab)

print(UCBAdmissions)
