# Store 24 eggs in trays

# 3 dimensional array
eggs<-1:24

# row=2, col=4, trays=3

rnames<-c("Row1","Row2")
cnames<-c("Col1","Col2","Col3","Col4")
tnames<-c("T1","T2","T3")

# Create the array
eggShelf<-array(eggs,dim=c(2,4,3),dimnames=list(rnames,cnames,tnames))
print(eggShelf)

# Get me the 1 row 2 col egg in Tray 2
eggShelf[1,2,2]

# Get me all the eggs in 2nd row of 1st tray

eggShelf[2,,1]

#Get me tray 3
eggShelf[,,3]


# Store 48 eggs in trays and box

# 4 dimensional array
eggs1<-1:48

# row=2, col=4, trays=3, box=2

rnames1<-c("Row1","Row2")
cnames1<-c("Col1","Col2","Col3","Col4")
tnames1<-c("T1","T2","T3")
bnames1<-c("Box 1","Box 2")

# Create the array
eggShelf1<-array(eggs1,dim=c(2,4,3,2),dimnames=list(rnames1,cnames1,tnames1,bnames1))
print(eggShelf1)

# Get me Box1
eggShelf1[,,,1]

# Get me the 3rd tray of Box 2
eggShelf1[,,3,2]

# Get me the first egg in Box 2
eggShelf1[1,1,1,2]

# Create Two 3D arrays
a1<-array(1:24,dim=c(2,3,4))
a2<-array(25:48,dim=c(2,3,4))

print(a1)
print(a2)

a3<-a1+a2
print(a3)


print(Titanic)


print(crimtab)

print(UCBAdmissions)








